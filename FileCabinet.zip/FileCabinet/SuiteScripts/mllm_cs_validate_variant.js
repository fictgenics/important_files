function onSave(type) 
{
	

    var refNum = nlapiGetFieldValue('name');
	var id = nlapiGetFieldValue('id');
	nlapiLogExecution( 'DEBUG', 'id', id );
	if (id == null || id =='')
	{
		
		if (refNum != null && refNum != '') 
		{
			var filter = new Array();
			filter[0] = new nlobjSearchFilter('name', null, 'is', refNum);
			var column = new Array();
			column[0] = new nlobjSearchColumn('internalid');
			column[1] = new nlobjSearchColumn('name');
			var searchResults = nlapiSearchRecord('customrecord_advs_model_variant', null, filter, column);
			if (searchResults != null && searchResults.length > 0) 
			{
				alert('Variant# is already there with internal id: ' + searchResults[0].getValue('internalid'));
				return false;
			}
			else
			{
				return true;
			}
		}
	}
	else
	{
		return true;
	}
}
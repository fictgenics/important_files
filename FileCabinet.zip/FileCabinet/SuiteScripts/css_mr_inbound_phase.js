/**
	*@NApiVersion 2.x
	*@NScriptType MapReduceScript
*/
/**
	* Script Name          : CSS MR CREATE PAYMENT APPLICATION
	* Author               : Naim 
	* Start Date           : Feb 2023
	* Last Modified Date   : 
	* Description          : This script is responsible to create a payment application record.
*/

/**
	* The script uses NetSuite's Map/Reduce pardigm implementation and uses getInputData, map, and summarize stages. When completed,
	* the script deletes existing Pricing data for for qualifying items using the following generalized algorithm:
	* Read the items and price data in getinputdata
	* In map stage, delete the price data that was passed from getInputData stage
	* In summery stage, write the debug log regarding uses and descriptive messages
*/
define(['N/search', 'N/record', 'N/runtime'],
	/**
		* @param search @param record
	*/

	function (search, record, runtime) {


		function getInputData() {
			try {
				var schobj = runtime.getCurrentScript();
				var data = schobj.getParameter({ name: 'custscript_c_sp_inbound_shipment' });
				log.debug('data', data);

				var inboundshipmentSearchObj = search.create({
					type: "inboundshipment",
					filters:
						[
							["internalid", "anyof", data]
						],
					columns:
						[
							search.createColumn({
								name: "purchaseorder",
								summary: "GROUP",
								label: "Items - PO"
							}),
							search.createColumn({
								name: "quantityexpected",
								summary: "SUM",
								label: "Items - Quantity Expected"
							})
						]
				});
				var searchResultCount = inboundshipmentSearchObj.runPaged().count;
				log.debug("inboundshipmentSearchObj result count", searchResultCount);

				return inboundshipmentSearchObj;
			}
			catch (reqError) {
				log.error('log Error', reqError);
			}

		}


		function map(context) {
			try {
				var mapData = JSON.parse(context.value);
				log.debug('mapData', mapData);

				var poId = mapData.values['GROUP(purchaseorder)'].value;
				var quantitySum = mapData.values['SUM(quantityexpected)'];
				log.debug('poId', poId);
				log.debug('quantitySum', quantitySum);

				var customrecord_c59306_purchase_milestoneSearchObj = search.create({
					type: "customrecord_c59306_purchase_milestone",
					filters:
						[
							["custrecord_c59306_purchase_order", "anyof", poId],
							"AND",
							["custrecord_c59306_inbound_shipment", "anyof", "@NONE@"]
						],
					columns:
						[
							search.createColumn({ name: "internalid", label: "Internal ID" })
						]
				});
				var searchResultCount = customrecord_c59306_purchase_milestoneSearchObj.runPaged().count;
				log.debug("customrecord_c59306_purchase_milestoneSearchObj result count", searchResultCount);
				//This search maximum outout is 4
				customrecord_c59306_purchase_milestoneSearchObj.run().each(function (result) {
					var milestoneId = result.getValue({ name: "internalid", label: "Internal ID" })
					context.write({ key: milestoneId, value: milestoneId });
					return true;
				});

			}
			catch (reqError) {
				log.error('log Error', reqError);
			}
		}


		function reduce(context) {
			try {
				var schobj = runtime.getCurrentScript();
				var milestoneId = context.key;
				var inboundId = schobj.getParameter({ name: 'custscript_c_sp_inbound_shipment' });
				log.debug('milestoneId', milestoneId);
				log.debug('inboundId', inboundId);
				//var reduceData = context.values.map(JSON.parse);
				//log.debug('reduceData', reduceData);

				record.submitFields({
					type: 'customrecord_c59306_purchase_milestone',
					id: milestoneId,
					values: {
						custrecord_c59306_inbound_shipment: inboundId
					},
					options: {
						enableSourcing: true,
						ignoreMandatoryFields: true
					}
				});
			}
			catch (reqError) {
				log.error('log Error', reqError);
			}
		}


		return {
			getInputData: getInputData,
			map: map,
			reduce: reduce
		};
	});					
/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED:
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/record', 'N/ui/serverWidget', 'N/search', 'N/task', 'N/query'], function (record, serverWidget, search, task, query) {

	function beforeLoad(context) {
		try {
			var custForm = context.form;
			var recObj = context.newRecord;

			/* if (context.type == 'view') {
				var recordOrder = context.newRecord;

				custForm.addButton({
					id: 'custpage_approve',
					label: 'Verify Credit Limit',
					functionName: 'onVerifyLimitButton(' + recordOrder.id + ')'
				});
				custForm.clientScriptModulePath = "./CSS_CS_Verify_Credit_Limit.js";

			} */

			//log.debug('context.type', context.type);
			if (context.type == 'edit') {
				var tab = custForm.addTab({
					id: 'custpage_open_milestone',
					label: 'Open Milestone'
				});

				var sublist = custForm.addSublist({
					id: 'custpage_open_milestone_list',
					type: serverWidget.SublistType.INLINEEDITOR,
					label: 'Open Milestone List',
					tab: 'custpage_open_milestone'
				});

				sublist.addField({
					id: 'custpage_mark_payment',
					type: serverWidget.FieldType.CHECKBOX,
					label: 'MARK PAYMENT'
				});

				var paymentMilestone = sublist.addField({
					id: 'custpage_payment_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});
				paymentMilestone.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var paymentQuantity = sublist.addField({
					id: 'custpage_quantity',
					type: serverWidget.FieldType.TEXT,
					label: 'Quantity'
				});
				paymentQuantity.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var salesOrder = sublist.addField({
					id: 'custpage_sales_order',
					type: serverWidget.FieldType.TEXT,
					label: 'SALES ORDER'
				});
				salesOrder.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var fulfillmentReq = sublist.addField({
					id: 'custpage_fulfillment_request',
					type: serverWidget.FieldType.TEXT,
					label: 'FULFILLMENT REQUEST'
				});
				fulfillmentReq.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var itemFulfillment = sublist.addField({
					id: 'custpage_item_fulfillment',
					type: serverWidget.FieldType.TEXT,
					label: 'ITEM FULFILLMENT'
				});
				itemFulfillment.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestoneType = sublist.addField({
					id: 'custpage_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});
				milestoneType.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestonePercent = sublist.addField({
					id: 'custpage_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});
				milestonePercent.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestoneAmount = sublist.addField({
					id: 'custpage_milestone_amount',
					type: serverWidget.FieldType.CURRENCY,
					label: 'MILESTONE AMOUNT'
				});
				milestoneAmount.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var currentApplied = sublist.addField({
					id: 'custpage_current_applied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'CURRENT APPLIED'
				});
				currentApplied.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var amountRemaining = sublist.addField({
					id: 'custpage_amount_remaining',
					type: serverWidget.FieldType.CURRENCY,
					label: 'REMAIN AMOUNT'
				});
				amountRemaining.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var appliedNow = sublist.addField({
					id: 'custpage_applied_now',
					type: serverWidget.FieldType.TEXT,
					label: 'APPLIED NOW'
				});


				var milestoneId = sublist.addField({
					id: 'custpage_milestone_id',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE Id'
				});
				milestoneId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
				
				var typeId = sublist.addField({
					id: 'custpage_milestone_type_id',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE ID'
				});
				typeId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

				var customrecord_c58005_payment_milestoneSearchObj = search.create({
					type: "customrecord_c58005_payment_milestone",
					filters:
						[
							["custrecord_c58005_quotation.mainline", "is", "T"],
							"AND",
							["custrecord_c58005_milestone_type", "anyof", "1", "2", "3", "4"],
							"AND",
							["custrecord_c58005_milestone_remain_amt", "greaterthan", "0.00"],
							"AND",
							["custrecord_c58005_customer", "anyof", recObj.id],
							"AND",
							["custrecord_c58005_quotation.status","noneof","Estimate:X"],
							"AND",
							["custrecord_c58005_quotation.custbody_won_quotation", "is", "T"]
							
						],
					columns:
						[
							search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "internalid" }),
							search.createColumn({ name: "name", label: "Name" }),
							search.createColumn({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" }),
							search.createColumn({ name: "custrecord_c58005_milestone", label: "Milestone %" }),
							search.createColumn({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }),
							search.createColumn({ name: "Internalid", label: "Internalid" }),
							search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" }),
							search.createColumn({ name: "custrecord_c58005_milestone_remain_amt", label: "custrecord_c58005_milestone_remain_amt" }),
							search.createColumn({ name: "custrecord_c58005_salesorder", label: "custrecord_c58005_salesorder" }),
							search.createColumn({ name: "custrecord_c58005_fulfillment_request", label: "custrecord_c58005_fulfillment_request" }),
							search.createColumn({ name: "custrecord_c58005_item_fulfillment", label: "custrecord_c58005_item_fulfillment" }),
							search.createColumn({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" })

						]
				});
				var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
				log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
				var count = 0;
				var quo
				customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
					var quotation = result.getValue({ name: "name", sort: search.Sort.ASC, label: "Name" });
					var milestoneTypeVal = result.getText({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });
					var milestonePercentVal = result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" });
					var milestoneAmountVal = result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" });
					var milestoneValue = result.getValue({ name: "Internalid", label: "Internalid" });
					var currentAppliedVal = result.getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" });
					var remainAmt = result.getValue({ name: "custrecord_c58005_milestone_remain_amt", label: "custrecord_c58005_milestone_remain_amt" });
					var salesId = result.getText({ name: "custrecord_c58005_salesorder", label: "custrecord_c58005_salesorder" });
					var fulfillReq = result.getText({ name: "custrecord_c58005_fulfillment_request", label: "custrecord_c58005_fulfillment_request" });
					var itemFulfill = result.getText({ name: "custrecord_c58005_item_fulfillment", label: "custrecord_c58005_item_fulfillment" });
					var quantity = result.getValue({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" });
					var milestoneTypeId = result.getValue({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });

					if (!currentAppliedVal) {
						currentAppliedVal = 0;
					}

					if (!salesId) {
						salesId = '';
					}

					if (!fulfillReq) {
						fulfillReq = '';
					}

					if (!itemFulfill) {
						itemFulfill = '';
					}

					sublist.setSublistValue({ id: 'custpage_payment_milestone', line: count, value: quotation });
					sublist.setSublistValue({ id: 'custpage_quantity', line: count, value: quantity });
					sublist.setSublistValue({ id: 'custpage_sales_order', line: count, value: salesId });
					sublist.setSublistValue({ id: 'custpage_fulfillment_request', line: count, value: fulfillReq });
					sublist.setSublistValue({ id: 'custpage_item_fulfillment', line: count, value: itemFulfill });
					sublist.setSublistValue({ id: 'custpage_milestone_type', line: count, value: milestoneTypeVal });
					sublist.setSublistValue({ id: 'custpage_milestone_percent', line: count, value: milestonePercentVal });
					sublist.setSublistValue({ id: 'custpage_milestone_amount', line: count, value: milestoneAmountVal });
					sublist.setSublistValue({ id: 'custpage_current_applied', line: count, value: currentAppliedVal });
					sublist.setSublistValue({ id: 'custpage_amount_remaining', line: count, value: remainAmt });
					sublist.setSublistValue({ id: 'custpage_milestone_id', line: count, value: milestoneValue });
					sublist.setSublistValue({ id: 'custpage_milestone_type_id', line: count, value: milestoneTypeId });
					count++;
					return true;
				});
			}

			if (context.type != 'create') {
				var softTab = custForm.addTab({
					id: 'custpage_soft_limit',
					label: 'Soft Limit'
				});

				var softSublist = custForm.addSublist({
					id: 'custpage_soft_limit_list',
					type: serverWidget.SublistType.LIST,
					label: 'Soft Limit List',
					tab: 'custpage_soft_limit'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_customer',
					type: serverWidget.FieldType.TEXT,
					label: 'CUSTOMER'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_quantity',
					type: serverWidget.FieldType.TEXT,
					label: 'QUANTITY'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_amount',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE AMOUNT'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_applied_to',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE APPLIED TO'
				});


				var queryString = "SELECT BUILTIN.DF(pa.custrecord_c57685_customer) AS customer,BUILTIN.DF(pa.custrecord_c57685_payment_milestone) AS paymentname, ";
				queryString += "pa.custrecord_c57685_milestone_percent AS percent, BUILTIN.DF(pa.custrecord_c57685_pay_milestone_type) AS milestonetype, ";
				queryString += "pa.custrecord_c57685_milestone_amount AS amount, pa.custrecord_c57685_milestone_applied_to AS appliedto, ";
				queryString += "BUILTIN.DF(pm.custrecord_c58005_fulfillment_request),t.recordtype, BUILTIN.DF(t.status),pm.custrecord_c58005_quantity AS quantity ";
				queryString += "FROM customrecord_c57685_paymt_milestone_app AS pa ";
				queryString += "JOIN transaction AS qt ON pa.custrecord_c57685_quotation = qt.id ";
				queryString += "JOIN customrecord_c58005_payment_milestone AS pm ON pa.custrecord_c57685_payment_milestone = pm.id ";
				queryString += "LEFT JOIN transaction AS t ON pm.custrecord_c58005_fulfillment_request = t.id ";
				queryString += "WHERE pa.isinactive = 'F' AND pa.custrecord_c57685_customer = '" + recObj.id + "' AND BUILTIN.DF(qt.status) <> 'Quotation : Expired' AND ((pa.custrecord_c57685_pay_milestone_type = 1 AND pm.custrecord_c58005_salesorder IS NULL) OR ((pa.custrecord_c57685_pay_milestone_type = 2 AND BUILTIN.DF(t.status) = 'Fulfillment Request : New') OR (pa.custrecord_c57685_pay_milestone_type = 2 AND pm.custrecord_c58005_fulfillment_request IS NULL)) OR (pa.custrecord_c57685_pay_milestone_type = 3 AND PM.custrecord_c58005_item_fulfillment IS NULL) OR (pa.custrecord_c57685_pay_milestone_type = 4 AND PM.custrecord_c58005_invoice IS NULL))";

				//log.debug('queryString', queryString);
				var queryResult = query.runSuiteQL({ query: queryString });
				var resultValues = queryResult.asMappedResults();

				for (var x = 0; x < resultValues.length; x++) {
					softSublist.setSublistValue({ id: 'custpage_soft_customer', line: x, value: resultValues[x].customer });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone', line: x, value: resultValues[x].paymentname });
					softSublist.setSublistValue({ id: 'custpage_soft_quantity', line: x, value: resultValues[x].quantity });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_type', line: x, value: resultValues[x].milestonetype });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_percent', line: x, value: resultValues[x].percent * 100 + '%' });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_amount', line: x, value: resultValues[x].amount });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_applied_to', line: x, value: resultValues[x].appliedto });
				}
			}

			if (context.type == 'view') {
				var appliedField = custForm.getField({id: 'custentity_c58005_customer_applied_amt'});
				appliedField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
				
				var unappliedField = custForm.getField({id: 'custentity_c58005_customer_unapplied_amt'});
				unappliedField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
	 
				custForm.addField({
					id: 'custpage_applied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'APPLIED AMOUNT'
				});
				
				custForm.addField({
					id: 'custpage_unapplied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'UNAPPLIED AMOUNT'
				});
				
		        var customerDeposite = 0;
				
				var custLookUp = search.lookupFields({
                    type: 'customer',
                    id: recObj.id,
                    columns: ['depositbalance']
                });
                var depsiteBalance = custLookUp.depositbalance;
                if (depsiteBalance) {
					customerDeposite = depsiteBalance;
                }
				
				var filters =
                    [
                        [[["custrecord_c58005_customer", "anyof", recObj.id], "AND", ["custrecord_c58005_salesorder.status", "noneof", "SalesOrd:G"], "AND", ["custrecord_c58005_salesorder.mainline", "is", "T"], "AND", ["custrecord_c58005_quotation.status","noneof","Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]], "OR", [["custrecord_c58005_customer", "anyof", recObj.id], "AND", ["custrecord_c58005_salesorder", "anyof", "@NONE@"], "AND", ["custrecord_c58005_quotation.status","noneof","Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]]],
                        "AND",
                        ["isinactive", "is", "F"],
                        "AND",
                        ["custrecord_c58005_milestone_applied_amt", "isnotempty", ""]
                    ];

                var columns =
                    [
                        search.createColumn({ name: "custrecord_c58005_salesorder", label: "Sales Order" }),
                        search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" })
                    ];

                var appliedObj = searchAllRecord('customrecord_c58005_payment_milestone', null, filters, columns);

                var totalApplied = 0;
                var salesArray = [];
                for (var z = 0; z < appliedObj.length; z++) {
                    var salesId = appliedObj[z].getValue({ name: "custrecord_c58005_salesorder", label: "Sales Order" });
                    var appliedValue = appliedObj[z].getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" });
                    totalApplied = parseFloat(totalApplied) + parseFloat(appliedValue);
                    var index = salesArray.indexOf(salesId);
                    if (index == '-1' && salesId) {
                        salesArray.push(salesId);
                    }
                }
				log.debug('totalApplied', totalApplied);
				log.debug('appliedObj', appliedObj);
				if (salesArray.length > 0) {
                    var invoiceSearchObj = search.create({
                        type: "invoice",
                        filters:
                            [
                                ["type", "anyof", "CustInvc"],
                                "AND",
                                ["createdfrom", "anyof", salesArray],
                                "AND",
                                ["mainline", "is", "T"]
                            ],
                        columns:
                            [
                                search.createColumn({ name: "amount", summary: "SUM", label: "Amount" })
                            ]
                    });
                    var searchResultCount = invoiceSearchObj.runPaged().count;
                    if(searchResultCount > 0){
						var searchResult = invoiceSearchObj.run().getRange({start: 0,end: 1});
		                var partialTotal = searchResult[0].getValue({ name: "amount", summary: "SUM", label: "Amount" });
						totalApplied = totalApplied - partialTotal; 
					}
                }
				
				var unapplied = customerDeposite - totalApplied;  
				recObj.setValue({fieldId: 'custpage_applied',value: totalApplied,ignoreFieldChange: true});
				recObj.setValue({fieldId: 'custpage_unapplied',value: unapplied,ignoreFieldChange: true});
			}
		}
		catch (e) { log.error('Error', e) }
	}


	function afterSubmit(context) {
		try {
			var recObj = context.newRecord;

			var lineCnt = recObj.getLineCount({ sublistId: 'custpage_open_milestone_list' });
			//log.debug("lineCnt", lineCnt);

			var paymentArray = [];
			for (var x = 0; x < lineCnt; x++) {
				var markPayment = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment', line: x });
				var appliedTo = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', line: x });
				if (markPayment == 'T' && parseFloat(appliedTo) > 0) {
					var paymentId = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_id', line: x });
					paymentArray.push({ 'paymentId': paymentId, 'appliedTo': appliedTo });
				}
			}
			log.debug("paymentArray", paymentArray);

			if (paymentArray.length > 0) {
				var mrTask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_css_mr_create_payment_app',
					//deploymentId: availableJobId[randomId],
					params: { custscript_c_sp_milestone_data: paymentArray }
				});
				mrTask.submit();
			}
		}
		catch (e) { log.error('Error', e) }
	}


	function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
		try {
			var arrSearchResults = [];
			var count = 1000,
				min = 0,
				max = 1000;
			var searchObj = false;
			if (recordType == null) {
				recordType = null;
			}
			if (searchId) {
				searchObj = search.load({
					id: searchId
				});
				if (searchFilter) {
					searchObj.filterExpression = searchFilter;
				}
			} else {
				searchObj = search.create({
					type: recordType,
					filters: searchFilter,
					columns: searchColumns
				})
			}

			var rs = searchObj.run();
			//searchColumns.push(rs.columns);
			//allColumns = rs.columns;

			while (count == 1000) {
				var resultSet = rs.getRange({
					start: min,
					end: max
				});
				if (resultSet != null) {
					arrSearchResults = arrSearchResults.concat(resultSet);
					min = max;
					max += 1000;
					count = resultSet.length;
				}
			}
		} catch (e) {
			//log.debug('Error searching for Customer:- ', e.message);
		}
		return arrSearchResults;
	}


	return {
		beforeLoad: beforeLoad,
		afterSubmit: afterSubmit
	};
});
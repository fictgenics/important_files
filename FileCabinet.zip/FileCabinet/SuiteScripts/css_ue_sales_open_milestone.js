/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED:
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/record', 'N/ui/serverWidget', 'N/search', 'N/task', 'N/query'], function (record, serverWidget, search, task, query) {

	function beforeLoad(context) {
		try {
			var custForm = context.form;
			var recObj = context.newRecord;
			var createdFrom = recObj.getValue({ fieldId: 'createdfrom' });

			//log.debug('context.type', context.type);
			if (context.type == 'edit' && createdFrom) {
				var tab = custForm.addTab({
					id: 'custpage_open_milestone',
					label: 'Open Milestone'
				});

				var sublist = custForm.addSublist({
					id: 'custpage_open_milestone_list',
					type: serverWidget.SublistType.INLINEEDITOR,
					label: 'Open Milestone List',
					tab: 'custpage_open_milestone'
				});

				sublist.addField({
					id: 'custpage_mark_payment',
					type: serverWidget.FieldType.CHECKBOX,
					label: 'MARK PAYMENT'
				});

				var paymentMilestone = sublist.addField({
					id: 'custpage_payment_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});
				paymentMilestone.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var paymentQuantity = sublist.addField({
					id: 'custpage_quantity',
					type: serverWidget.FieldType.TEXT,
					label: 'Quantity'
				});
				paymentQuantity.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var salesOrder = sublist.addField({
					id: 'custpage_sales_order',
					type: serverWidget.FieldType.TEXT,
					label: 'SALES ORDER'
				});
				salesOrder.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var fulfillmentReq = sublist.addField({
					id: 'custpage_fulfillment_request',
					type: serverWidget.FieldType.TEXT,
					label: 'FULFILLMENT REQUEST'
				});
				fulfillmentReq.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var itemFulfillment = sublist.addField({
					id: 'custpage_item_fulfillment',
					type: serverWidget.FieldType.TEXT,
					label: 'ITEM FULFILLMENT'
				});
				itemFulfillment.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestoneType = sublist.addField({
					id: 'custpage_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});
				milestoneType.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestonePercent = sublist.addField({
					id: 'custpage_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});
				milestonePercent.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestoneAmount = sublist.addField({
					id: 'custpage_milestone_amount',
					type: serverWidget.FieldType.CURRENCY,
					label: 'MILESTONE AMOUNT'
				});
				milestoneAmount.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var currentApplied = sublist.addField({
					id: 'custpage_current_applied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'CURRENT APPLIED'
				});
				currentApplied.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var amountRemaining = sublist.addField({
					id: 'custpage_amount_remaining',
					type: serverWidget.FieldType.CURRENCY,
					label: 'REMAIN AMOUNT'
				});
				amountRemaining.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var appliedNow = sublist.addField({
					id: 'custpage_applied_now',
					type: serverWidget.FieldType.TEXT,
					label: 'APPLIED NOW'
				});


				var milestoneId = sublist.addField({
					id: 'custpage_milestone_id',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE Id'
				});
				milestoneId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

				var typeId = sublist.addField({
					id: 'custpage_milestone_type_id',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE ID'
				});
				typeId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

				var customrecord_c58005_payment_milestoneSearchObj = search.create({
					type: "customrecord_c58005_payment_milestone",
					filters:
						[
							["custrecord_c58005_quotation.mainline", "is", "T"],
							"AND",
							["custrecord_c58005_milestone_type", "anyof", "1", "2", "3", "4"],
							"AND",
							["custrecord_c58005_milestone_remain_amt", "greaterthan", "0.00"],
							"AND",
							["custrecord_c58005_quotation", "anyof", createdFrom],
							"AND",
							["custrecord_c58005_quotation.status", "noneof", "Estimate:X"],
							"AND",
							["custrecord_c58005_quotation.custbody_won_quotation", "is", "T"]

						],
					columns:
						[
							search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "internalid" }),
							search.createColumn({ name: "name", label: "Name" }),
							search.createColumn({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" }),
							search.createColumn({ name: "custrecord_c58005_milestone", label: "Milestone %" }),
							search.createColumn({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }),
							search.createColumn({ name: "Internalid", label: "Internalid" }),
							search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" }),
							search.createColumn({ name: "custrecord_c58005_milestone_remain_amt", label: "custrecord_c58005_milestone_remain_amt" }),
							search.createColumn({ name: "custrecord_c58005_salesorder", label: "custrecord_c58005_salesorder" }),
							search.createColumn({ name: "custrecord_c58005_fulfillment_request", label: "custrecord_c58005_fulfillment_request" }),
							search.createColumn({ name: "custrecord_c58005_item_fulfillment", label: "custrecord_c58005_item_fulfillment" }),
							search.createColumn({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" })

						]
				});
				var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
				log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
				var count = 0;
				var quo
				customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
					var quotation = result.getValue({ name: "name", sort: search.Sort.ASC, label: "Name" });
					var milestoneTypeVal = result.getText({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });
					var milestonePercentVal = result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" });
					var milestoneAmountVal = result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" });
					var milestoneValue = result.getValue({ name: "Internalid", label: "Internalid" });
					var currentAppliedVal = result.getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" });
					var remainAmt = result.getValue({ name: "custrecord_c58005_milestone_remain_amt", label: "custrecord_c58005_milestone_remain_amt" });
					var salesId = result.getText({ name: "custrecord_c58005_salesorder", label: "custrecord_c58005_salesorder" });
					var fulfillReq = result.getText({ name: "custrecord_c58005_fulfillment_request", label: "custrecord_c58005_fulfillment_request" });
					var itemFulfill = result.getText({ name: "custrecord_c58005_item_fulfillment", label: "custrecord_c58005_item_fulfillment" });
					var quantity = result.getValue({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" });
					var milestoneTypeId = result.getValue({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });

					if (!currentAppliedVal) {
						currentAppliedVal = 0;
					}

					if (!salesId) {
						salesId = '';
					}

					if (!fulfillReq) {
						fulfillReq = '';
					}

					if (!itemFulfill) {
						itemFulfill = '';
					}

					sublist.setSublistValue({ id: 'custpage_payment_milestone', line: count, value: quotation });
					sublist.setSublistValue({ id: 'custpage_quantity', line: count, value: quantity });
					sublist.setSublistValue({ id: 'custpage_sales_order', line: count, value: salesId });
					sublist.setSublistValue({ id: 'custpage_fulfillment_request', line: count, value: fulfillReq });
					sublist.setSublistValue({ id: 'custpage_item_fulfillment', line: count, value: itemFulfill });
					sublist.setSublistValue({ id: 'custpage_milestone_type', line: count, value: milestoneTypeVal });
					sublist.setSublistValue({ id: 'custpage_milestone_percent', line: count, value: milestonePercentVal });
					sublist.setSublistValue({ id: 'custpage_milestone_amount', line: count, value: milestoneAmountVal });
					sublist.setSublistValue({ id: 'custpage_current_applied', line: count, value: currentAppliedVal });
					sublist.setSublistValue({ id: 'custpage_amount_remaining', line: count, value: remainAmt });
					sublist.setSublistValue({ id: 'custpage_milestone_id', line: count, value: milestoneValue });
					sublist.setSublistValue({ id: 'custpage_milestone_type_id', line: count, value: milestoneTypeId });
					count++;
					return true;
				});
			}


			if (context.type == 'edit') {
				custForm.addField({
					id: 'custpage_deposit_balance',
					type: serverWidget.FieldType.CURRENCY,
					label: 'DEPOSIT BALANCE'
				});

				custForm.addField({
					id: 'custpage_applied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'APPLIED AMOUNT'
				});

				custForm.addField({
					id: 'custpage_unapplied',
					type: serverWidget.FieldType.CURRENCY,
					label: 'UNAPPLIED AMOUNT'
				});

				var customerDeposite = 0;
				var custId = recObj.getValue({ fieldId: 'entity' });

				var custLookUp = search.lookupFields({
					type: 'customer',
					id: custId,
					columns: ['depositbalance']
				});
				var depsiteBalance = custLookUp.depositbalance;
				if (depsiteBalance) {
					customerDeposite = depsiteBalance;
				}

				var filters =
					[
						[[["custrecord_c58005_customer", "anyof", custId], "AND", ["custrecord_c58005_salesorder.status", "noneof", "SalesOrd:G"], "AND", ["custrecord_c58005_salesorder.mainline", "is", "T"], "AND", ["custrecord_c58005_quotation.status", "noneof", "Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]], "OR", [["custrecord_c58005_customer", "anyof", custId], "AND", ["custrecord_c58005_salesorder", "anyof", "@NONE@"], "AND", ["custrecord_c58005_quotation.status", "noneof", "Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]]],
						"AND",
						["isinactive", "is", "F"],
						"AND",
						["custrecord_c58005_milestone_applied_amt", "isnotempty", ""]
					];

				var columns =
					[
						search.createColumn({ name: "custrecord_c58005_salesorder", label: "Sales Order" }),
						search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" })
					];

				var appliedObj = searchAllRecord('customrecord_c58005_payment_milestone', null, filters, columns);

				var totalApplied = 0;
				var salesArray = [];
				for (var z = 0; z < appliedObj.length; z++) {
					var salesId = appliedObj[z].getValue({ name: "custrecord_c58005_salesorder", label: "Sales Order" });
					var appliedValue = appliedObj[z].getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" });
					totalApplied = parseFloat(totalApplied) + parseFloat(appliedValue);
					var index = salesArray.indexOf(salesId);
					if (index == '-1' && salesId) {
						salesArray.push(salesId);
					}
				}
				log.debug('totalApplied', totalApplied);
				log.debug('appliedObj', appliedObj);
				if (salesArray.length > 0) {
					var invoiceSearchObj = search.create({
						type: "invoice",
						filters:
							[
								["type", "anyof", "CustInvc"],
								"AND",
								["createdfrom", "anyof", salesArray],
								"AND",
								["mainline", "is", "T"]
							],
						columns:
							[
								search.createColumn({ name: "amount", summary: "SUM", label: "Amount" })
							]
					});
					var searchResultCount = invoiceSearchObj.runPaged().count;
					if (searchResultCount > 0) {
						var searchResult = invoiceSearchObj.run().getRange({ start: 0, end: 1 });
						var partialTotal = searchResult[0].getValue({ name: "amount", summary: "SUM", label: "Amount" });
						totalApplied = totalApplied - partialTotal;
					}
				}

				var unapplied = customerDeposite - totalApplied;
				recObj.setValue({ fieldId: 'custpage_deposit_balance', value: customerDeposite, ignoreFieldChange: true });
				recObj.setValue({ fieldId: 'custpage_applied', value: totalApplied, ignoreFieldChange: true });
				recObj.setValue({ fieldId: 'custpage_unapplied', value: unapplied, ignoreFieldChange: true });
			}

			if (context.type === context.UserEventType.VIEW) {
				var sublistField = context.form.getSublist({ id: 'item' });
				var urlField = sublistField.addField({ id: 'custpage_url_field', type: serverWidget.FieldType.URL, label: 'Add Addon' }).linkText = 'Choose Addon';
				var count = recObj.getLineCount({ sublistId: 'item' });
				for (var i = 0; i < count; i++) {
					var urlVal = "https://5676368-sb1.app.netsuite.com/app/site/hosting/scriptlet.nl?script=2273&deploy=1";
					urlVal += "&qid=" + recObj.id;
					urlVal += "&itemid=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
					urlVal += "&linenum=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c61406_line_id', line: i });
					urlVal += "&sio=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_subitem_of', line: i });
					urlVal += "&iv=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_variant', line: i });
					urlVal += "&im=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_model', line: i });
					urlVal += "&lqty=" + recObj.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
					urlVal += "&rec=salesorder";
					recObj.setSublistValue({ sublistId: 'item', fieldId: 'custpage_url_field', value: urlVal, line: i });
				}
			}
		}
		catch (e) { log.error('Error', e) }
	}


	function afterSubmit(context) {
		try {
			var recObj = context.newRecord;

			var lineCnt = recObj.getLineCount({ sublistId: 'custpage_open_milestone_list' });
			//log.debug("lineCnt", lineCnt);

			var paymentArray = [];
			for (var x = 0; x < lineCnt; x++) {
				var markPayment = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment', line: x });
				var appliedTo = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', line: x });
				if (markPayment == 'T' && parseFloat(appliedTo) > 0) {
					var paymentId = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_id', line: x });
					paymentArray.push({ 'paymentId': paymentId, 'appliedTo': appliedTo });
				}
			}
			log.debug("paymentArray", paymentArray);

			if (paymentArray.length > 0) {
				var mrTask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_css_mr_create_payment_app',
					//deploymentId: availableJobId[randomId],
					params: { custscript_c_sp_milestone_data: paymentArray }
				});
				mrTask.submit();
			}

			//Code to re-set Addon price on Sales Order lines if Addons processing checkbox has been set from 'T' to 'F'

			var oldRecord = context.oldRecord;
			var newAddonsProcessing = recObj.getValue('custbody_c60520_addons_processing');
			var oldAddonsProcessing = oldRecord.getValue('custbody_c60520_addons_processing');
			log.debug("oldAddonsProcessing||newAddonsProcessing", oldAddonsProcessing + '||' + newAddonsProcessing);
			if (oldAddonsProcessing == true && newAddonsProcessing == false) {
				var currentRecord = record.load({ type: 'salesorder', id: recObj.id, isDynamic: true });
				var lineCount = currentRecord.getLineCount({ sublistId: 'item' });
				for (var i = 0; i < lineCount; i++) {
					var rate = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'rate', line: i });
					var quantity = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
					var addon = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', line: i })
					var amount = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: i });
					if (amount != (rate * quantity + addon)) {
						// currentRecord.setSublistValue({ sublistId: 'item', fieldId: 'amount', line: i, value: rate * quantity + addon });
						var r = currentRecord.selectLine({ sublistId: 'item', line: i });
						var s = currentRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'amount', value: rate * quantity + addon });
						var t = currentRecord.commitLine({ sublistId: 'item' });
					}
				}
				currentRecord.save();
			}
		}
		catch (e) { log.error('Error', e) }
	}


	function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
		try {
			var arrSearchResults = [];
			var count = 1000,
				min = 0,
				max = 1000;
			var searchObj = false;
			if (recordType == null) {
				recordType = null;
			}
			if (searchId) {
				searchObj = search.load({
					id: searchId
				});
				if (searchFilter) {
					searchObj.filterExpression = searchFilter;
				}
			} else {
				searchObj = search.create({
					type: recordType,
					filters: searchFilter,
					columns: searchColumns
				})
			}

			var rs = searchObj.run();
			//searchColumns.push(rs.columns);
			//allColumns = rs.columns;

			while (count == 1000) {
				var resultSet = rs.getRange({
					start: min,
					end: max
				});
				if (resultSet != null) {
					arrSearchResults = arrSearchResults.concat(resultSet);
					min = max;
					max += 1000;
					count = resultSet.length;
				}
			}
		} catch (e) {
			//log.debug('Error searching for Customer:- ', e.message);
		}
		return arrSearchResults;
	}


	return {
		beforeLoad: beforeLoad,
		afterSubmit: afterSubmit
	};
});
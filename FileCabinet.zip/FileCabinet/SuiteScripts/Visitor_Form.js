/**
 *@NApiVersion 2.0
 *@NScriptType Suitelet
 *@NModuleScope SameAccount
 */

define(['N/ui/serverWidget'],

  function (serverWidget) {
    function onRequest(context) {
      var form = serverWidget.createForm({

        title: 'Visitor Form'

      });

      form.addField({

        id : 'name',
        type: serverWidget.FieldType.TEXT,

        label: 'Name'

      });
      form.addField({

        id : 'dob',
        type: serverWidget.FieldType.DATE,

        label: 'DOB'

      });
      form.addField({

        id : 'city',
        type: serverWidget.FieldType.TEXT,

        label: 'City'

      });
     


      form.addSubmitButton({

        
        id : 'sub_btn',
        label: 'Submit Button',
        functionName : 'createReTestRecord'

        
        
        });

      context.response.writePage(form);
      
      alert("Test Button");

    }

    function createReTestRecord() {
      alert("Test Button!");
  }

    

    return {
      onRequest: onRequest,
      createReTestRecord:createReTestRecord
     
    };

  });
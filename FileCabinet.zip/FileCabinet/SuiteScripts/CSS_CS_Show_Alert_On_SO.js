/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME:CSS_CS_Show_Alert_On_SO.js
* DEVOPS TASK: ENH/, BL/73326
* AUTHOR: Shalini Srivastava
* DATE CREATED: 3 April,2024
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
define(['N/currentRecord','N/record'],function (currentRecord,record){
	var mode;
	function pageInit(context) {
		mode = context.mode;
	}
	function saveRecord(context) {
		try{
			if(mode == 'create' || mode == 'copy'){
				var lines=[];
				var recObj = context.currentRecord;
				var count = recObj.getLineCount('item');	
				var inventoryNotSet = false;
				for(var iter=0; iter<count; iter++){	
					var inventoryDetailSet = recObj.getSublistValue({ sublistId: 'item', fieldId: 'inventorydetailset',line:iter});
					var isNumbered = recObj.getSublistValue({ sublistId: 'item', fieldId: 'isnumbered',line:iter});
					var isSerial = recObj.getSublistValue({ sublistId: 'item', fieldId: 'isserial',line:iter});
					log.debug('DEBUG','inventoryDetailSet: '+inventoryDetailSet+'==='+'isNumbered: '+isNumbered+'==='+'isSerial: '+isSerial);
					if((isNumbered == 'T' || isSerial == 'T') && inventoryDetailSet == 'F'){
						lines.push(iter+1);
						inventoryNotSet = true;
					}
				}
				if(inventoryNotSet){
					alert('Please set invetory details for line '+lines.toString()+' on sales order.');
					return false;
				}
			}
			return true;
		}
		catch(Err){
            console.error(Err);
        }
	}
	return {
		pageInit:pageInit,
		saveRecord: saveRecord
	}
});
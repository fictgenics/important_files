/**
@NApiVersion 2.0
@NScriptType ClientScript
@NModuleScope Public
*/
define([],function() {
	function showMessage() {
		var message = "Hello";
		alert(message);
      	context.currentRecord.setValue({
            fieldId: "title",
            value: "jamin"
        });
    }
	return{
		pageInit: showMessage
	};
});
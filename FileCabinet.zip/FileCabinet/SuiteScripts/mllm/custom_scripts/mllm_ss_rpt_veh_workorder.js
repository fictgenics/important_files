/*
 * Copyright (c) Advectus Solutions Germany GmbH - All Rights Reserved
 * This file is subject to the terms and conditions defined in
 * file 'ADVECTUS_LICENSE.txt', which is part of this source code package.
 *
 * TASK.DATE               WHO     COMMENT
 * DEV701033-120.20210928  MKH     REQ14915 - Milele Print documentation work order side
 */

/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * @name mllm_ss_rpt_veh_workorder.js
 */

 define([
    'N/email',
    'N/file',
    'N/record',
    'N/render',
    'N/runtime',
    'N/https',
    'N/cache',
    'N/search',
    '/SuiteScripts/mllm/mllm_lb_vehicles_references.js',
    '/SuiteScripts/mllm/custom_scripts/mllm_lb_vehicle_prints.js',
    '/.bundle/371731/advs/vehicle/advs_lb_vehicles_references.js',
    '/.bundle/371731/advs/util/advs_lb_trans.js',
    '/.bundle/371731/advs/util/advs_lb_recordtype.js',
  ],
  /**
   * @param {email} email
   * @param {file} file
   * @param {record} record
   * @param {render} render
   * @param {runtime} runtime
   * @param {https} https
   * @param {cache} cache
   * @param {VehRef} VehRef
   * @param {MllmRef} MllmRef
   * @param {VehPrint} VehPrint
   * @param {trans} trans
   * @param {r} r
   */
  
  (email, file, record, render, runtime, https, cache, search, MllmRef, VehPrint, VehRef, trans, r) => {
    /**
    * Definition of the Suitelet script trigger point.
    *
    * @param {Object} context
    * @param {ServerRequest} context.request - Encapsulation of the incoming request
    * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
    * @Since 2015.2
    */
    function onRequest(context) {
      const { request } = context;
  
      // HTTP GET
      if (request.method === https.Method.GET) {
        // LOADING PARAMETERS
        const recordID = context.request.parameters.custpara_recordid;
        const printOption = context.request.parameters.custpara_print_option;
        const chkHideVat = context.request.parameters.custpara_hidevat;
        const chkShowOTotal = context.request.parameters.custpara_showototal;
        const chkShowAddonPrice = context.request.parameters.custpara_showaddonprice_option;
        const chkShowAddon = context.request.parameters.custpara_showaddon_option;
        const recordType = context.request.parameters.custpara_recordtype;
  
        const recordPayPlan = context.request.parameters.custpara_paymentplan;
        const emailObject = context.request.parameters.custpara_email_object;
        const chkWithoutCustomer = context.request.parameters.custpage_chk_withoutcustomer || false; // to hide customer / cost
        const recordTemplate = '/SuiteScripts/mllm/custom_scripts/mllm_ss_rpt_veh_workorder.ftl';
        
  
        const renderer = render.create();
        renderer.templateContent = file.load(recordTemplate).getContents();
  
        const salesRecord = record.load({
          type: recordType,
          id: recordID,
        });
  
        let docLang = salesRecord.getValue({
          fieldId: VehRef.RECORDS.TRANSACTION_BODY.LANGUAGE,
        });
  
        const tranId = salesRecord.getValue({
          fieldId: VehRef.RECORDS.TRANSACTION_BODY.TRANID,
        });
        const customerId = salesRecord.getValue({
          fieldId: VehRef.RECORDS.TRANSACTION_BODY.ENTITY,
        });
        docLang = trans.getLanguageMap(docLang);
        trans.InitializeLanguage(docLang);
  
        // const printTitle = PrintMgt.GetPrintTitle(recordType);
        const printTitle = trans.translateFromCollection('SPECIFIC_1146', null, 'mllm');
  
        renderer.addRecord({
          templateName: 'record',
          record: salesRecord,
        });
  
        // ADDING DATA TO REPORT
        const DataSource = VehPrint.ReportData(recordID, recordType, chkHideVat, chkShowOTotal, recordPayPlan, context, chkShowAddonPrice, chkShowAddon);
        DataSource.forEach((obj) => {
          renderer.addCustomDataSource({
            format: render.DataSource.OBJECT,
            alias: obj.alias,
            data: obj.data,
          });
        });
        // WORKORDER FIELDS
        const obWorkOrder = search.lookupFields({
          type: search.Type.PURCHASE_ORDER,
          id: recordID,
          columns: [
            MllmRef.RECORDS.WORKORDER.WO_SALESPERSON,
            MllmRef.RECORDS.WORKORDER.WO_SALESORDER,
            MllmRef.RECORDS.WORKORDER.WO_VEHMODEL,
            MllmRef.RECORDS.WORKORDER.WO_CUSTOMER,
            MllmRef.RECORDS.WORKORDER.WO_VEHVIN,
            MllmRef.RECORDS.WORKORDER.WO_JOBCOMPLETE,
          ],
        });
        const salesOrder = obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESORDER].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESORDER][0].value : '';
        const vehicleId = obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHVIN].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHVIN][0].value : '';
        const objWorkOrder = {
          SALESPERSON: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESPERSON].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESPERSON][0].text : '',
          SALESORDER: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESORDER].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_SALESORDER][0].text : '',
          VEHMODEL: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHMODEL].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHMODEL][0].text : '',
          CUSTOMER: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_CUSTOMER].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_CUSTOMER][0].text : '',
          VEHVIN: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHVIN].length > 0 ? obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_VEHVIN][0].text : '',
          JOBCOMPLETEDATE: obWorkOrder[MllmRef.RECORDS.WORKORDER.WO_JOBCOMPLETE] || '',
          WITHOUTCUSTOMER: chkWithoutCustomer || false,
        };
        renderer.addCustomDataSource({
          format: render.DataSource.OBJECT,
          alias: 'WORKORDER',
          data: objWorkOrder,
        });
        // VEHICLE FIELDS
        if (vehicleId) {
          const oVehicle = search.lookupFields({
            type: VehRef.RECORDS.VEHICLE.RecordId,
            id: vehicleId,
            columns: [
              VehRef.RECORDS.VEHICLE.ENGINE_NUMBER,
              VehRef.RECORDS.VEHICLE.COUNTRY,
              VehRef.RECORDS.VEHICLE.VIN,
            ],
          });
          const objVehicle = {
            VIN: oVehicle[VehRef.RECORDS.VEHICLE.VIN] || '',
            ENGINENUM: oVehicle[VehRef.RECORDS.VEHICLE.ENGINE_NUMBER] || '',
            COUNTRY: oVehicle[VehRef.RECORDS.VEHICLE.COUNTRY].length > 0 ? oVehicle[VehRef.RECORDS.VEHICLE.COUNTRY][0].text : '',
          };
          renderer.addCustomDataSource({
            format: render.DataSource.OBJECT,
            alias: 'WOVEHICLE',
            data: objVehicle,
          });
        }
        // SALES ORDER FIELDS
        if (salesOrder) {
          const oSalesOrder = search.lookupFields({
            type: search.Type.SALES_ORDER,
            id: salesOrder,
            columns: [
              VehRef.RECORDS.TRANSACTION_BODY.EXPECTED_DATE,
              VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_CONSIGNEE,
              VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_DEST_COUNTRY,
              VehRef.RECORDS.TRANSACTION_BODY.SHIPP_METHOD,
              VehRef.RECORDS.TRANSACTION_BODY.SHIP_DATE,
              VehRef.RECORDS.TRANSACTION_BODY.ACTUALSHIPDATE,
              MllmRef.RECORDS.WORKORDER.WO_PORTLOADING,
              MllmRef.RECORDS.WORKORDER.WO_PORTDISCHARGE,
            ],
          });
          const objSalesOrder = {
            // SHIPMENTMETHOD: oSalesOrder.shipmentmethod || '',
            EXPECTED_DATE: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.EXPECTED_DATE] || '',
            CONSIGNEE: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_CONSIGNEE].length > 0 ? oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_CONSIGNEE][0].text : '',
            DEST_COUNTRY: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_DEST_COUNTRY].length > 0 ? oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_DEST_COUNTRY][0].text : '',
            SHIP_METHOD: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.SHIPP_METHOD].length > 0 ? oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.SHIPP_METHOD][0].text : '',
            SHIPDATE: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.SHIP_DATE] || '',
            ACTUALSHIPDATE: oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.ACTUALSHIPDATE] || '',
            PORTLOADING: oSalesOrder[MllmRef.RECORDS.WORKORDER.WO_PORTLOADING].length > 0 ? oSalesOrder[MllmRef.RECORDS.WORKORDER.WO_PORTLOADING][0].text : '',
            PORTDISCHARGE: oSalesOrder[MllmRef.RECORDS.WORKORDER.WO_PORTDISCHARGE].length > 0 ? oSalesOrder[MllmRef.RECORDS.WORKORDER.WO_PORTDISCHARGE][0].text : '',
          };
          renderer.addCustomDataSource({
            format: render.DataSource.OBJECT,
            alias: 'WOSALESORDER',
            data: objSalesOrder,
          });
  
          const consigneeId = oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_CONSIGNEE].length > 0 ? oSalesOrder[VehRef.RECORDS.TRANSACTION_BODY.PROFORMAINV_CONSIGNEE][0].value : '';
          // CONSIGNEE DETAIL
          if (consigneeId) {
            const oConsignee = search.lookupFields({
              type: r.ShipConsignee.recordId,
              id: consigneeId,
              columns: [
                r.ShipConsignee.name,
                r.ShipConsignee.ConsigneeContact,
                r.ShipConsignee.ConsigneeEmail,
              ],
            });
            const objConsignee = {
              NAME: oConsignee[r.ShipConsignee.name] || '',
              CONTACT: oConsignee[r.ShipConsignee.ConsigneeContact] || '',
              EMAIL: oConsignee[r.ShipConsignee.ConsigneeEmail] || '',
            };
            renderer.addCustomDataSource({
              format: render.DataSource.OBJECT,
              alias: 'WOCONSIGNEE',
              data: objConsignee,
            });
          }
        }
  
        const newfile = renderer.renderAsPdf();
        newfile.name = `${printTitle} #${tranId}.pdf`;
  
        if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.PRINT || printOption === VehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
          context.response.writeFile({
            file: newfile,
            isInline: false,
          });
        }
        if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.EMAIL || printOption === VehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
          const emailObj = JSON.parse(emailObject);
          let Body = '';
          let Subject = '';
          if (emailObj) {
            const emailTempFld = emailObj.emailtemplate;
  
            if (emailTempFld) {
              const newEmailTemplate = record.load({
                type: VehRef.RECORDS.EMAIL_TEMPLATE.RecordId,
                id: emailTempFld,
                isDynamic: true,
                defaultValues: true,
              });
              Body = newEmailTemplate.getValue(VehRef.RECORDS.EMAIL_TEMPLATE.SUBJECT);
              Subject = newEmailTemplate.getValue(VehRef.RECORDS.EMAIL_TEMPLATE.CONTENT);
  
              const mergeResultObj = render.mergeEmail({
                templateId: emailTempFld,
                entity: {
                  type: 'employee',
                  id: runtime.getCurrentUser().id,
                },
                recipient: {
                  type: VehRef.RECORDS.CUSTOMER.RECORDID,
                  id: customerId * 1,
                },
                supportCaseId: null,
                transactionId: recordID * 1,
                custmRecord: null,
              });
              Body = mergeResultObj.body;
              Subject = mergeResultObj.subject;
            }
  
            email.send({
              author: emailObj.author,
              recipients: emailObj.recipients,
              cc: emailObj.cc,
              bcc: emailObj.bcc,
              subject: Subject,
              body: Body,
              relatedRecords: {
                entityId: customerId,
                transactionId: recordID,
              },
              attachments: [
                newfile,
              ],
              // relatedRecords: emailObj.relatedRecords,
            });
          }
        }
  
        if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.EMAIL) {
          let onclickScript = " <html><body> <script type='text/javascript'>try{";
          onclickScript += 'window.close();';
          onclickScript += "}catch(e){alert(e+'   '+e.message);}</script></body></html>";
          context.response.write(onclickScript);
        }
      }
    }
  
    return {
      onRequest,
    };
  });
  
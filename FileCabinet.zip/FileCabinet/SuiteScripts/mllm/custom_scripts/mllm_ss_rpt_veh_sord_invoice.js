/*
 * Copyright (c) Advectus Solutions Germany GmbH - All Rights Reserved
 * This file is subject to the terms and conditions defined in
 * file 'ADVECTUS_LICENSE.txt', which is part of this source code package.
 *
 * TASK.DATE               WHO     COMMENT
 * DEV701033-127.20210101  MKH     REQ15391: Milele CFD_3.3 Vehicle Sales Invoice
 */

/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 * @name mllm_ss_rpt_veh_sord_invoice.js
 */

define([
  'N/email',
  'N/file',
  'N/record',
  'N/render',
  'N/runtime',
  'N/https',
  'N/cache',
  '/.bundle/371731/advs/vehicle/advs_lb_vehicles_references.js',
  '/SuiteScripts/mllm/custom_scripts/mllm_lb_vehicle_prints.js',
  '/.bundle/371731/advs/util/advs_lb_trans.js',
],
/**
 * @param {email} email
 * @param {file} file
 * @param {record} record
 * @param {render} render
 * @param {runtime} runtime
 * @param {https} https
 * @param {cache} cache
 * @param {VehRef} VehRef
 * @param {VehPrint} VehPrint
 * @param {trans} trans
 */

(email, file, record, render, runtime, https, cache, VehRef, VehPrint, trans) => {
  /**
  * Definition of the Suitelet script trigger point.
  *
  * @param {Object} context
  * @param {ServerRequest} context.request - Encapsulation of the incoming request
  * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
  * @Since 2015.2
  */
  function onRequest(context) {
    const { request } = context;

    // HTTP GET
    if (request.method === https.Method.GET) {
      // LOADING PARAMETERS
      const recordID = context.request.parameters.custpara_recordid;
      const printOption = context.request.parameters.custpara_print_option;
      const chkHideVat = context.request.parameters.custpara_hidevat;
      const chkShowOTotal = context.request.parameters.custpara_showototal;
      const chkShowAddonPrice = context.request.parameters.custpara_showaddonprice_option;
      const chkShowAddon = context.request.parameters.custpara_showaddon_option;
      const recordType = context.request.parameters.custpara_recordtype;

      const recordPayPlan = context.request.parameters.custpara_paymentplan;
      const emailObject = context.request.parameters.custpara_email_object;
      const recordTemplate = '/SuiteScripts/mllm/custom_scripts/mllm_ss_rpt_veh_sord_invoice.ftl';

      const renderer = render.create();
      renderer.templateContent = file.load(recordTemplate).getContents();

      const salesRecord = record.load({
        type: recordType,
        id: recordID,
      });

      let docLang = salesRecord.getValue({
        fieldId: VehRef.RECORDS.TRANSACTION_BODY.LANGUAGE,
      });

      const tranId = salesRecord.getValue({
        fieldId: VehRef.RECORDS.TRANSACTION_BODY.TRANID,
      });
      const customerId = salesRecord.getValue({
        fieldId: VehRef.RECORDS.TRANSACTION_BODY.ENTITY,
      });
      docLang = trans.getLanguageMap(docLang);
      trans.InitializeLanguage(docLang);

      // const printTitle = PrintMgt.GetPrintTitle(recordType);
      const printTitle = trans.translateFromCollection('SPECIFIC_1185', null, 'mllm');

      renderer.addRecord({
        templateName: 'record',
        record: salesRecord,
      });

      // ADDING DATA TO REPORT
      const DataSource = VehPrint.ReportData(recordID, recordType, chkHideVat, chkShowOTotal, recordPayPlan, request.parameters, chkShowAddonPrice, chkShowAddon);
      DataSource.forEach((obj) => {
        renderer.addCustomDataSource({
          format: render.DataSource.OBJECT,
          alias: obj.alias,
          data: obj.data,
        });
      });

      const newfile = renderer.renderAsPdf();
      newfile.name = `${printTitle} #${tranId}.pdf`;

      if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.PRINT || printOption === VehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
        context.response.writeFile({
          file: newfile,
          isInline: false,
        });
      }
      if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.EMAIL || printOption === VehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
        const emailObj = JSON.parse(emailObject);
        let Body = '';
        let Subject = '';
        if (emailObj) {
          const emailTempFld = emailObj.emailtemplate;

          if (emailTempFld) {
            const newEmailTemplate = record.load({
              type: VehRef.RECORDS.EMAIL_TEMPLATE.RecordId,
              id: emailTempFld,
              isDynamic: true,
              defaultValues: true,
            });
            Body = newEmailTemplate.getValue(VehRef.RECORDS.EMAIL_TEMPLATE.SUBJECT);
            Subject = newEmailTemplate.getValue(VehRef.RECORDS.EMAIL_TEMPLATE.CONTENT);

            const mergeResultObj = render.mergeEmail({
              templateId: emailTempFld,
              entity: {
                type: 'employee',
                id: runtime.getCurrentUser().id,
              },
              recipient: {
                type: VehRef.RECORDS.CUSTOMER.RECORDID,
                id: customerId * 1,
              },
              supportCaseId: null,
              transactionId: recordID * 1,
              custmRecord: null,
            });
            Body = mergeResultObj.body;
            Subject = mergeResultObj.subject;
          }

          email.send({
            author: emailObj.author,
            recipients: emailObj.recipients,
            cc: emailObj.cc,
            bcc: emailObj.bcc,
            subject: Subject,
            body: Body,
            relatedRecords: {
              entityId: customerId,
              transactionId: recordID,
            },
            attachments: [
              newfile,
            ],
            // relatedRecords: emailObj.relatedRecords,
          });
        }
      }

      if (printOption === VehRef.LABELS.SALES_PRINT.OPTION.EMAIL) {
        let onclickScript = " <html><body> <script type='text/javascript'>try{";
        onclickScript += 'window.close();';
        onclickScript += "}catch(e){alert(e+'   '+e.message);}</script></body></html>";
        context.response.write(onclickScript);
      }
    }
  }

  return {
    onRequest,
  };
});

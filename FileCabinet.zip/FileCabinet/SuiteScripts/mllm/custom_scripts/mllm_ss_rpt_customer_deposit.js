/*
 * Copyright (c) Advectus Solutions Germany GmbH - All Rights Reserved
 * This file is subject to the terms and conditions defined in
 * file 'ADVECTUS_LICENSE.txt', which is part of this source code package.
 *
 * TASK.DATE                WHO    COMMENT
 * MAI652021-875.20220303   MKH    Customer Deposit Printout
 */
/**
 *@NApiVersion 2.1
 *@NScriptType Suitelet
 *@NModuleScope SameAccount
 *@name mllm_ss_rpt_customer_deposit.js
 */
define([
  'N/email',
  'N/file',
  'N/record',
  'N/render',
  'N/runtime',
  'N/http',
  'N/error',
  'N/ui/serverWidget',
  '/.bundle/371731/advs/vehicle/advs_lb_vehicles_references.js',
  '/SuiteScripts/mllm/custom_scripts/mllm_lb_vehicle_prints.js',
  '/.bundle/371731/advs/util/advs_lb_trans.js',
],
/**
 * @param {email} email
 * @param {file} file
 * @param {record} record
 * @param {render} render
 * @param {runtime} runtime
 * @param {http} http
 * @param {error} error
 * @param {serverWidget} serverWidget
 * @param {vehRef} vehRef
 * @param {vehPrint} vehPrint
 * @param {trans} trans
*/
(email, file, record, render, runtime, http, error, serverWidget, vehRef, vehPrint, trans) => {
  const RECORD_TEMPLATE = '/SuiteScripts/mllm/custom_scripts/mllm_customer_deposit.ftl';

  function initializeLanguage(docLang) {
    const mappedDocLang = trans.getLanguageMap(docLang);
    trans.InitializeLanguage(mappedDocLang);
  }

  function getValue(recordObj, recFieldId) {
    return recordObj.getValue({
      fieldId: recFieldId,
    });
  }

  function loadRecord(recordType, recordId) {
    return record.load({
      type: recordType,
      id: recordId,
    });
  }

  function getReceiptDataObj(receiptRecord) {
    const object = {};
    object.customerId = getValue(receiptRecord, vehRef.RECORDS.TRANSACTION_BODY.CUSTOMER);
    object.docLang = getValue(receiptRecord, vehRef.RECORDS.TRANSACTION_BODY.LANGUAGE);
    object.tranId = getValue(receiptRecord, vehRef.RECORDS.TRANSACTION_BODY.TRANID);
    return object;
  }

  function handleGet(context) {
    const { request } = context;
    const {
      custpara_recordid: recordId,
      custpara_recordtype: recordType,
      custpara_print_option: printOption,
      custpara_email_object: emailObjectParam,
      custpara_showaddonprice_option: showAddonPrice,
    } = request.parameters;

    const renderer = render.create();
    renderer.templateContent = file.load(RECORD_TEMPLATE).getContents();

    const receiptRecord = loadRecord(recordType, recordId);

    const receiptDataObj = getReceiptDataObj(receiptRecord);

    initializeLanguage(receiptDataObj.docLang);
    const printTitle = trans.translate('OTHERUI_2502');

    renderer.addRecord({
      templateName: 'record',
      record: receiptRecord,
    });
    const dataSource = vehPrint.ReportData(recordId, recordType, '', '', '', '', showAddonPrice || 'false');
    dataSource.forEach((obj) => {
      renderer.addCustomDataSource({
        format: render.DataSource.OBJECT,
        alias: obj.alias,
        data: obj.data,
      });
    });
    let newfile = '';
    if (Number(printOption) === Number(vehRef.LABELS.SALES_PRINT.OPTION.RAW)) {
      newfile = renderer.renderAsString();
      context.response.write({
        output: newfile,
      });
    } else if (Number(printOption) === Number(vehRef.LABELS.SALES_PRINT.OPTION.DATASOURCE)) {
      const myPageObj = serverWidget.createList({
        title: 'Data Sources',
      });

      myPageObj.addColumn({
        id: 'alias',
        type: serverWidget.FieldType.TEXT,
        label: 'Alias',
      });

      myPageObj.addColumn({
        id: 'data',
        type: serverWidget.FieldType.TEXT,
        label: 'Data',
      });

      for (let i = 0; i < dataSource.length; i += 1) {
        myPageObj.addRow({
          row: {
            alias: dataSource[i].alias,
            data: JSON.stringify(dataSource[i].data),
          },
        });
      }
      context.response.writePage({
        pageObject: myPageObj,
      });
    } else {
      newfile = renderer.renderAsPdf();
      newfile.name = `${printTitle} #${receiptDataObj.tranId}.pdf`;
    }

    if (printOption === vehRef.LABELS.SALES_PRINT.OPTION.PRINT || printOption === vehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
      context.response.writeFile({
        file: newfile,
        isInline: false,
      });
    }

    if (printOption === vehRef.LABELS.SALES_PRINT.OPTION.EMAIL || printOption === vehRef.LABELS.SALES_PRINT.OPTION.BOTH) {
      const emailObj = JSON.parse(emailObjectParam);
      if (emailObj) {
        const emailTempFld = emailObj.emailtemplate;

        let body;
        let subject;
        if (emailTempFld) {
          const newEmailTemplate = record.load({
            type: vehRef.RECORDS.EMAIL_TEMPLATE.RecordId,
            id: emailTempFld,
            isDynamic: true,
            defaultValues: true,
          });
          body = newEmailTemplate.getValue(vehRef.RECORDS.EMAIL_TEMPLATE.SUBJECT);
          subject = newEmailTemplate.getValue(vehRef.RECORDS.EMAIL_TEMPLATE.CONTENT);

          const mergeResultObj = render.mergeEmail({
            templateId: emailTempFld,
            entity: {
              type: vehRef.CONSTANTS.EMPLOYEE,
              id: runtime.getCurrentUser().id,
            },
            recipient: {
              type: vehRef.RECORDS.CUSTOMER.RECORDID,
              id: receiptDataObj.customerId * 1,
            },
            supportCaseId: null,
            transactionId: recordId * 1,
            custmRecord: null,
          });
          body = mergeResultObj.body;
          subject = mergeResultObj.subject;
        }

        email.send({
          author: emailObj.author,
          recipients: emailObj.recipients,
          cc: emailObj.cc,
          bcc: emailObj.bcc,
          subject,
          body,
          relatedRecords: {
            entityId: receiptDataObj.customerId,
            transactionId: recordId,
          },
          attachments: [
            newfile,
          ],
        });
      }
    }

    if (printOption === vehRef.LABELS.SALES_PRINT.OPTION.EMAIL) {
      let onclickScript = " <html><body> <script type='text/javascript'>try{";
      onclickScript += 'window.close();';
      onclickScript += "}catch(e){alert(e+'   '+e.message);}</script></body></html>";
      context.response.write(onclickScript);
    }
  }

  function handleError() {
    throw error.create({
      name: trans.translate(vehRef.ERRORS_MSG.UNSUPPORTED_REQUEST_TYPE),
      message: trans.translate(vehRef.ERRORS_MSG.ONLY_GET_AND_POST),
      notifyOff: true,
    });
  }

  /**
    * Definition of the Suitelet script trigger point.
    * @param {Object} context
    * @param {ServerRequest} context.request - Encapsulation of the incoming request
    * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
    * @Since 2015.2
  */
  function onRequest(context) {
    const eventRouter = {};
    eventRouter[http.Method.GET] = handleGet;

    if (eventRouter[context.request.method]) {
      eventRouter[context.request.method](context);
    } else {
      handleError(context);
    }
  }

  return {
    onRequest,
  };
});

/**
    * @NApiVersion 2.x
    * @NScriptType UserEventScript
    * @NModuleScope SameAccount
*/
/**
    * Script Name          : CSS UE WORK ORDER PHASE  
    * Author               : Naim
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Discription          : This script link the relative work order phase and split the work order phase based on certain conditions.
    * Version              : 2.0
*/
define(['N/search', 'N/record'],

    function (search, record) {

        /**
            * Function definition to be triggered before record is loaded.
            *
            * @param {Object} scriptContext
            * @param {Record} scriptContext.newRecord - New record
            * @param {string} scriptContext.type - Trigger type
            * @param {Form} scriptContext.form - Current form
            * @Since 2015.2
        */

        function beforeLoad(scriptContext) {
            try {
                var recObj = scriptContext.newRecord;
                var orderstatus = recObj.getValue({ fieldId: 'orderstatus' });
				var addonsProcess = recObj.getValue({ fieldId: 'custbody_c60520_addons_processing' });
                if (addonsProcess && orderstatus != 'A') {
                    var custForm = scriptContext.form;
                    custForm.removeButton({ id: 'requestfulfillment' });

                }

                if (!addonsProcess && scriptContext.type == scriptContext.UserEventType.VIEW) {
					var custForm = scriptContext.form;
                    custForm.clientScriptModulePath = './css_cs_addons.js';
                    custForm.addButton({ id: 'custpage_addons', label: 'ADDONS', functionName: "addons(" + recObj.id + ")" });
                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }


        function afterSubmit(context) {
            try {
                var recObj = context.newRecord;
                if (context.type == context.UserEventType.CREATE) {
                    var createdFrom = recObj.getValue({ fieldId: 'createdfrom' });
                    log.debug("createdFrom", createdFrom);

                    if (createdFrom) {
                        var soId = recObj.id;
                        var customrecord_c60520_order_addonsSearchObj = search.create({
                            type: "customrecord_c60520_order_addons",
                            filters:
                                [
                                    ["custrecord9", "anyof", createdFrom]
                                ],
                            columns:
                                [
                                    search.createColumn({ name: "internalid", label: "Internal ID" })
                                ]
                        });
                        var searchResultCount = customrecord_c60520_order_addonsSearchObj.runPaged().count;
                        log.debug("customrecord_c60520_order_addonsSearchObj result count", searchResultCount);
                        customrecord_c60520_order_addonsSearchObj.run().each(function (result) {
                            var addOnId = result.getValue({ name: "internalid", label: "Internal ID" });

                            var objRecord = record.copy({
                                type: 'customrecord_c60520_order_addons',
                                id: addOnId,
                                isDynamic: true
                            });

                            objRecord.setValue({ fieldId: 'custrecord9', value: soId, ignoreFieldChange: true });
                            var newRecId = objRecord.save({ ignoreMandatoryFields: true });
                            log.debug("newRecId", newRecId);

                            return true;
                        });

                    }
                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }

        return {
            beforeLoad: beforeLoad,
            afterSubmit: afterSubmit
        };

    });	
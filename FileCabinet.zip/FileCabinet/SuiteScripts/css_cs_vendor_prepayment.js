/**
    * @NApiVersion 2.x
    * @NScriptType ClientScript
    * @NModuleScope Public
    * @record custom lease record
*/
define(['N/search'], function (search) {

    /** 
        * Function to be executed after page is initialized.
        * @param {Object} scriptContext
        * @param {Record} scriptContext.currentRecord - Current form record
        * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
        * @since 2015.2
    */
    var remainAmt = '';
	var payAmt = '';
    function pageInit(context) {
        if (context.mode == 'create') {
            var currentRecord = context.currentRecord;
            var urlToParse = location.search;
            var result = parseQueryString(urlToParse);
            var milestoneId = result.milestone;

            if (milestoneId) {
                var milestoneSearchObj = search.create({
                    type: "customrecord_c59306_purchase_milestone",
                    filters:
                        [
                            ["internalid", "anyof", milestoneId]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "custrecord_c59306_vendor", label: "Vendor " }),
                            search.createColumn({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" }),
							search.createColumn({ name: "custrecord_c59306_milestone_amount", label: "custrecord_c59306_milestone_amount" })
                        ]
                });
                var searchResultCount = milestoneSearchObj.runPaged().count;
                if (searchResultCount > 0) {
                    var searchResult = milestoneSearchObj.run().getRange({ start: 0, end: 1 });
                    var vendorId = searchResult[0].getValue({ name: "custrecord_c59306_vendor", label: "Vendor " });
					payAmt = searchResult[0].getValue({ name: "custrecord_c59306_milestone_amount", label: "custrecord_c59306_milestone_amount" });
                    remainAmt = searchResult[0].getValue({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" });
                    currentRecord.setValue({ fieldId: 'entity', value: vendorId, ignoreFieldChange: false });
                    currentRecord.setValue({ fieldId: 'custbody_c59306__purchase_milestone', value: milestoneId, ignoreFieldChange: true });
                }
            }
        }

        return true;
    }

    function postSourcing(context) {
        if (context.fieldId == 'entity') {
            if (payAmt) {
                var currentRecord = context.currentRecord;
                currentRecord.setValue({ fieldId: 'payment', value: payAmt, ignoreFieldChange: true });
                currentRecord.setValue({ fieldId: 'approvalstatus', value: 2, ignoreFieldChange: true });
            }
        }
    }


    function parseQueryString(url) {
        var urlParams = {};
        url.replace(
            new RegExp("([^?=&]+)(=([^&]*))?", "g"),
            function ($0, $1, $2, $3) {
                urlParams[$1] = $3;
            }
        );
        return urlParams;
    }

    return {
        pageInit: pageInit,
        postSourcing: postSourcing
    };

});	
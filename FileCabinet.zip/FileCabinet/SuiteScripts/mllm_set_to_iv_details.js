function after_Submit() 
{
    try
    {	
		// Open the Transfer Order record
		var s_rec_type = nlapiGetRecordType();
		var i_rec_id = nlapiGetRecordId();
			
		var record2= nlapiLoadRecord(s_rec_type, i_rec_id);
		var rec2 = "";

		//get the number of items from the sales order
		var toItem = record2.getLineItemCount('item');

		for(var x=1; x <= toItem; x++ ) 
		{
			record2.selectLineItem('item', x);
			var invDetailSubrecord = record2.viewCurrentLineItemSubrecord('item', 'inventorydetail');
			record2.removeCurrentLineItemSubrecord('item', 'inventorydetail');
			record2.commitLineItem('item');
		}
		record2.commitLineItem('item');
		
		//loop for all the items
		//create a new inventory detail subrecord
		//setting the values from the Item Fulfillment
		for(var i=1; i <= toItem; i++ )
		{
			var vin = record2.getLineItemValue('item', 'custcol_advs_veh_vin', i);
			nlapiLogExecution( 'DEBUG', 'vin', vin );
			record2.selectLineItem('item', i);
	
			if (vin)
			{
				var itemSubRecord = record2.createCurrentLineItemSubrecord('item', 'inventorydetail');
				itemSubRecord.selectNewLineItem('inventoryassignment');
				itemSubRecord.setCurrentLineItemValue('inventoryassignment', 'quantity', '1' );
				itemSubRecord.setCurrentLineItemText('inventoryassignment', 'issueinventorynumber', vin);
				itemSubRecord.commitLineItem('inventoryassignment');  
				itemSubRecord.commit();
				record2.commitLineItem('item');
			}
		}
		record2.commitLineItem('item');

		var id = nlapiSubmitRecord(record2);

    }
    catch(e)
    {
        if ( e instanceof nlobjError )
            nlapiLogExecution( 'DEBUG', 'system error', e.getCode() + '\n' + e.getDetails() );
        else
            nlapiLogExecution( 'DEBUG', 'unexpected error', e.toString() );
    }
}
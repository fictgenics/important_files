/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED:
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/record', 'N/ui/serverWidget', 'N/search', 'N/task', 'N/query'], function (record, serverWidget, search, task, query) {

	function beforeLoad(context) {
		try {
			var custForm = context.form;
			var recObj = context.newRecord;

			//log.debug('context.type', context.type);
			if (context.type == 'edit') {
				var tab = custForm.addTab({
					id: 'custpage_open_milestone',
					label: 'Open Milestone'
				});

				var sublist = custForm.addSublist({
					id: 'custpage_open_milestone_list',
					type: serverWidget.SublistType.INLINEEDITOR,
					label: 'Open Milestone List',
					tab: 'custpage_open_milestone'
				});

				sublist.addField({
					id: 'custpage_mark_payment',
					type: serverWidget.FieldType.CHECKBOX,
					label: 'MARK PAYMENT'
				});

				var paymentMilestone = sublist.addField({
					id: 'custpage_payment_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});
				paymentMilestone.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var salesOrder = sublist.addField({
					id: 'custpage_purchase_order',
					type: serverWidget.FieldType.TEXT,
					label: 'PURCHASE ORDER'
				});
				salesOrder.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });
				
				var inboundShip = sublist.addField({
					id: 'custpage_inbound_shipment',
					type: serverWidget.FieldType.TEXT,
					label: 'INBOUND SHIPMENT'
				});
                inboundShip.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });
				
				var itemRece = sublist.addField({
					id: 'custpage_item_receipt',
					type: serverWidget.FieldType.TEXT,
					label: 'ITEM RECEIPT'
				});
				 itemRece.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });
				
				var milestoneType = sublist.addField({
					id: 'custpage_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});
				milestoneType.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestonePercent = sublist.addField({
					id: 'custpage_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});
				milestonePercent.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var milestoneAmount = sublist.addField({
					id: 'custpage_milestone_amount',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE AMOUNT'
				});
				milestoneAmount.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var currentApplied = sublist.addField({
					id: 'custpage_current_applied',
					type: serverWidget.FieldType.TEXT,
					label: 'CURRENT APPLIED'
				});
				currentApplied.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var amountRemaining = sublist.addField({
					id: 'custpage_amount_remaining',
					type: serverWidget.FieldType.TEXT,
					label: 'REMAIN AMOUNT'
				});
				amountRemaining.updateDisplayType({ displayType: serverWidget.FieldDisplayType.DISABLED });

				var appliedNow = sublist.addField({
					id: 'custpage_applied_now',
					type: serverWidget.FieldType.TEXT,
					label: 'APPLIED NOW'
				});


				var milestoneId = sublist.addField({
					id: 'custpage_milestone_id',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE Id'
				});
				milestoneId.updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });

				var customrecord_c58005_payment_milestoneSearchObj = search.create({
					type: "customrecord_c59306_purchase_milestone",
					filters:
						[
							["custrecord_c59306_purchase_miles_type", "anyof", "1", "2", "3", "4"],
							"AND",
							["custrecord_c59306_milestone_remain_amt", "greaterthan", "0.00"],
							"AND",
							["custrecord_c59306_vendor", "anyof", recObj.id]
						],
					columns:
						[
							search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
							search.createColumn({ name: "name", label: "Name" }),
							search.createColumn({ name: "custrecord_c59306_purchase_order", label: "Purchase Order" }),
							search.createColumn({ name: "custrecord_c59306_purchase_miles_type", label: "Purchase Milestone Type" }),
							search.createColumn({ name: "custrecord_c59306_milestone", label: "Milestone %" }),
							search.createColumn({ name: "custrecord_c59306_milestone_amount", label: "Milestone Amount" }),
							search.createColumn({ name: "custrecord_c59306_milestone_applied_amt", label: "Milestone Applied Amount" }),
							search.createColumn({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" }),
							search.createColumn({ name: "custrecord_c59306_inbound_shipment", label: "custrecord_c59306_inbound_shipment" }),
							search.createColumn({ name: "custrecord_c59306_item_receipt", label: "custrecord_c59306_item_receipt" })

						]
				});
				var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
				//log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
				var count = 0;
				customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
					var milestoneName = result.getValue({ name: "name", label: "Name" });
					var purchaseOrder = result.getText({ name: "custrecord_c59306_purchase_order", label: "Purchase Order" });
					var milestoneTypeVal = result.getText({ name: "custrecord_c59306_purchase_miles_type", label: "Purchase Milestone Type" });
					var milestonePercentVal = result.getValue({ name: "custrecord_c59306_milestone", label: "Milestone %" });
					var milestoneAmountVal = result.getValue({ name: "custrecord_c59306_milestone_amount", label: "Milestone Amount" });
					var currentAppliedVal = result.getValue({ name: "custrecord_c59306_milestone_applied_amt", label: "Milestone Applied Amount" });
					var remainAmt = result.getValue({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" });
					var milestoneValue = result.getValue({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" });
					var inboundShipment = result.getText({ name: "custrecord_c59306_inbound_shipment", label: "custrecord_c59306_inbound_shipment" });
					var itemReceipt = result.getText({ name: "custrecord_c59306_item_receipt", label: "custrecord_c59306_item_receipt" });

					if (!currentAppliedVal) {
						currentAppliedVal = 0;
					}
					
					if (!inboundShipment) {
						inboundShipment = '-';
					}
					
					if (!itemReceipt) {
						itemReceipt = '-';
					}

					sublist.setSublistValue({ id: 'custpage_payment_milestone', line: count, value: milestoneName });
					sublist.setSublistValue({ id: 'custpage_purchase_order', line: count, value: purchaseOrder });
					sublist.setSublistValue({ id: 'custpage_inbound_shipment', line: count, value: inboundShipment });
					sublist.setSublistValue({ id: 'custpage_item_receipt', line: count, value: itemReceipt });
					sublist.setSublistValue({ id: 'custpage_milestone_type', line: count, value: milestoneTypeVal });
					sublist.setSublistValue({ id: 'custpage_milestone_percent', line: count, value: milestonePercentVal });
					sublist.setSublistValue({ id: 'custpage_milestone_amount', line: count, value: String(milestoneAmountVal).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_current_applied', line: count, value: String(currentAppliedVal).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_amount_remaining', line: count, value: String(remainAmt).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_milestone_id', line: count, value: milestoneValue });
					count++;
					return true;
				});
			}
			else if (context.type == 'view') {
				var tab = custForm.addTab({
					id: 'custpage_open_milestone',
					label: 'Open Milestone'
				});

				var sublist = custForm.addSublist({
					id: 'custpage_open_milestone_list',
					type: serverWidget.SublistType.LIST,
					label: 'Open Milestone List',
					tab: 'custpage_open_milestone'
				});

				var paymentMilestone = sublist.addField({
					id: 'custpage_payment_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});

				var salesOrder = sublist.addField({
					id: 'custpage_purchase_order',
					type: serverWidget.FieldType.TEXT,
					label: 'PURCHASE ORDER'
				});
				
				var salesOrder = sublist.addField({
					id: 'custpage_inbound_shipment',
					type: serverWidget.FieldType.TEXT,
					label: 'INBOUND SHIPMENT'
				});
				
				var salesOrder = sublist.addField({
					id: 'custpage_item_receipt',
					type: serverWidget.FieldType.TEXT,
					label: 'ITEM RECEIPT'
				});

				var milestoneType = sublist.addField({
					id: 'custpage_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});

				var milestonePercent = sublist.addField({
					id: 'custpage_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});

				var milestoneAmount = sublist.addField({
					id: 'custpage_milestone_amount',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE AMOUNT'
				});

				var currentApplied = sublist.addField({
					id: 'custpage_current_applied',
					type: serverWidget.FieldType.TEXT,
					label: 'CURRENT APPLIED'
				});

				var amountRemaining = sublist.addField({
					id: 'custpage_amount_remaining',
					type: serverWidget.FieldType.TEXT,
					label: 'REMAIN AMOUNT'
				});
				
				var prePayment = sublist.addField({
					id: 'custpage_prepayment',
					type: serverWidget.FieldType.TEXTAREA,
					label: 'VENDOR PREPAYMENT'
				});
				
				prePayment.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

				var customrecord_c58005_payment_milestoneSearchObj = search.create({
					type: "customrecord_c59306_purchase_milestone",
					filters:
						[
							["custrecord_c59306_purchase_miles_type", "anyof", "1", "2", "3", "4"],
							"AND",
							["custrecord_c59306_milestone_remain_amt", "greaterthan", "0.00"],
							"AND",
							["custrecord_c59306_vendor", "anyof", recObj.id]
						],
					columns:
						[
							search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
							search.createColumn({ name: "name", label: "Name" }),
							search.createColumn({ name: "custrecord_c59306_purchase_order", label: "Purchase Order" }),
							search.createColumn({ name: "custrecord_c59306_purchase_miles_type", label: "Purchase Milestone Type" }),
							search.createColumn({ name: "custrecord_c59306_milestone", label: "Milestone %" }),
							search.createColumn({ name: "custrecord_c59306_milestone_amount", label: "Milestone Amount" }),
							search.createColumn({ name: "custrecord_c59306_milestone_applied_amt", label: "Milestone Applied Amount" }),
							search.createColumn({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" }),
							search.createColumn({ name: "custrecord_c59306_inbound_shipment", label: "custrecord_c59306_inbound_shipment" }),
							search.createColumn({ name: "custrecord_c59306_item_receipt", label: "custrecord_c59306_item_receipt" })

						]
				});
				var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
				//log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
				var count = 0;
				customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
					var milestoneName = result.getValue({ name: "name", label: "Name" });
					var purchaseOrder = result.getText({ name: "custrecord_c59306_purchase_order", label: "Purchase Order" });
					var milestoneTypeVal = result.getText({ name: "custrecord_c59306_purchase_miles_type", label: "Purchase Milestone Type" });
					var milestonePercentVal = result.getValue({ name: "custrecord_c59306_milestone", label: "Milestone %" });
					var milestoneAmountVal = result.getValue({ name: "custrecord_c59306_milestone_amount", label: "Milestone Amount" });
					var currentAppliedVal = result.getValue({ name: "custrecord_c59306_milestone_applied_amt", label: "Milestone Applied Amount" });
					var remainAmt = result.getValue({ name: "custrecord_c59306_milestone_remain_amt", label: "Milestone Remaining Amount" });
					var milestoneValue = result.getValue({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" });
					var inboundShipment = result.getText({ name: "custrecord_c59306_inbound_shipment", label: "custrecord_c59306_inbound_shipment" });
					var itemReceipt = result.getText({ name: "custrecord_c59306_item_receipt", label: "custrecord_c59306_item_receipt" });

					if (!currentAppliedVal) {
						currentAppliedVal = 0;
					}
					
					if (!inboundShipment) {
						inboundShipment = '-';
					}
					
					if (!itemReceipt) {
						itemReceipt = '-';
					}
                    
					var prePayUrl = 'https://5676368-sb1.app.netsuite.com/app/accounting/transactions/vprep.nl?milestone=' + milestoneValue; 
					
					sublist.setSublistValue({ id: 'custpage_payment_milestone', line: count, value: milestoneName });
					sublist.setSublistValue({ id: 'custpage_purchase_order', line: count, value: purchaseOrder });
					sublist.setSublistValue({ id: 'custpage_inbound_shipment', line: count, value: inboundShipment });
					sublist.setSublistValue({ id: 'custpage_item_receipt', line: count, value: itemReceipt });
					sublist.setSublistValue({ id: 'custpage_milestone_type', line: count, value: milestoneTypeVal });
					sublist.setSublistValue({ id: 'custpage_milestone_percent', line: count, value: milestonePercentVal });
					sublist.setSublistValue({ id: 'custpage_milestone_amount', line: count, value: String(milestoneAmountVal).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_current_applied', line: count, value: String(currentAppliedVal).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_amount_remaining', line: count, value: String(remainAmt).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					sublist.setSublistValue({ id: 'custpage_milestone_id', line: count, value: milestoneValue });
					sublist.setSublistValue({ id: 'custpage_prepayment', line: count, value: '<a href="'+prePayUrl+'" target="_blank">PREPAYMENT</a>' });
					count++;
					return true;
				});
			}

			if (context.type != 'create') {
				var softTab = custForm.addTab({
					id: 'custpage_soft_limit',
					label: 'Soft Limit'
				});

				var softSublist = custForm.addSublist({
					id: 'custpage_soft_limit_list',
					type: serverWidget.SublistType.LIST,
					label: 'Soft Limit List',
					tab: 'custpage_soft_limit'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_vendor',
					type: serverWidget.FieldType.TEXT,
					label: 'VENDOR'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});

				var purchaseOrd = softSublist.addField({
					id: 'custpage_purchase_order_app',
					type: serverWidget.FieldType.TEXT,
					label: 'PURCHASE ORDER'
				});
				
				var purchaseOrd = softSublist.addField({
					id: 'custpage_soft_shipment',
					type: serverWidget.FieldType.TEXT,
					label: 'INBOUND SHIPMENT'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_amount',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE AMOUNT'
				});

				var paymentMilestone = softSublist.addField({
					id: 'custpage_soft_milestone_applied_to',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE APPLIED TO'
				});
				
				var prePayment = softSublist.addField({
					id: 'custpage_soft_prepayment',
					type: serverWidget.FieldType.TEXTAREA,
					label: 'VENDOR PREPAYMENT'
				});
				prePayment.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });

				var softString = "SELECT BUILTIN.DF(pma.custrecord_c59306_purchase_vendor) AS vendor, BUILTIN.DF(pma.custrecord_c59306_purchase_pay_milestone) AS milestone, ";
				softString += "BUILTIN.DF(pma.custrecord_c59306_purch_miles_type) AS milestonetypeapp, pma.custrecord_c59306_milestone_percent * 100 AS milestonepercentapp, ";
				softString += "pma.custrecord_c59306_purch_miles_amt AS milestoneamtapp, pma.custrecord_c59306_purc_milestone_app_to AS milestoneappliedtoapp, ";
				softString += "BUILTIN.DF(ppm.custrecord_c59306_purchase_order) AS mileastonepo, BUILTIN.DF(ppm.custrecord_c59306_inbound_shipment) AS inboundshipment,ppm.id AS milestoneid ";
				softString += "FROM customrecord_c59306_purchase_miles_app AS pma ";
				softString += "JOIN customrecord_c59306_purchase_milestone AS ppm ON pma.custrecord_c59306_purchase_pay_milestone = ppm.id ";
				softString += "JOIN transaction AS pt ON ppm.custrecord_c59306_purchase_order = pt.id ";
				softString += "WHERE pma.custrecord_c59306_purchase_vendor  = '" + recObj.id + "' AND ((pma.custrecord_c59306_purch_miles_type = 1 AND pt.approvalstatus = '1') OR (pma.custrecord_c59306_purch_miles_type = 3 AND ppm.custrecord_c59306_inbound_shipment IS NULL) OR (pma.custrecord_c59306_purch_miles_type = 4 AND ppm.custrecord_c59306_item_receipt IS NULL))";

				//log.debug('softString', softString);
				var softResult = query.runSuiteQL({ query: softString });
				var softValues = softResult.asMappedResults();
				//log.debug('softValues', softValues);

				for (var z = 0; z < softValues.length; z++) {
					var prePayUrl = 'https://5676368-sb1.app.netsuite.com/app/accounting/transactions/vprep.nl?milestone=' + softValues[z].milestoneid; 
					
					softSublist.setSublistValue({ id: 'custpage_soft_vendor', line: z, value: softValues[z].vendor });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone', line: z, value: softValues[z].milestone });
					softSublist.setSublistValue({ id: 'custpage_purchase_order_app', line: z, value: softValues[z].mileastonepo });
					softSublist.setSublistValue({ id: 'custpage_soft_shipment', line: z, value: softValues[z].inboundshipment });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_type', line: z, value: softValues[z].milestonetypeapp });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_percent', line: z, value: softValues[z].milestonepercentapp });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_amount', line: z, value: String(softValues[z].milestoneamtapp).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					softSublist.setSublistValue({ id: 'custpage_soft_milestone_applied_to', line: z, value: String(softValues[z].milestoneappliedtoapp).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					softSublist.setSublistValue({ id: 'custpage_soft_prepayment', line: z, value: '<a href="'+prePayUrl+'" target="_blank">PREPAYMENT</a>' });
				}
			}


			if (context.type != 'create') {
				var hardTab = custForm.addTab({
					id: 'custpage_hard_limit',
					label: 'Hard Limit'
				});

				var hardSublist = custForm.addSublist({
					id: 'custpage_hard_limit_list',
					type: serverWidget.SublistType.LIST,
					label: 'Hard Limit List',
					tab: 'custpage_hard_limit'
				});

				hardSublist.addField({
					id: 'custpage_hard_vendor',
					type: serverWidget.FieldType.TEXT,
					label: 'VENDOR'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone',
					type: serverWidget.FieldType.TEXT,
					label: 'PAYMENT MILESTONE'
				});

				hardSublist.addField({
					id: 'custpage_hard_purchase_order',
					type: serverWidget.FieldType.TEXT,
					label: 'PURCHASE ORDER'
				});
				
				hardSublist.addField({
					id: 'custpage_hard_inbound_shipment',
					type: serverWidget.FieldType.TEXT,
					label: 'INBOUND SHIPMENT'
				});
				
				hardSublist.addField({
					id: 'custpage_hard_item_receipt',
					type: serverWidget.FieldType.TEXT,
					label: 'ITEM RECEIPT'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone_qty',
					type: serverWidget.FieldType.TEXT,
					label: 'QUANTITY'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone_type',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TYPE'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone_percent',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE %'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone_term',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE TERM'
				});

				hardSublist.addField({
					id: 'custpage_hard_milestone_amount',
					type: serverWidget.FieldType.TEXT,
					label: 'MILESTONE AMOUNT'
				});

				hardSublist.addField({
					id: 'custpage_hard_applied_to',
					type: serverWidget.FieldType.TEXT,
					label: 'APPLIED TO'
				});
				
				var prePayment = hardSublist.addField({
					id: 'custpage_hard_prepayment',
					type: serverWidget.FieldType.TEXTAREA,
					label: 'VENDOR PREPAYMENT'
				});
				prePayment.updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });


				var queryString = "SELECT BUILTIN.DF(pm.custrecord_c59306_vendor) AS vendor,pm.name AS milestonename, BUILTIN.DF(custrecord_c59306_purchase_order) AS purchaseorder, ";
				queryString += "BUILTIN.DF(pm.custrecord_c59306_purchase_miles_type) AS milestonetype, pm.custrecord_c59306_milestone * 100 AS milestonepercent, ";
				queryString += "BUILTIN.DF(pm.custrecord_c59306_milestone_terms) AS terms, pm.custrecord_c59306_milestone_amount AS pmamount, pm.custrecord_c59306_quantity AS pmquantity, pm.custrecord_c59306_milestone_applied_amt AS appliedto, ";
				queryString += "BUILTIN.DF(pm.custrecord_c59306_inbound_shipment)  AS inboundshipment,BUILTIN.DF(pm.custrecord_c59306_item_receipt) AS itemreceipt,pm.id AS milestoneid  ";
				queryString += "FROM customrecord_c59306_purchase_milestone AS pm ";
				queryString += "JOIN transaction AS pt ON pm.custrecord_c59306_purchase_order = pt.id ";
				queryString += "WHERE pm.custrecord_c59306_vendor = '" + recObj.id + "' AND ((pm.custrecord_c59306_purchase_miles_type = 1  AND pt.approvalstatus = '2') OR (pm.custrecord_c59306_purchase_miles_type = 3 AND pm.custrecord_c59306_inbound_shipment IS NOT NULL) OR (pm.custrecord_c59306_purchase_miles_type = 4  AND pm.custrecord_c59306_item_receipt IS NOT NULL))";

				log.debug('queryString', queryString);
				var queryResult = query.runSuiteQL({ query: queryString });
				var resultValues = queryResult.asMappedResults();
				//log.debug('resultValues', resultValues);

				for (var i = 0; i < resultValues.length; i++) { 
					var prePayUrl = 'https://5676368-sb1.app.netsuite.com/app/accounting/transactions/vprep.nl?milestone=' + resultValues[i].milestoneid; 
					
					hardSublist.setSublistValue({ id: 'custpage_hard_vendor', line: i, value: resultValues[i].vendor });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone', line: i, value: resultValues[i].milestonename });
					hardSublist.setSublistValue({ id: 'custpage_hard_purchase_order', line: i, value: resultValues[i].purchaseorder });
					hardSublist.setSublistValue({ id: 'custpage_hard_inbound_shipment', line: i, value: resultValues[i].inboundshipment });
					hardSublist.setSublistValue({ id: 'custpage_hard_item_receipt', line: i, value: resultValues[i].itemreceipt });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone_qty', line: i, value: resultValues[i].pmquantity });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone_type', line: i, value: resultValues[i].milestonetype });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone_percent', line: i, value: resultValues[i].milestonepercent + '%' });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone_term', line: i, value: resultValues[i].terms });
					hardSublist.setSublistValue({ id: 'custpage_hard_milestone_amount', line: i, value: String(resultValues[i].pmamount).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					hardSublist.setSublistValue({ id: 'custpage_hard_applied_to', line: i, value: String(resultValues[i].appliedto).replace(/\B(?=(\d{3})+(?!\d))/g, ',') });
					hardSublist.setSublistValue({ id: 'custpage_hard_prepayment', line: i, value: '<a href="'+prePayUrl+'" target="_blank">PREPAYMENT</a>' });
				}

			}
		}
		catch (e) { log.error('Error', e) }
	}


	function afterSubmit(context) {
		try {
			var recObj = context.newRecord;

			var lineCnt = recObj.getLineCount({ sublistId: 'custpage_open_milestone_list' });
			//log.debug("lineCnt", lineCnt);

			var paymentArray = [];
			for (var x = 0; x < lineCnt; x++) {
				var markPayment = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment', line: x });
				var appliedTo = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', line: x });
				if (markPayment == 'T' && parseFloat(appliedTo) > 0) {
					var paymentId = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_id', line: x });
					paymentArray.push({ 'paymentId': paymentId, 'appliedTo': appliedTo });
				}
			}
			log.debug("paymentArray", paymentArray);

			if (paymentArray.length > 0) {
				var mrTask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_css_mr_create_purch_pay_app',
					//deploymentId: availableJobId[randomId],
					params: { custscript_c_sp_payment_data: paymentArray }
				});
				mrTask.submit();
			}
		}
		catch (e) { log.error('Error', e) }
	}


	function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
		try {
			var arrSearchResults = [];
			var count = 1000,
				min = 0,
				max = 1000;
			var searchObj = false;
			if (recordType == null) {
				recordType = null;
			}
			if (searchId) {
				searchObj = search.load({
					id: searchId
				});
				if (searchFilter) {
					searchObj.filterExpression = searchFilter;
				}
			} else {
				searchObj = search.create({
					type: recordType,
					filters: searchFilter,
					columns: searchColumns
				})
			}

			var rs = searchObj.run();
			//searchColumns.push(rs.columns);
			//allColumns = rs.columns;

			while (count == 1000) {
				var resultSet = rs.getRange({
					start: min,
					end: max
				});
				if (resultSet != null) {
					arrSearchResults = arrSearchResults.concat(resultSet);
					min = max;
					max += 1000;
					count = resultSet.length;
				}
			}
		} catch (e) {
			//log.debug('Error searching for Customer:- ', e.message);
		}
		return arrSearchResults;
	}


	return {
		beforeLoad: beforeLoad,
		afterSubmit: afterSubmit
	};
});
/**
    *@NApiVersion 2.x
    *@NScriptType MapReduceScript
*/
/**
    * Script Name          : CSS MR CREATE PAYMENT APPLICATION
    * Author               : Naim 
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Description          : This script is responsible to create a payment application record.
*/

/**
    * The script uses NetSuite's Map/Reduce pardigm implementation and uses getInputData, map, and summarize stages. When completed,
    * the script deletes existing Pricing data for for qualifying items using the following generalized algorithm:
    * Read the items and price data in getinputdata
    * In map stage, delete the price data that was passed from getInputData stage
    * In summery stage, write the debug log regarding uses and descriptive messages
*/
define(['N/search', 'N/record', 'N/runtime'],
    /**
        * @param search @param record
    */

    function (search, record, runtime) {


        function getInputData() {
            try {
                var schobj = runtime.getCurrentScript();
                var data = JSON.parse(schobj.getParameter({ name: 'custscript_c_sp_milestone_data' }));

                log.debug('data', data);
                log.debug('data length', data.length);
                log.debug('data type', typeof data);

                return data;
            }
            catch (reqError) {
                log.error('log Error', reqError);
            }

        }


        function map(context) {
            try {
                var mapData = JSON.parse(context.value);

                var milestoneId = mapData.paymentId;
                var appliedAmt = mapData.appliedTo;
                log.debug('milestoneId', milestoneId);
                log.debug('appliedAmt', appliedAmt);

                var paymentApp = record.create({ type: 'customrecord_c57685_paymt_milestone_app' });
                paymentApp.setValue({ fieldId: 'custrecord_c57685_payment_milestone', value: milestoneId });
                paymentApp.setValue({ fieldId: 'custrecord_c57685_milestone_applied_to', value: appliedAmt });

                var paymentAppId = paymentApp.save({ ignoreMandatoryFields: true });
                log.debug('paymentAppId', paymentAppId);

                if (paymentAppId) {
                    var recObj = record.load({ type: 'customrecord_c58005_payment_milestone', id: milestoneId, isDynamic: true });
                    var appliedAmount = recObj.getValue({ fieldId: 'custrecord_c58005_milestone_applied_amt' });
                    var milestoneAmt = recObj.getValue({ fieldId: 'custrecord_c58005_milestone_amount' });
                    var milestoneType = recObj.getValue({ fieldId: 'custrecord_c58005_milestone_type' });
                    var quotation = recObj.getValue({ fieldId: 'custrecord_c58005_quotation' });
                    var fulfillmentRequest = recObj.getValue({ fieldId: 'custrecord_c58005_fulfillment_request' });

                    if (appliedAmount) {
                        var sumAmt = parseFloat(appliedAmount) + parseFloat(appliedAmt);
                    }
                    else {
                        var sumAmt = parseFloat(appliedAmt);
                    }
                    var remainAmt = milestoneAmt - sumAmt;

                    recObj.setValue({ fieldId: 'custrecord_c58005_milestone_applied_amt', value: sumAmt, ignoreFieldChange: true });
                    recObj.setValue({ fieldId: 'custrecord_c58005_milestone_remain_amt', value: remainAmt, ignoreFieldChange: true });
                    recObj.save({ ignoreMandatoryFields: true });

                    if (remainAmt == 0 && (milestoneType == '1' || milestoneType == '2')) {
                        context.write({ key: milestoneId, value: { 'milestoneType': milestoneType, 'quotaion': quotation, 'fulfillmentRequest': fulfillmentRequest } });
                    }
                }

            }
            catch (reqError) {
                log.error('log Error', reqError);
            }
        }

        function reduce(context) {
            try {
                var reduceData = context.values.map(JSON.parse);
                log.debug('reduceData', reduceData);
                log.debug('reduceData length', reduceData.length);
                if (reduceData.length > 0) {
                    if (reduceData[0].milestoneType == 1) {
                        var quoteId = reduceData[0].quotaion;
                        log.debug('quoteId', quoteId);

                        var soRec = record.transform({
                            fromType: record.Type.ESTIMATE,
                            fromId: quoteId,
                            toType: record.Type.SALES_ORDER,
                            isDynamic: true,
                        });
                        var soId = soRec.save({ ignoreMandatoryFields: true });
                        log.debug('soId', soId);

                        if (soId) {
                            var customrecord_c58005_payment_milestoneSearchObj = search.create({
                                type: "customrecord_c58005_payment_milestone",
                                filters:
                                    [
                                        ["custrecord_c58005_quotation", "anyof", quoteId]
                                    ],
                                columns:
                                    [
                                        search.createColumn({ name: "internalid", label: "Internal ID" })
                                    ]
                            });
                            var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                            log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

                            //This loop never going to be more than 4 results so no need to worry regarding script failure or performance.
                            customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                                var milestoneIds = result.getValue({ name: "internalid", label: "Internal ID" });
                                record.submitFields({
                                    type: 'customrecord_c58005_payment_milestone',
                                    id: milestoneIds,
                                    values: {
                                        custrecord_c58005_salesorder: soId
                                    },
                                    options: {
                                        enableSourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });
                                return true;
                            });
                        }
                    }
                    else if (reduceData[0].fulfillmentRequest && reduceData[0].milestoneType == 2) {
                        var fulfillReqId = reduceData[0].fulfillmentRequest;
                        record.submitFields({
                            type: 'fulfillmentrequest',
                            id: fulfillReqId,
                            values: {
                                transtatus: 'B'
                            },
                            options: {
                                enableSourcing: true,
                                ignoreMandatoryFields: true
                            }
                        });
                    }
                }
            }
            catch (reqError) {
                log.error('log Error', reqError);
            }
        }


        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce
        };
    });					
/**
* @NApiVersion 2.1
* @NScriptType ClientScript
* @NModuleScope SameAccount
*/

/*******************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Create Matrix Item.js
* DEVOPS TASK: DT/50834
* AUTHOR: Akash Sharma
* DATE CREATED: 28-June-2022
* DESCRIPTION: Client Script to Help Suitelet Run.
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/

define(['N/currentRecord', 'N/url', './Matrix Items.lib.js'],

  function (currentRecord, url, mat) {

    /**
    * Function to be executed after page is initialized.
    *
    * @param {Object} scriptContext
    * @param {Record} scriptContext.currentRecord - Current form record
    * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
    *
    * @since 2015.2
    */
    function pageInit(scriptContext) {
      try{
      log.debug("Inside page init function");

      }catch(e){
        log.error("Error Inside pageInit", e.message);
      }
    }

    function openSuiteletItemAdd(matrixItemRecordId) {
      try {
        log.debug("matrixItemRecordId", matrixItemRecordId)

        var slCallOne = url.resolveScript({
          scriptId: 'customscript_c60520_su_create_matrx_item',
          deploymentId: 'customdeploy_c60520_su_create_matrx_item',
          returnExternalUrl: false,
          params: { 'mrecid': matrixItemRecordId, 'mrecsl': true, 'itemadd': true }
        });
        window.open(slCallOne, '_blank');
      } catch (e) {
        log.error("Error Inside openSuiteletItemAdd Function!", [e.message, e.stack]);
      }
    }
    function openSuiteletSpecAdd(matrixItemRecordId) {
      try {
        log.debug("matrixItemRecordId", matrixItemRecordId)

        var slCallOne = url.resolveScript({
          scriptId: 'customscript_c60520_su_create_matrx_item',
          deploymentId: 'customdeploy_c60520_su_create_matrx_item',
          returnExternalUrl: false,
          params: { 'mrecid': matrixItemRecordId, 'mrspecadd': true,}
        });
        window.open(slCallOne, '_blank');
      } catch (e) {
        log.error("Error Inside openSuiteletSpecAdd Function!", [e.message, e.stack]);
      }
    }

    function openSuiteletOptionAdd(matrixItemRecordId) {
      try {
        log.debug("matrixItemRecordId", matrixItemRecordId)

        var slCallOne = url.resolveScript({
          scriptId: 'customscript_c60520_su_create_matrx_item',
          deploymentId: 'customdeploy_c60520_su_create_matrx_item',
          returnExternalUrl: false,
          params: { 'mrecid': matrixItemRecordId, 'mrecsl': true, 'optionadd': true }
        });
        window.open(slCallOne, '_blank');
      } catch (e) {
        log.error("Error Inside openSuiteletOptionAdd Function!", [e.message, e.stack]);
      }
    }

    function openSuiteletItemDuplicate(matrixItemRecordId, matrixSubItemId) {
      try {
        log.debug("matrixItemRecordId", matrixItemRecordId);
        log.debug("matrixSubItemId", matrixSubItemId)

        var slCallOne = url.resolveScript({
          scriptId: 'customscript_c60520_su_create_matrx_item',
          deploymentId: 'customdeploy_c60520_su_create_matrx_item',
          returnExternalUrl: false,
          params: { 'mrecid': matrixItemRecordId, 'mrecsl': true, 'dupadd': true, 'msrecid':matrixSubItemId}
        });
        window.open(slCallOne, '_blank');
      } catch (e) {
        log.error("Error Inside openSuiteletItemDuplicate Function!", [e.message, e.stack]);
      }
    }

    var data = fieldsArray(); //Matrix Item library data
    var str = '{itemid}' // Global variable to store data in field: 'matrixitemnametemplate'
    function fieldChanged(context)
    {
      //Function is used to remove '-' character from fieldId: 'matrixitemnametemplate'
      try{
        var currentRecord = context.currentRecord;
        var fieldName = context.fieldId;
        log.debug("fieldName",currentRecord.getValue({fieldId:fieldName})=='');
        var index = data.findIndex((c) => c.actualFieldId == fieldName); //If field being changed is present in library
        if(index >= 0)
        {
          
          if(str.indexOf(fieldName) < 0)
          {
            str = str + '{' + fieldName + '}';
            currentRecord.setValue({ fieldId: 'matrixitemnametemplate', value: str});
          }

          var fieldValue = currentRecord.getValue({fieldId: fieldName});

          if(fieldValue == ''|| fieldValue.length == 0) // If field is set to blank
          {
            //Case when field is removed
            str = str.replace(`{${fieldName}}`,'');
            currentRecord.setValue({ fieldId: 'matrixitemnametemplate', value: str});

          }
        }
      }
      catch(err)
      {
        log.error("Error in fieldchanged:", err);
      }
    }

    return {
      pageInit: pageInit,
      openSuiteletItemAdd: openSuiteletItemAdd,
      openSuiteletOptionAdd: openSuiteletOptionAdd,
      openSuiteletItemDuplicate: openSuiteletItemDuplicate,
      openSuiteletSpecAdd: openSuiteletSpecAdd,
      fieldChanged: fieldChanged
    };

  });
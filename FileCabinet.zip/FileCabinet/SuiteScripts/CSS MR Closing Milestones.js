/**
* @NApiVersion 2.1
* @NScriptType MapReduceScript
*/
/*****************************************************************************
 *  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS MR Closing Milestone.js
* DEVOPS TASK: BL/59159
* AUTHOR: Akash Sharma
* DATE CREATED: 9 March, 2023
* DESCRIPTION: This Script is for marking customrecord_c58005_payment_milestone record's
* status to closed when linked quotation's expiry date has passed.                            
*****************************************************************************/
define(['N/search', 'N/record','N/format'],
/**
* @param{search} search
* @param{record} record
* @param{format} format
*/
(search, record, format) => {
  /**
  * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
  * @param {Object} inputContext
  * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
  *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
  * @param {Object} inputContext.ObjectRef - Object that references the input data
  * @typedef {Object} ObjectRef
  * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
  * @property {string} ObjectRef.type - Type of the record instance that contains the input data
  * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
  * @since 2015.2
  */
  
  const getInputData = (inputContext) => {
    try{
      let filters = [
          ["custrecord_c58005_status","anyof","1"], 
          // "AND", 
          // ["custrecord_c58005_quotation.expectedclosedate","before","today"], 
          // // "AND", 
          // // ["custrecord_c58005_quotation.expectedclosedate","within","15-Feb-2023","16-Feb-2023"], 
          // "AND", 
          // ["internalid","anyof","9"],
          "AND", 
          ["custrecord_c58005_quotation.status","anyof","Estimate:X"]
      ];

      let columns = [
        search.createColumn({name: "internalid",sort: search.Sort.ASC,label: "Internal ID"}),
        search.createColumn({name: "name", label: "Name"}),
        search.createColumn({name: "scriptid", label: "Script ID"}),
        search.createColumn({name: "custrecord_c58005_milestone", label: "Milestone %"}),
        search.createColumn({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}),
        search.createColumn({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"}),
        search.createColumn({name: "custrecord_c58005_status", label: "Status"}),
        search.createColumn({name: "custrecord_c58005_milestone_terms", label: "Milestone Terms"}),
        search.createColumn({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"}),
        search.createColumn({name: "custrecord_c58005_milestone_remain_amt", label: "Milestone Remaining Amount"}),
        search.createColumn({name: "custrecord_c58005_item_fulfillment", label: "Item Fulfillment"}),
        search.createColumn({name: "custrecord_c58005_quantity", label: "Quantity"}),
        search.createColumn({name: "expectedclosedate",join: "CUSTRECORD_C58005_QUOTATION",label: "Expected Close"})
      ];

      let quotationPaymentMileStoneList = searchAllRecord('customrecord_c58005_payment_milestone',null,filters,columns);
			log.debug('quotationPaymentMileStoneList',quotationPaymentMileStoneList);

      let quotationPaymentArr = [];
      for(let i = 0; i < quotationPaymentMileStoneList.length; i++){
        quotationPaymentArr.push(Number(quotationPaymentMileStoneList[i].getValue(quotationPaymentMileStoneList[i].columns[0])));
      }
 
      log.debug('quotationPaymentArr',quotationPaymentArr);
      if(quotationPaymentArr.length){
        return removeDuplicates(quotationPaymentArr);
      }
            
    }catch(err){
      log.error("Error Inside Get Input Data -->",[err.message,err.stack]);
    }
    
  }
  
  /**
  * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
  * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
  * context.
  * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
  *     is provided automatically based on the results of the getInputData stage.
  * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
  *     function on the current key-value pair
  * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
  *     pair
  * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
  *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
  * @param {string} mapContext.key - Key to be processed during the map stage
  * @param {string} mapContext.value - Value to be processed during the map stage
  * @since 2015.2
  */
  
  const map = (mapContext) => {
    try{
      const quoPayRecId = JSON.parse(mapContext.value);
      log.debug("Quotation Payment Record Id",quoPayRecId);

      var quoPayRecord = record.load({type: 'customrecord_c58005_payment_milestone',id: quoPayRecId});
      quoPayRecord.setValue({fieldId: 'custrecord_c58005_status',value: 3});
      
      var savedQuoPayRecord = quoPayRecord.save({
        enableSourcing: true,
        ignoreMandatoryFields: true
      });

      log.debug("Saved quoPayRecord Id is : "+ savedQuoPayRecord);

    }catch(err){
      log.error("Error Inside Map -->",[err.message,err.stack]);
    }    
  }
  
  
  
  /**
  * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
  * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
  * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
  *     provided automatically based on the results of the map stage.
  * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
  *     reduce function on the current group
  * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
  * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
  *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
  * @param {string} reduceContext.key - Key to be processed during the reduce stage
  * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
  *     for processing
  * @since 2015.2
  */
  const reduce = (reduceContext) => {
    
  }
  
  
  /**
  * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
  * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
  * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
  * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
  *     script
  * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
  * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
  *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
  * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
  * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
  * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
  *     script
  * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
  * @param {Object} summaryContext.inputSummary - Statistics about the input stage
  * @param {Object} summaryContext.mapSummary - Statistics about the map stage
  * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
  * @since 2015.2
  */
  const summarize = (summaryContext) => {
    log.debug("Summarize Complete!"); 
  }
  

  	function searchAllRecord(recordType,searchId,searchFilter,searchColumns){       
		try{   
			var arrSearchResults =[];
			var count = 1000,min = 0,max = 1000;
			var searchObj = false;
			
			if(recordType==null){
				recordType=null;
			}
			
			if (searchId)
			{
				searchObj = search.load({id : searchId});
				if (searchFilter)
				{
					searchObj.addFilters(searchFilter);
				}
				if (searchColumns)
				{
					searchObj.addColumns(searchColumns);
				}          
			}
			else
			{
				searchObj = search.create({type:recordType,filters:searchFilter,columns:searchColumns})
			}
			
			var rs = searchObj.run();           
			searchColumns.push(rs.columns);
			allColumns = rs.columns;
			
			while (count == 1000)
			{
				var resultSet = rs.getRange({start : min,end :max});                                           
				if(resultSet!=null)
				{
					arrSearchResults = arrSearchResults.concat(resultSet);
					min = max;
					max += 1000;
					count = resultSet.length;
				}
			}
		}
		catch (e)
		{
			log.debug( 'Error searching for Customer:- ', e.message);
		}
		return arrSearchResults;
	}

  function removeDuplicates(arr) {
    return arr.filter((item, 
        index) => arr.indexOf(item) === index);
  }
  
  return {getInputData, map, reduce, summarize}
  
});

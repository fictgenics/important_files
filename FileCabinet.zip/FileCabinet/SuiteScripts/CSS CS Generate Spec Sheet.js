/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 */
define(['N/url', 'N/currentRecord'], function(url, currentRecord) {
    function pageInit(context) {
    }

    function generateSpecSheet() {
       try {
         var recId = currentRecord.get().id;
         var suiteletURL = url.resolveScript({
             scriptId: 'customscript_c60520_su_create_spec_sheet',
             deploymentId: 'customdeploy_c60520_su_create_spec_sheet',
             params: {
                 recd_id: recId
             }
         });
         
         window.open(suiteletURL);
       } catch (error) {
        alert( error.message);
        
       }
        
    }

    return {
        pageInit: pageInit,
        generateSpecSheet: generateSpecSheet
    };
});

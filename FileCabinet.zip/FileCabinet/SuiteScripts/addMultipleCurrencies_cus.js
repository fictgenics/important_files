function addMultipleCurrencies_cus(type) 
{
    if (type == 'create') 
	{
        nlapiSetLineItemValue('currency', 'currency', 1, 1);
        nlapiSetLineItemValue('currency', 'currency', 2, 2);
        nlapiSetLineItemValue('currency', 'currency', 3, 4);
    }
}
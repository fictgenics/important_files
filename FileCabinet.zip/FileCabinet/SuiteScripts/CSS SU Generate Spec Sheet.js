/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
define(['N/xml', 'N/log', 'N/render', 'N/file', 'N/url', 'N/search', 'N/format', 'N/query'], function (xml, log, render, file, url, search, format, query) {

    function onRequest(context) {


        try {
            var mainXml = '<?xml version="1.0"?><!DOCTYPE pdf PUBLIC "-//big.faceless.org//report" "report-1.1.dtd">';
            mainXml += '<pdf><head>';
            mainXml += '  <style rel="stylesheet" type="text/css">';
            mainXml += '    th{';
            mainXml += '      font-weight:bold;';
            mainXml += '      width:50%;';
            mainXml += '    }';
            mainXml += '    table{';
            mainXml += '      width:100%;';
            mainXml += '    }';
            mainXml += '  </style>';
            mainXml += '<macrolist>';
            mainXml += '<macro id="nlheader">';
            mainXml += '<table width="100%" style="border: 0px solid black;"><tr align="left"><td>';
            mainXml += '<div style="text-align: center;">';
            mainXml += '<img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/image-000.jpg" width="90%" height="90" style="display: inline-block;"/>';
            mainXml += '</div>';
            mainXml += '</td></tr></table>';
            mainXml += '</macro>';
            mainXml += '<macro id="nlfooter">';
            mainXml += '<table width="100%" style="border: 0px solid black; position: absolute; bottom: 0;">';
            mainXml += '<tr>';
            mainXml += '<td style="width: 33%; text-align: left; vertical-align: left;">';
            mainXml += 'Page <pagenumber /> of <totalpages />';
            mainXml += '</td>';
            mainXml += '<td style="width: 33%; text-align: center; vertical-align: middle;">';
            mainXml += '<a href="https://www.milele.com/" style="color: #042d65; text-decoration: none;">www.milele.com</a>';
            mainXml += '</td>';
            mainXml += '<td style="width: 33%; text-align: right; vertical-align: middle;">';
            mainXml += '<table style="border: none; padding: 0; margin: 0;">';
            mainXml += '<tr>';
            mainXml += '<td style="padding: 0; margin: 0;">';
            mainXml += '<a href="https://www.linkedin.com"><img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/Linkedin Logo" width="15" height="15" style="vertical-align: middle;" /></a>'; // Reduced margin-right
            mainXml += '</td>';
            mainXml += '<td style="padding: 0; margin: 0;">';
            mainXml += '<a href="https://www.youtube.com"><img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/Youtube Logo" width="15" height="15" style="vertical-align: middle;" /></a>';
            mainXml += '</td>';
            mainXml += '<td style="padding: 0; margin: 0;">';
            mainXml += '<a href="https://www.milele.com"><img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/Google Logo" width="15" height="15" style="vertical-align: middle;" /></a>';
            mainXml += '</td>';
            mainXml += '<td style="padding: 0; margin: 0;">';
            mainXml += '<a href="https://www.instagram.com"><img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/Instagram Logo" width="15" height="15" style="vertical-align: middle;" /></a>';
            mainXml += '</td>';
            mainXml += '<td style="padding: 0; margin: 0;">';
            mainXml += '<a href="https://www.facebook.com"><img src="https://5676368-sb1.app.netsuite.com/c.5676368_SB1/suitebundle43003/src/Facebook Logo" width="15" height="15" style="vertical-align: middle;" /></a>';
            mainXml += '</td>';
            mainXml += '</tr>';
            mainXml += '</table>';
            mainXml += '</td>';
            mainXml += '</tr>';
            mainXml += '</table>';
            mainXml += '<hr style="border: none; height: 1px; background-color: #042d65; margin-top: 1px;" />';
            mainXml += '<div style="margin-bottom: 10px;"></div>'; // Adjust the margin-bottom value as needed for spacing
            // Continue with your footer code
            mainXml += '</macro>';
            mainXml += '</macrolist>';
            mainXml += '</head>';
            mainXml += '<body header="nlheader" header-height="15%" footer="nlfooter" footer-height="auto" size="A4">';
            var searchResults;
            var photo;
            var recId = context.request.parameters.recd_id;
            var searchExecuted = false;

            if (!searchExecuted) {
                searchResults = specNameAndValueSearch(recId);
                photo = photosearch(recId);
                var prefix = "https://5676368-sb1.app.netsuite.com";
                var modifiedUrls = [];
                photo.forEach(function (urlObj) {
                    var originalUrl = urlObj.url;
                    var modifiedUrl = prefix + originalUrl;
                    modifiedUrls.push(modifiedUrl);
                });

                var nameValuePairs;
                for (var category in searchResults) {
                    if (searchResults.hasOwnProperty(category)) {
                        nameValuePairs = searchResults[category];
                        mainXml += '<table>';
                        mainXml += '<tr>';
                        mainXml += '<td>&nbsp;</td>';
                        mainXml += '</tr>';
                        mainXml += '<tr>';
                        category = excapeXML(category);
                        mainXml += '<th>' + category + '</th>';
                        mainXml += '</tr>';
                        for (var i = 0; i < nameValuePairs.length; i++) {
                            var name = nameValuePairs[i].name;
                            var value = nameValuePairs[i].value;
                            name = excapeXML(name);
                            value = excapeXML(value);
                            mainXml += '<tr>';
                            mainXml += '<td>' + name + '</td>';
                            mainXml += '<td>' + value + '</td>';
                            mainXml += '</tr>';
                        }

                    }
                    mainXml += '</table>';

                }

                for (var i = 0; i < modifiedUrls.length; i += 2) {
                    mainXml += '<div style="display: flex; justify-content: space-between; margin-bottom: 50px;">';
                    for (var j = i; j < i + 2 && j < modifiedUrls.length; j++) {
                        var url = excapeXML(modifiedUrls[j]);
                        mainXml += '<div style="flex: 1; text-align: center;">';
                        mainXml += '<img src="' + url + '" style="max-width: auto; height: auto;"/>';
                        mainXml += '</div>';
                    }
                    mainXml += '</div>';
                }
                mainXml += '</body>';
                mainXml += '</pdf>';
                context.response.renderPdf({ xmlString: mainXml });
            };
        } catch (error) {
            log.debug("Error ", error.message)
        }
    };
    function specNameAndValueSearch(recId) {

        var customrecord_c60520_variant_bgkSearchObj = search.create({
            type: "customrecord_c60520_variant_bgk",
            filters:
                [

                    ["internalid", "anyof", recId]
                ],
            columns:
                [
                    search.createColumn({ name: "custrecord_c60520_specname", join: "CUSTRECORD_C60520_VS_VARIANT", label: "Spec Name" }),
                    search.createColumn({ name: "custrecord_c60520_specvalue", join: "CUSTRECORD_C60520_VS_VARIANT", label: "Spec Value" }),
                    search.createColumn({ name: "custrecord_c60520_speccategory", join: "CUSTRECORD_C60520_VS_VARIANT", sort: search.Sort.ASC, label: "Spec Category" })
                ]
        });
        var finalObject = {};
        var searchSpecCategories = [];
        customrecord_c60520_variant_bgkSearchObj.run().each(function (result) {
            var searchSpecName = result.getValue({ name: 'custrecord_c60520_specname', join: "CUSTRECORD_C60520_VS_VARIANT", label: "Spec Name" });
            var searchSpecValue = result.getValue({ name: 'custrecord_c60520_specvalue', join: "CUSTRECORD_C60520_VS_VARIANT", label: "Spec Value" });
            var searchSpecCategory = result.getValue({ name: 'custrecord_c60520_speccategory', join: "CUSTRECORD_C60520_VS_VARIANT", label: "Spec Category" });
            searchSpecCategories.push(searchSpecCategory);
            if (!finalObject[searchSpecCategory]) { finalObject[searchSpecCategory] = []; }
            finalObject[searchSpecCategory].push({ name: searchSpecName, value: searchSpecValue });
            return true;
        });
        return finalObject;
    }
    function runSuiteQuery(queryString) {
        var resultSet = query.runSuiteQL({ query: queryString });
        log.debug("Query wise Data", resultSet.asMappedResults());
        if (resultSet && resultSet.results && resultSet.results.length > 0) {
            return resultSet.asMappedResults();
        } else {
            return [];
        }
    }
    function photosearch(recId) {
        var customrecord_c60520_variantrefphotoSearchObj = search.create({
            type: "customrecord_c60520_variantrefphoto",
            filters: [
                ["custrecord_c60520_variant", "anyof", recId]
            ],
            columns: [
                search.createColumn({ name: "custrecord_c60520_refphoto", label: "Reference Photo" })
            ]
        });
        var photoObject = { photoIds: [] };
        var searchResultCount = customrecord_c60520_variantrefphotoSearchObj.runPaged().count;
        log.debug("customrecord_c60520_variantrefphotoSearchObj result count", searchResultCount);

        customrecord_c60520_variantrefphotoSearchObj.run().each(function (result) {
            var photoId = result.getValue({ name: 'custrecord_c60520_refphoto', label: "Reference Photo" });
            photoObject.photoIds.push(photoId);
            return true;
        });
        // Convert photo IDs array to a comma-separated string
        var fileIds = photoObject.photoIds.join(',');

        // Create a SuiteQL query to retrieve file URLs
        var query = "SELECT url FROM file WHERE id IN (" + fileIds + ")";
        var resultSet = runSuiteQuery(query);
        return resultSet;
    }
    function excapeXML(si) {
        var s = new String(si);
        return s.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/&/g, "&amp;").replace(/'/g, "&#39;").replace(/\n/g, "<br></br>").replace(undefined, "").replace('NaN', "").replace('&lt;/space&gt;', "&nbsp").replace('&lt;hr&gt;', "<hr>");
    }
    return {
        onRequest: onRequest
    }
});

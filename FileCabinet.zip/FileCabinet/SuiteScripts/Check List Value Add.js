/**
* @NApiVersion 2.x
* @NScriptType UserEventScript
* @NModuleScope SameAccount
*/

define(['N/record','N/runtime'], function(record, runtime) {
  
  function afterSubmit(context) {
    try{
    // var currentRec = context.newRecord;
      log.debug("Runtime Details", runtime.getCurrentUser().subsidiary);
    // var createRecord = record.create({type: 'customlist_custom_test_list'});
    // createRecord.setValue({fieldId: 'name',value: 'Name Test'});

    // var createRecord = record.create({
    //   type: record.Type.SERIALIZED_ASSEMBLY_ITEM,
    // });
   
    //  createRecord.setValue({fieldId: 'matrixtype', value: 'CHILD'});
    // createRecord.setValue({fieldId: 'parent', value: 2931});
    // createRecord.setValue({fieldId: 'itemid', value: 'Renault Matrix SubItem'});
    // createRecord.setValue({fieldId: 'taxschedule', value: 1});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem_c60520_matrix_steering', value: 1});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem_c60520_matrix_gear', value: 1});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem_c60520_matrix_fuel', value: 1});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem_c60520_matrix_seats', value: 4});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem_c60520_matrix_ext_main_color', value: 3});
    // createRecord.setValue({fieldId: 'matrixoptioncustitem9', value: 1});

    // var savedid = createRecord.save();
    // log.debug("savedid", savedid);
    }catch(e){
      log.error("error inside after submit", [e.message, e.stack]);
    }


  }
  
  return {
    afterSubmit: afterSubmit
  };
  
});
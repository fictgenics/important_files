 /**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @NScriptType ClientScript
 */
define([], function () {
 function showMessage(context){
 	   
   		var title=context.portlet.getValue({"fieldId":"title"});
   		//var dept=context.currentRecord.getText({"fieldId":"tasks"});
   		//var department=dept.options[dept.selectedIndex].text;
   	alert(title);
    }
	return{
      pageInit:showMessage
    };
});
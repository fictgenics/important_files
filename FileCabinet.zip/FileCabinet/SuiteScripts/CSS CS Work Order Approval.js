/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CSS CS Work Order Approval.js
* DEVOPS TASK: DT/60530
* AUTHOR: Akash Sharma
* DATE CREATED: 23-April-2023
* DESCRIPTION: This script is for function call from user event & to call workflow approve request.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 24-April-2023   DT/60531          Akash Sharma        Added Suitelet in Middle to Call MR Script.
************************************************************************************************/
define(['N/record','N/url', 'N/https', 'N/runtime'],function(record, url, https, runtime){

    function pageInit(scriptContext) {
        log.debug("inside Page init");
    }

    function directApproveWorkorder(workOrderId, status, issueValue){
        try{
            /**
             * Direct Approve
             */
            let userId = runtime.getCurrentUser().id;
            log.debug("DEBUG FUNCTION DATA", "workOrderId: "+workOrderId+" | status: "+status+" | issueValue: "+issueValue);
            if(status){
                log.debug("Status is True!");
                /**
                 * Just set the status to approved & create PO
                 */
                let workOrderRecord = record.load({type: 'workorder',id: workOrderId});
                workOrderRecord.setValue({fieldId: 'custbody_c60520_wo_app_status',value:1});
                workOrderRecord.setValue({fieldId: 'custbody_c60520_wo_approver',value: userId});
                workOrderRecord.save({enableSourcing: true,ignoreMandatoryFields: true});

                /**
                 * Create PO For INVENTORY ITEM LINES: 
                 */

                openMRScript(workOrderId);


                window.location.reload(); 

            }else if(!status){
                log.debug("Status is False!");
                /**
                 * Check the issue and thow error properly.
                 */

                let flag = false;
                let otherFlag = false;

                if(Number(issueValue) == 0){
                    alert("List/Quoted Price Not Found!");
                    flag = true;
                }else if(Number(issueValue) == 1){
                    alert("List Price is less then Quoted Price!");
                    flag = true;
                }else if(Number(issueValue) == 2){
                    alert("Please Set Vendor For All Lines!");
                    flag = true;
                }else if(Number(issueValue) == 3){
                    alert("Please Set Work Date For All Lines!");
                    flag = true;
                }else if(Number(issueValue) == 4){
                    alert("Please Set Quoted Price For All Lines!");
                    flag = true;
                }else if(Number(issueValue) == 5){
                    alert("Please Set Vendor For All Lines!");
                    otherFlag = true;
                }else if(Number(issueValue) == 6){
                    alert("Please Set Work Date For All Lines!");
                    otherFlag = true;
                }else if(Number(issueValue) == 7){
                    alert("Please Set Quoted Price For All Lines!");
                    otherFlag = true;
                }

                if(flag || otherFlag){
                    return;
                }

                

                if(!flag){
                    log.debug("Inside Flag!");
                    let workOrderRecord = record.load({type: 'workorder',id: workOrderId});
                    workOrderRecord.setValue({fieldId: 'custbody_c60520_wo_app_status',value:1});
                    workOrderRecord.setValue({fieldId: 'custbody_c60520_wo_approver',value:userId});
                    workOrderRecord.save({enableSourcing: true,ignoreMandatoryFields: true});  
                    window.location.reload();                   
                }

                if(!otherFlag){
                    log.debug("Inside otherFlag!");
                    let workOrderRecord = record.load({type: 'workorder',id: workOrderId});
                    workOrderRecord.setValue({fieldId: 'custbody_c60520_wo_app_status',value:2});
                    workOrderRecord.save({enableSourcing: true,ignoreMandatoryFields: true});  

                    openMRScript(workOrderId);
                    window.location.reload();  
                }              
                
            }

            
        }catch(e){
            log.debug('Exception in function directApproveWorkorder : ',[e.message, e.stack]);
        }
    }

    function openMRScript(workOrderId){
        try{

            var slCallOne = url.resolveScript({
                scriptId: 'customscript_c60520_su_mr_call_po',
                deploymentId: 'customdeploy_c60520_su_mr_call_po',
                returnExternalUrl: false,
                params: {'woid': workOrderId}
            });  
            log.debug("slCallOne", slCallOne);       
            https.get({url: slCallOne});
        }catch(e){
            log.debug('Exception while opening Main Suitelet : ',[e.message, e.stack]);
        }
    }

    return {
        pageInit: pageInit,
        directApproveWorkorder: directApproveWorkorder
    };
    
});

/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED:
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/task'], function (task) {


	function afterSubmit(context) {
		try {
			var recObj = context.newRecord;
			var shipmentStatus = recObj.getValue({fieldId: 'shipmentstatus'});
			log.debug("shipmentStatus", shipmentStatus);

			if (shipmentStatus != 'received') {
				var mrTask = task.create({
					taskType: task.TaskType.MAP_REDUCE,
					scriptId: 'customscript_css_mr_inbound_phase',
					//deploymentId: availableJobId[randomId],
					params: { custscript_c_sp_inbound_shipment: recObj.id }
				});
				mrTask.submit();
			}
		}
		catch (e) { log.error('Error', e) }
	}


	return {
		afterSubmit: afterSubmit
	};
});
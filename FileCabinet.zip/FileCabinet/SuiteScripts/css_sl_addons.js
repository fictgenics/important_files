/**
 * Module Description
 *
 * Version    Date            Author
 * 2.00       29 April 2019     Naim
 *
 *
 * Last Modified:
 */

/**
 * Type    : SUITELET
 *
 * Description :
 * Genrating a wave.
 *
 */

/**
 *@NApiVersion 2.x
 *@NScriptType Suitelet
 *@NModuleScope Public
 */
define(['N/record', 'N/search', 'N/task'
],
    /**
       * @param {https} https
       * @param {record} record
       * @param {url} url
       * @param {file} file
       * @param {search} search
       * @param {task} task
       * @return {{onRequest: onRequest}}
       */
    function (record, search, task) {

        function onRequest(context) {

            if (context.request.method === 'GET') {
                try {
                    var soId = context.request.parameters.soId;
                    log.debug('soId', soId);

                    var myTask = task.create({
                        taskType: task.TaskType.MAP_REDUCE,
                        scriptId: 'customscript_css_mr_addons',
                        //deploymentId: 'customdeploy_css_ss_pickup_form' ,
                        params: { custscript_c_sp_so_id: soId }
                    });
                    var taskId = myTask.submit();
                    log.debug('taskId', taskId);

                    var resultResp = JSON.stringify('Success');
                    context.response.write(resultResp);
                } catch (e) {
                    log.error({ title: e.name, details: e.toString() });
                    var resultResp = JSON.stringify('Fail');
                    context.response.write(resultResp);
                }
            }

        }

        return { onRequest: onRequest };
    });
/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH 58005,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 9/Feb/2022
* DESCRIPTION:
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
 define(['N/currentRecord'],
 
	function(currentRecord) { 
		
		 function saveRecord(context) {
			
			try{
				var currentRecord = context.currentRecord;
				var depositAmt = currentRecord.getValue({
					fieldId:'payment'
				});
				var count = currentRecord.getLineCount('recmachcustrecord_c58005_dep_cust_deposit');	
				log.debug('count',count);
				var totalAmt = 0;
				if(count>0){
					for(var aa=0; aa<count; aa++){
						
						var amount = currentRecord.getSublistValue({
							sublistId: 'recmachcustrecord_c58005_dep_cust_deposit',
							fieldId: 'custrecord_c58005_dep_milestone_amt',
							line: aa
						});
						
						totalAmt += amount;
					}
					if(depositAmt <= totalAmt){
						alert('Quotaion will not be converted because Unapplied balance should be greater than 0');
					}
				}
				var unappliedAmt = depositAmt-totalAmt;
				log.debug('DEBUG','totalAmt: '+totalAmt+'==='+'unappliedAmt: '+unappliedAmt+'==='+'depositAmt: '+depositAmt);
				currentRecord.setValue({
					fieldId:'custbody_c58005_applied_amt',
					value:totalAmt
				});
				currentRecord.setValue({
					fieldId:'custbody_c58005_unapplied_amt',
					value:unappliedAmt
				});
				return true;
			}
			catch(ex) {
				log.error('Error','Message: '+ex.toString());
			}
		}
		
		return {
			saveRecord: saveRecord
		}
	}
 );
var submitconvert1 = document.getElementById('tbl_item_copy');
submitconvert1.style.display = 'none';
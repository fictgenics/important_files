/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Set Terms.js
* DEVOPS TASK: DD/59537
* AUTHOR: Akash Sharma
* DATE CREATED: 27 April, 2023
* DESCRIPTION: This Script is for setting default terms on PO & Quote.                          
*****************************************************************************
* DATE MODIFIED           DEVOPS TASK           AUTHOR             DESCRIPTION
* 
*****************************************************************************/
define(['N/search'], function(search) {
    
    
    function fieldChanged(scriptContext){
        try{
            var currentRecord = scriptContext.currentRecord;
            var fieldName = scriptContext.fieldId;

            /**
             * On Subsidiary Change we need to change terms from default terms.
             */
            if(fieldName == 'subsidiary' || fieldName == 'entity'){
                var subsidiaryValue = currentRecord.getValue({fieldId: 'subsidiary'});
                if (subsidiaryValue) {
                    var fieldLookup = search.lookupFields({
                        type: search.Type.SUBSIDIARY,
                        id: Number(subsidiaryValue),
                        columns: ['custrecord_c60520_default_terms']
                    });
        
                    fieldLookup = fieldLookup.custrecord_c60520_default_terms;
                    if(fieldLookup.length > 0){
                       currentRecord.setValue({fieldId: 'terms', value: fieldLookup[0].value});
                    }else{
                        currentRecord.setValue({fieldId: 'terms', value: ""});
                    }
                }
            }

        } catch(e) {
            console.error("Error Inside fieldchanged", [e.message, e.stack]);
        }
    }

    return {fieldChanged: fieldChanged};
    
});

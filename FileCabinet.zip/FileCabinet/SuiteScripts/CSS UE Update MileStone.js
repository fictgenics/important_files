/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
define(['N/record', 'N/search'], function (record, search) {


	function beforeSubmit(context) {
		try {

			var recordOrder = context.newRecord;
			var salesOrderId = recordOrder.id;

			var salesOrderRec = record.load({ type: 'salesorder', id: salesOrderId });
			var salesOrderStatus = salesOrderRec.getValue({ fieldId: 'status' });
			log.debug('salesOrderStatus', salesOrderStatus);

			if (salesOrderStatus == 'Pending Fulfillment' && context.type == 'edit') {
				var oldSalesOrderAmount = parseFloat((context.oldRecord.getValue({ fieldId: 'total' })).toFixed(2));
				var newSalesOrderAmount = parseFloat((context.newRecord.getValue({ fieldId: 'total' })).toFixed(2));

				log.debug('oldSalesOrderAmount', oldSalesOrderAmount);
				log.debug('newSalesOrderAmount', newSalesOrderAmount);



				var customrecord_c58005_payment_milestoneSearchObj = search.create({
					type: "customrecord_c58005_payment_milestone",
					filters: [
						["custrecord_c58005_salesorder", "anyof", salesOrderId]
					],
					columns: [
						search.createColumn({ name: "internalid", label: "Internal ID" }),
						search.createColumn({ name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request" }),
						search.createColumn({ name: "custrecord_c58005_milestone", label: "Milestone %" }),
						search.createColumn({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }),
						search.createColumn({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" })
					]
				});
				var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
				log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

				var orderPhaseAmount;// = 10;
				var workOrderPhaseAmount;// = 20;
				var deliveryPhaseAmount;// = 30;
				var postDeliveryPhaseAmount;// = 40;

				var orderPhasePercentage;// = 10;
				var workOrderPhasePercentage;// = 20;
				var deliveryPhasePercentage;// = 30;
				var postDeliveryPhasePercentage;// = 40;

				if (searchResultCount > 0) {
					customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
						var currentMSType = result.getValue({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });
						if (currentMSType) {
							switch (Number(currentMSType)) {
								case 1: //Order Phase
									orderPhaseAmount = parseFloat((parseFloat(result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }))).toFixed(2));
									orderPhasePercentage = parseFloat(result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }));
									break;
								case 2: //WO Phase
									workOrderPhaseAmount = parseFloat((parseFloat(result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }))).toFixed(2));
									workOrderPhasePercentage = parseFloat(result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }));
									break;
								case 3: //Delivery Phase
									deliveryPhaseAmount = parseFloat((parseFloat(result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }))).toFixed(2));
									deliveryPhasePercentage = parseFloat(result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }));
									break;
								case 4: //PD Phase
									postDeliveryPhaseAmount = parseFloat((parseFloat(result.getValue({ name: "custrecord_c58005_milestone_amount", label: "Milestone Amount" }))).toFixed(2));
									postDeliveryPhasePercentage = parseFloat(result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }));
									break;
							}
						}
						return true;
					});
				}
				log.debug("AMOUNT", "orderPhaseAmount: " + orderPhaseAmount + " || workOrderPhaseAmount: " + workOrderPhaseAmount + " || deliveryPhaseAmount: " + deliveryPhaseAmount + " || postDeliveryPhaseAmount: " + postDeliveryPhaseAmount);
				log.debug("PERCENAGE", "orderPhasePercentage: " + orderPhasePercentage + " || workOrderPhasePercentage: " + workOrderPhasePercentage + " || deliveryPhasePercentage: " + deliveryPhasePercentage + " || postDeliveryPhasePercentage: " + postDeliveryPhasePercentage);


				var salesOrderAmountDifference = parseFloat(newSalesOrderAmount) - parseFloat(oldSalesOrderAmount);
				log.debug("salesOrderAmountDifference", salesOrderAmountDifference);

				if (salesOrderAmountDifference !== 0) {
					var newWorkOrderPhaseAmount = (parseFloat(workOrderPhaseAmount + (workOrderPhasePercentage * salesOrderAmountDifference / (100 - orderPhasePercentage)))).toFixed(2);
					var newDeliveryPhaseAmount = (parseFloat(deliveryPhaseAmount + (deliveryPhasePercentage * salesOrderAmountDifference / (100 - orderPhasePercentage)))).toFixed(2);
					var newPostDeliveryPhaseAmount = (parseFloat(postDeliveryPhaseAmount + (postDeliveryPhasePercentage * salesOrderAmountDifference / (100 - orderPhasePercentage)))).toFixed(2);

					log.debug('newWorkOrderPhaseAmount', newWorkOrderPhaseAmount);
					log.debug('newDeliveryPhaseAmount', newDeliveryPhaseAmount);
					log.debug('newPostDeliveryPhaseAmount', newPostDeliveryPhaseAmount);

					if (searchResultCount > 0) {
						customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
							var currentMSType = result.getValue({ name: "custrecord_c58005_milestone_type", label: "Milestone Type" });
							if (currentMSType) {
								var milestoneID = result.getValue({ name: "internalid", label: "Internal ID" });
								switch (Number(currentMSType)) {
									case 2: //WO Phase
										record.submitFields({ type: 'customrecord_c58005_payment_milestone', id: milestoneID, values: { 'custrecord_c58005_milestone_amount': newWorkOrderPhaseAmount, 'custrecord_c58005_milestone_remain_amt': newWorkOrderPhaseAmount } });
										break;
									case 3: //Delivery Phase
										record.submitFields({ type: 'customrecord_c58005_payment_milestone', id: milestoneID, values: { 'custrecord_c58005_milestone_amount': newDeliveryPhaseAmount, 'custrecord_c58005_milestone_remain_amt': newDeliveryPhaseAmount } });
										break;
									case 4: //PD Phase
										record.submitFields({ type: 'customrecord_c58005_payment_milestone', id: milestoneID, values: { 'custrecord_c58005_milestone_amount': newPostDeliveryPhaseAmount, 'custrecord_c58005_milestone_remain_amt': newPostDeliveryPhaseAmount } });
										break;
								}
							}
							return true;
						});
					}
				}
			}
		} catch (e) {
			log.error('ERROR', 'Exception: ' + e.toString());
		}
	}
	return {
		beforeSubmit: beforeSubmit
	};
});
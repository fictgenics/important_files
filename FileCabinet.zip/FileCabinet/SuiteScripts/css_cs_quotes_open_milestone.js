/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: css_cs_open_payment.js
* DEVOPS TASK: ENH 58209,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 9/Feb/2022
* DESCRIPTION: T'Approved'.
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/currentRecord', 'N/search', './lodash.min'],

	function (currentRecord, search, lodash) {

		var deposite = 0;
		var customerDeposite = 0;
		var milestoneCnt = 0;
		var milestoneArray = [];

		function pageInit(context) {
			if (context.mode != 'create') {
				var currentRecord = context.currentRecord;
				milestoneCnt = currentRecord.getLineCount({ sublistId: 'custpage_open_milestone_list' });
				for (var y = 0; y < milestoneCnt; y++) {
					var milestoneName = currentRecord.getSublistValue({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_payment_milestone", line: y });
					var milestoneTypeid = currentRecord.getSublistValue({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_milestone_type_id", line: y });
					milestoneArray.push({ 'milestoneName': milestoneName, 'milestoneTypeid': milestoneTypeid })
				}
                
				var custId = currentRecord.getValue({ fieldId: 'entity' });
				var custLookUp = search.lookupFields({
					type: 'customer',
					id: custId,
					columns: ['depositbalance']
				});
				var depsiteBalance = custLookUp.depositbalance;
				if (depsiteBalance) {
					deposite = depsiteBalance;
					customerDeposite = depsiteBalance;
				}

				var filters =
					[
						[[["custrecord_c58005_customer", "anyof", custId], "AND", ["custrecord_c58005_salesorder.status", "noneof", "SalesOrd:G"], "AND", ["custrecord_c58005_salesorder.mainline", "is", "T"], "AND", ["custrecord_c58005_quotation.status","noneof","Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]], "OR", [["custrecord_c58005_customer", "anyof", custId], "AND", ["custrecord_c58005_salesorder", "anyof", "@NONE@"], "AND", ["custrecord_c58005_quotation.status","noneof","Estimate:X"], "AND", ["custrecord_c58005_quotation.mainline", "is", "T"]]],
						"AND",
						["isinactive", "is", "F"],
						"AND",
						["custrecord_c58005_milestone_applied_amt", "isnotempty", ""]
					];

				var columns =
					[
						search.createColumn({ name: "custrecord_c58005_salesorder", label: "Sales Order" }),
						search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" })
					];

				var appliedObj = searchAllRecord('customrecord_c58005_payment_milestone', null, filters, columns);

				var totalApplied = 0;
				var salesArray = [];
				for (var z = 0; z < appliedObj.length; z++) {
					var salesId = appliedObj[z].getValue({ name: "custrecord_c58005_salesorder", label: "Sales Order" });
					var appliedValue = appliedObj[z].getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount" });
					totalApplied = parseFloat(totalApplied) + parseFloat(appliedValue);
					var index = salesArray.indexOf(salesId);
					if (index == '-1' && salesId) {
						salesArray.push(salesId);
					}
				}

				if (salesArray.length > 0) {
					var invoiceSearchObj = search.create({
						type: "invoice",
						filters:
							[
								["type", "anyof", "CustInvc"],
								"AND",
								["createdfrom", "anyof", salesArray],
								"AND",
								["mainline", "is", "T"]
							],
						columns:
							[
								search.createColumn({ name: "amount", summary: "SUM", label: "Amount" })
							]
					});
					var searchResultCount = invoiceSearchObj.runPaged().count;
					if (searchResultCount > 0) {
						var searchResult = invoiceSearchObj.run().getRange({ start: 0, end: 1 });
						var partialTotal = searchResult[0].getValue({ name: "amount", summary: "SUM", label: "Amount" });
						totalApplied = totalApplied - partialTotal;
					}
				}

				deposite = deposite - totalApplied;
				var unapplied = customerDeposite - totalApplied;
				//alert(deposite);
			}
		}

		function fieldChanged(context) {
			var sublistName = context.sublistId;
			var sublistFieldName = context.fieldId;
			if (sublistName == 'custpage_open_milestone_list' && sublistFieldName == 'custpage_mark_payment') {
				var currentRecord = context.currentRecord;
				var markPayment = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment' });
				if (markPayment) {
					var milestoneAmt = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_amount' });
					var currentApplied = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_current_applied' });
					var appliedToAmt = milestoneAmt - currentApplied;

					currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: appliedToAmt, ignoreFieldChange: false });
				}
				else {
					currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: '', ignoreFieldChange: false });
				}
			}

			if (sublistName == 'custpage_open_milestone_list' && sublistFieldName == 'custpage_applied_now') {
				var currentRecord = context.currentRecord;
				var appliedTo = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now' });
				if (appliedTo) {
					var milestoneAmt = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_amount' });
					var currentApplied = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_current_applied' });
					var appliedToAmt = milestoneAmt - currentApplied;

					if (parseFloat(appliedTo) > parseFloat(appliedToAmt)) {
						currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: '', ignoreFieldChange: false });
						alert('You enter extra applied amount.');
					}
				}
			}
		}


		function validateLine(context) {
			if (context.sublistId == 'custpage_open_milestone_list') {

				var recObj = context.currentRecord;
				var lineCnt = recObj.getLineCount({ sublistId: 'custpage_open_milestone_list' });
				var milestoneId = recObj.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_id' });
				var lineNum = recObj.findSublistLineWithValue({
					sublistId: 'custpage_open_milestone_list',
					fieldId: 'custpage_milestone_id',
					value: milestoneId
				});

				var appliedNow = 0;
				for (var x = 0; x < lineCnt; x++) {
					var markPayment = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment', line: x });
					if (markPayment && x != lineNum) {
						var appliedAmt = recObj.getSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', line: x });
						appliedNow = parseFloat(appliedNow) + parseFloat(appliedAmt);
					}
				}
				var lineApplied = recObj.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now' });
				appliedNow = parseFloat(appliedNow) + parseFloat(lineApplied);

				if (parseFloat(appliedNow) > parseFloat(deposite)) {
					alert("You do not have enough deposit to mark payment on this milestone.");
					return false;
				}
			}
			return true;
		}


		function lineInit(context) {
			var currentRecord = context.currentRecord;
			var sublistName = context.sublistId;
			if (sublistName == 'custpage_open_milestone_list') {
				var lineNum = currentRecord.getCurrentSublistIndex({ sublistId: 'custpage_open_milestone_list' });
				if (lineNum < milestoneCnt) {
					var milestoneType = currentRecord.getSublistValue({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_milestone_type_id", line: lineNum });

					if (milestoneType != '1') {
						var lineMilestone = currentRecord.getSublistValue({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_payment_milestone", line: lineNum });
						if (milestoneType == 2) {
							var newMilestoneName = lineMilestone.replace("Work Order Release", "Order Phase");
						}
						else if (milestoneType == 3) {
							var newMilestoneName = lineMilestone.replace("Delivery Phase", "Work Order Release");
						}
						else if (milestoneType == 4) {
							var newMilestoneName = lineMilestone.replace("Post-Delivery", "Delivery Phase");
						}

						var index = _.findIndex(milestoneArray, function (o) { return o.milestoneName == newMilestoneName && o.milestoneTypeid == milestoneType - 1; });

						if (index > -1) {
							var markField = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_mark_payment", line: lineNum });
							markField.isDisabled = true;
							var applyNow = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_applied_now", line: lineNum });
							applyNow.isDisabled = true;
						}
						else {
							var markField = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_mark_payment", line: lineNum });
							markField.isDisabled = false;
							var applyNow = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_applied_now", line: lineNum });
							applyNow.isDisabled = false;
						}
					}
					else {
						var markField = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_mark_payment", line: lineNum });
						markField.isDisabled = false;
						var applyNow = currentRecord.getSublistField({ sublistId: "custpage_open_milestone_list", fieldId: "custpage_applied_now", line: lineNum });
					    applyNow.isDisabled = false;
					}
				}
			}
		}


		function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
			try {
				var arrSearchResults = [];
				var count = 1000,
					min = 0,
					max = 1000;
				var searchObj = false;
				if (recordType == null) {
					recordType = null;
				}
				if (searchId) {
					searchObj = search.load({
						id: searchId
					});
					if (searchFilter) {
						searchObj.filterExpression = searchFilter;
					}
				} else {
					searchObj = search.create({
						type: recordType,
						filters: searchFilter,
						columns: searchColumns
					})
				}

				var rs = searchObj.run();
				//searchColumns.push(rs.columns);
				//allColumns = rs.columns;

				while (count == 1000) {
					var resultSet = rs.getRange({
						start: min,
						end: max
					});
					if (resultSet != null) {
						arrSearchResults = arrSearchResults.concat(resultSet);
						min = max;
						max += 1000;
						count = resultSet.length;
					}
				}
			} catch (e) {
				//log.debug('Error searching for Customer:- ', e.message);
			}
			return arrSearchResults;
		}

		return {
			pageInit: pageInit,
			fieldChanged: fieldChanged,
			validateLine: validateLine,
			lineInit: lineInit
		}
	}
);
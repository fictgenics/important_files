function hidePriceBeforeLoad(type)
{

	var sublistColumnToHide = nlapiGetLineItemField('item', 'grossamt');
	if(sublistColumnToHide != null)
    {
		sublistColumnToHide.setDisplayType('hidden');
	}

	var sublistColumnToHide = nlapiGetLineItemField('item', 'amount');
	if(sublistColumnToHide != null)
    {
		sublistColumnToHide.setDisplayType('hidden');
	}

	var sublistColumnToHide = nlapiGetLineItemField('item', 'tax1amt');
	if(sublistColumnToHide != null)
    {
		sublistColumnToHide.setDisplayType('hidden');
	}

	var sublistColumnToHide = nlapiGetLineItemField('item', 'taxcode');
	if(sublistColumnToHide != null) 
    {
		sublistColumnToHide.setDisplayType('hidden');
	}

	var sublistColumnToHide = nlapiGetLineItemField('item', 'rate');
	if(sublistColumnToHide != null)
    {
		sublistColumnToHide.setDisplayType('hidden');
	}

	var sublistColumnToHide = nlapiGetLineItemField('item', 'taxrate1');
	if(sublistColumnToHide != null)
    {
		sublistColumnToHide.setDisplayType('hidden');
	}
}
/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/*****************************************************************************
 *  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SS Create Quality Data Details.js
* DEVOPS TASK: ----
* AUTHOR: Akash Sharma
* DATE MODIFIED: 25 Oct, 2023
* DESCRIPTION: This Script is for calculating quality data details.                      
*****************************************************************************/
define(['N/task'], (task) => {
    /**
     * Defines the function definition that is executed before record is loaded.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @param {Form} scriptContext.form - Current form
     * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
     * @since 2015.2
     */
    const beforeLoad = (scriptContext) => {
    }

    /**
     * Defines the function definition that is executed before record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const beforeSubmit = (scriptContext) => {

        try {
            if (scriptContext.type === scriptContext.UserEventType.EDIT || scriptContext.type === scriptContext.UserEventType.CREATE) {
                var qualityDataRec = scriptContext.newRecord;
                var specification = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                var inspection = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                var item = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_item' });
                var actionType = qualityDataRec.getValue({ fieldId: 'custrecord_qm_action_type' });
                log.debug("actionType", actionType);

                if (specification && inspection && item && actionType) {
                    let createQDD = task.create({ taskType: task.TaskType.SCHEDULED_SCRIPT, scriptId: 'customscript_css_ss_create_qdd', deploymentId: 'customdeploy_css_ss_create_qdd', params: {} });
                    createQDD.params = { 'custscript_qdd_item': item, 'custscript_recordid': qualityDataRec.id, 'custscript_action_type': actionType };
                    createQDD.submit();
                }
            }
        } catch (e) {
            log.error("Error Inside before Submit", e.message);
        }
    }

    /**
     * Defines the function definition that is executed after record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const afterSubmit = (scriptContext) => {
        try {
            if (scriptContext.type === scriptContext.UserEventType.EDIT) {
                var qualityDataRec = scriptContext.newRecord;
                var specification = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                var inspection = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                var item = qualityDataRec.getValue({ fieldId: 'custrecord_qm_quality_data_item' });
                var actionType = qualityDataRec.getValue({ fieldId: 'custrecord_qm_action_type' });
                log.debug("actionType", actionType);

                if (specification && inspection && item && actionType) {
                    let createQDD = task.create({ taskType: task.TaskType.SCHEDULED_SCRIPT, scriptId: 'customscript_css_ss_create_qdd', deploymentId: 'customdeploy_css_ss_create_qdd', params: {} });
                    createQDD.params = { 'custscript_qdd_item': item, 'custscript_recordid': qualityDataRec.id, 'custscript_action_type': actionType };
                    createQDD.submit();
                }
            }
        } catch (e) {
            log.error("Error Inside before Submit", e.message);
        }

    }

    return { beforeLoad, beforeSubmit, afterSubmit }

});

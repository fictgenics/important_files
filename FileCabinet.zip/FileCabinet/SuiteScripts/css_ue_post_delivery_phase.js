/**
    * @NApiVersion 2.x
    * @NScriptType UserEventScript
    * @NModuleScope SameAccount
*/
/**
    * Script Name          : CSS UE POST DELIVERY PHASE  
    * Author               : Naim
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Discription          : This script link the invoice to it's ralative phases.
    * Version              : 2.0
*/
define(['N/search', 'N/record'],

    function (search, record) {

        /**
            * Function definition to be triggered before record is loaded.
            *
            * @param {Object} scriptContext
            * @param {Record} scriptContext.newRecord - New record
            * @param {string} scriptContext.type - Trigger type
            * @param {Form} scriptContext.form - Current form
            * @Since 2015.2
        */

        function afterSubmit(context) {
            try {
                if (context.type == context.UserEventType.CREATE) {
                    var recObj = context.newRecord;
                    var itemFulfillment = recObj.getValue({ fieldId: 'custbody_c57685_item_fulfillment' });
                    log.debug("itemFulfillment", itemFulfillment);

                    if (itemFulfillment) {
                        var customrecord_c58005_payment_milestoneSearchObj = search.create({
                            type: "customrecord_c58005_payment_milestone",
                            filters:
                                [
                                    ["custrecord_c58005_item_fulfillment", "anyof", itemFulfillment]
                                ],
                            columns:
                                [
                                    search.createColumn({ name: "internalid", label: "Internal ID" })
                                ]
                        });
                        var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                        log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

                        //This search result did not contain more than 3 results.
                        customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                            var milestoneId = result.getValue({ name: "internalid", label: "Internal ID" });

                            record.submitFields({
                                type: 'customrecord_c58005_payment_milestone',
                                id: milestoneId,
                                values: {
                                    custrecord_c58005_invoice: recObj.id
                                },
                                options: {
                                    enableSourcing: true,
                                    ignoreMandatoryFields: true
                                }
                            });

                            return true;
                        });
                    }
                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }

        return {
            afterSubmit: afterSubmit
        };

    });	
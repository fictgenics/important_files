/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
define(['N/record', 'N/search'],function(record,search){
	
	function afterSubmit(context)
	{
		try {
			
			var recordOrder = context.newRecord;
			var recId       = recordOrder.id;
			
			var depositRec = record.load({
				type:'customerdeposit',
				id:recId
			});
			var unappliedAmt = depositRec.getValue({
				fieldId:'custbody_c58005_unapplied_amt'
			});
			var count = depositRec.getLineCount({
				sublistId:'recmachcustrecord_c58005_dep_cust_deposit'
			});
			log.debug('DEBUG', 'count: ' +count+'==='+'unappliedAmt: ' +unappliedAmt);
			if(count>0 && unappliedAmt > 0.00){
				
				for(var aa=0; aa<count; aa++){
					log.debug('DEBUG', 'count: ' +count);
					var salesOrder = depositRec.getSublistValue({
						sublistId: 'recmachcustrecord_c58005_dep_cust_deposit',
						fieldId: 'custrecord_c58005_dep_salesorder',
						line: aa
					});
					log.debug('DEBUG', 'salesOrder: ' +salesOrder);
					if(!isNotNull(salesOrder)){
						var quotation = depositRec.getSublistValue({
							sublistId: 'recmachcustrecord_c58005_dep_cust_deposit',
							fieldId: 'custrecord_c58005_dep_quotation',
							line: aa
						});
						log.debug('DEBUG', 'quotation: ' +quotation);
						if(isNotNull(quotation)){
							log.debug('DEBUG', 'test');
							var estimateRec = record.transform({
								fromType: record.Type.ESTIMATE,
								fromId: quotation,
								toType: record.Type.SALES_ORDER,
								isDynamic: true,
							});
							var soId = estimateRec.save({
								ignoreMandatoryFields:true
							});
							log.debug('DEBUG', 'soId: ' +soId); 
							depositRec.setSublistValue({
								sublistId: 'recmachcustrecord_c58005_dep_cust_deposit',
								fieldId: 'custrecord_c58005_dep_salesorder',
								value:soId,
								line: aa
							});
						}
					}
				}
				var depositId = depositRec.save({
					ignoreMandatoryFields:true
				});
				log.debug('DEBUG', 'depositId: ' +depositId); 
		
			}
			
		} catch(e) {
			log.error('ERROR','Exception: ' + e.toString());
		}
	}
		
	return{
		afterSubmit:afterSubmit
	};
});

function isNotNull(aVal)
{
	if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
	return true;
	else
	return false;
}
/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Payment Allocation PDF.js
* DEVOPS TASK: BL/59158
* AUTHOR: Akash Sharma
* DATE CREATED: 14-March-2023
* DESCRIPTION: This script is for function call from user event & to call suitelet to generate pdf.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/record', 'N/url', 'N/format','N/search','N/query','N/currentRecord'],

function(record, url, format, search, query, currentRecord){
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        log.debug("inside Page init");
    }

    function openPDF(customerId){
        try{

            log.debug("customerId",customerId);

            /**Suitelet For Filters */
            var slCallOne = url.resolveScript({
                scriptId: 'customscript_c57685_su_payment_alloc_pdf',
                deploymentId: 'customdeploy_c57685_su_payment_alloc_pdf',
                returnExternalUrl: false,
                params: {
                    'customerid': customerId,
                    'frompdf': false
                }
            });         
            window.open(slCallOne,'_blank');
        }catch(e){
            log.debug('Exception while opening Main Suitelet : ',[e.message, e.stack]);
        }
    } 

    function generatePDF(customerId){
        try{

            console.log("Inside generatePDF Function!");

            log.debug("customerId",customerId);

            var form = currentRecord.get();
            var fromDate = form.getValue({fieldId: 'custpage_pas_fromdate'});
            var toDate = form.getValue({fieldId: 'custpage_pas_todate'});

            if(fromDate && toDate){
                /**Suitelet For Filters */
                console.log("beforefromDate",fromDate);
                console.log("before toDate",toDate);
                fromDate = formattingDate(fromDate);
                toDate = formattingDate(toDate);

                console.log("again fromDate",fromDate);
                console.log("again toDate",toDate);

                var slCallOne = url.resolveScript({
                    scriptId: 'customscript_c57685_su_payment_alloc_pdf',
                    deploymentId: 'customdeploy_c57685_su_payment_alloc_pdf',
                    returnExternalUrl: false,
                    params: {
                        'customerid': customerId,
                        'frompdf': true,
                        'fromdate':fromDate,
                        'todate': toDate
                    }
                });         
                window.open(slCallOne,'_blank');
            }else if(!fromDate && !toDate){
                /**Suitelet For Filters */
                var slCallOne = url.resolveScript({
                    scriptId: 'customscript_c57685_su_payment_alloc_pdf',
                    deploymentId: 'customdeploy_c57685_su_payment_alloc_pdf',
                    returnExternalUrl: false,
                    params: {
                        'customerid': customerId,
                        'frompdf': true
                    }
                });         
                window.open(slCallOne,'_blank');
            }
            
        }catch(e){
            log.debug('Exception while opening Main Suitelet : ',[e.message, e.stack]);
        }
    } 

    function formattingDate(objDate){
        try{
          return format.format({type: format.Type.DATE, value: objDate});
        }catch(e){
          log.error("Error Inside formattingDate Function",e.message);
        }
      }

 
    function runSuiteQuery(queryString) {
        // log.debug("Query", queryString);
        var resultSet = query.runSuiteQL({query: queryString});
        // log.debug("Query wise Data", resultSet.asMappedResults());
        if(resultSet && resultSet.results && resultSet.results.length > 0) {
            return resultSet.asMappedResults();
        } else {
            return [];
        }
    }

    function isNotNull(aVal){
        if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
            return true;
        else
            return false;
    }


    return {
        pageInit: pageInit,
        openPDF: openPDF,
        generatePDF: generatePDF
    };
    
});

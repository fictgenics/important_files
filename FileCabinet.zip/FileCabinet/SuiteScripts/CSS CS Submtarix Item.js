/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
define(['N/currentRecord','N/record','N/url'],function(currentRecord,record,url){
// var mainVar;
    function pageInit(scriptContext) {
        log.debug("inside Page init");
    }

    function fieldChanged(scriptContext){
        var currentRecord = scriptContext.currentRecord;        
        var fieldName = scriptContext.fieldId;
        var fieldValue = currentRecord.getValue({fieldId: fieldName});
        
        if(fieldValue && fieldValue.length > 1){
            alert('Please select only one!');
            currentRecord.setValue({ fieldId: fieldName, value: fieldValue[0]});
        }



        var customItem = true;

        if(customItem && (customItem == 'T' || customItem == true)){
            var fieldName = scriptContext.fieldId;

            // Define an array of field names

            var fieldNames = [
                { fieldId: 'custpage_my', variable: 'my' },
                { fieldId: 'custpage_steering', variable: 'steering' },
                { fieldId: 'custpage_seats', variable: 'seats' },
                { fieldId: 'custpage_fuel', variable: 'fuel' },
                { fieldId: 'custpage_gear', variable: 'gear' },
                { fieldId: 'custpage_emc', variable: 'emc' },
                { fieldId: 'custpage_esc', variable: 'esc' },
                { fieldId: 'custpage_imc', variable: 'imc' },
                { fieldId: 'custpage_isc', variable: 'isc' },
                { fieldId: 'custpage_upholestriy', variable: 'upholestriy' },
                { fieldId: 'custpage_cabin_type', variable: 'cabinType' },
                { fieldId: 'custpage_drive_train', variable: 'driveTrain' },
                { fieldId: 'custpage_body_type', variable: 'bodyType' },
                { fieldId: 'custpage_territory', variable: 'territory' },
                { fieldId: 'custpage_engine_capacity', variable: 'engineCapacity' },
                { fieldId: 'custpage_coo', variable: 'coo' },
                { fieldId: 'custpage_regional_spec', variable: 'regionalSpec' },
                { fieldId: 'custpage_variant_detail', variable: 'varianceDetail' },
                { fieldId: 'custpage_modifications', variable: 'modifications' },
                { fieldId: 'custpage_sss', variable: 'sss' },
                { fieldId: 'custpage_grade', variable: 'grade' },
                { fieldId: 'custpage_doors', variable: 'doors' },
                { fieldId: 'custpage_wheel', variable: 'wheel' },
                { fieldId: 'custpage_wheel_types', variable: 'wheelTypes' },
                { fieldId: 'custpage_camera', variable: 'camera' },
                { fieldId: 'custpage_parking_sensors', variable: 'parkingSensors' },
                { fieldId: 'custpage_sfx', variable: 'sfx' },
                { fieldId: 'custpage_tss', variable: 'tss' },
                { fieldId: 'custpage_sunroof', variable: 'sunroof' },
                { fieldId: 'custpage_ret', variable: 'ret' },
                { fieldId: 'custpage_ebk', variable: 'ebk' },
                { fieldId: 'custpage_body_accents', variable: 'bodyAccents' },
                { fieldId: 'custpage_side_step', variable: 'sideStep' },
                { fieldId: 'custpage_front_grill', variable: 'frontGrill' },
                { fieldId: 'custpage_sidem', variable: 'sideM' },
                { fieldId: 'custpage_power_seats', variable: 'powerSeats' },
                { fieldId: 'custpage_memory_seats', variable: 'memorySeats' },
                { fieldId: 'custpage_headlampt', variable: 'headlampT' },
                { fieldId: 'custpage_foglamps', variable: 'fogLamps' },
                { fieldId: 'custpage_roof_rails', variable: 'roofRails' },
                { fieldId: 'custpage_seats_ventil', variable: 'seatsVentil' },
                { fieldId: 'custpage_electricb', variable: 'electricB' },
                { fieldId: 'custpage_wirelessc', variable: 'wirelessC' },
                { fieldId: 'custpage_res', variable: 'res' },
                { fieldId: 'custpage_rat', variable: 'rat' },
                { fieldId: 'custpage_hud', variable: 'hud' },
                { fieldId: 'custpage_displays', variable: 'displayS' },
                { fieldId: 'custpage_trw', variable: 'trw' },
                { fieldId: 'custpage_sit', variable: 'sit' },
                { fieldId: 'custpage_fmt', variable: 'fmt' },
                { fieldId: 'custpage_headlampw', variable: 'headlampW' },
                { fieldId: 'custpage_crawlc', variable: 'crawlC' },
                { fieldId: 'custpage_cruisec', variable: 'cruiseC' },
                { fieldId: 'custpage_wgip', variable: 'wgip' },
                { fieldId: 'custpage_airbag', variable: 'airbag' },
                { fieldId: 'custpage_catch_all', variable: 'catchAll' },
                { fieldId: 'custpage_cpillaremblem', variable: 'cpillaremblem' },
                { fieldId: 'custpage_door_handle', variable: 'doorHandle' },
                { fieldId: 'custpage_door_scuffplate', variable: 'doorScuffPlate' },
                { fieldId: 'custpage_door_side_emblm', variable: 'doorSideEmblm' },
                { fieldId: 'custpage_roof_rail_color', variable: 'roofRailColor' },
                { fieldId: 'custpage_roof_rail_type', variable: 'roofRailType' },
                { fieldId: 'custpage_side_mirror', variable: 'sideMirror' },
                { fieldId: 'custpage_win_mould', variable: 'winMould' },
                { fieldId: 'custpage_ac', variable: 'ac' },
                { fieldId: 'custpage_car_play', variable: 'carPlay' },
                { fieldId: 'custpage_arm_rest', variable: 'armRest' },
                { fieldId: 'custpage_bedliner', variable: 'bedliner' },
                { fieldId: 'custpage_shape', variable: 'shape' },
                { fieldId: 'custpage_steering_ctrl', variable: 'steeringCtrl' },
                { fieldId: 'custpage_pintle_hook', variable: 'pintleHook' },
                { fieldId: 'custpage_rollcage', variable: 'rollcage' },
                { fieldId: 'custpage_sos', variable: 'sos' },
                { fieldId: 'custpage_snorkel', variable: 'snorkel' },
                { fieldId: 'custpage_body_kit', variable: 'bodyKit' },
                { fieldId: 'custpage_bumpers', variable: 'bumpers' },
                { fieldId: 'custpage_coolbox', variable: 'coolbox' },
                { fieldId: 'custpage_diff_lock', variable: 'diffLock' },
                { fieldId: 'custpage_fender_type', variable: 'fenderType' },
                { fieldId: 'custpage_front_ac', variable: 'frontAC' },
                { fieldId: 'custpage_grillcolor', variable: 'grillColor' },
                { fieldId: 'custpage_hand_brake', variable: 'handBrake' },
                { fieldId: 'custpage_head_rest', variable: 'headRest' },
                { fieldId: 'custpage_heated_steering', variable: 'heatedSteering' },
                { fieldId: 'custpage_ignition', variable: 'ignition' },
                { fieldId: 'custpage_keyless_entry', variable: 'keylessEntry' },
                { fieldId: 'custpage_lther_trim_stw', variable: 'ltherTrimStw' },
                { fieldId: 'custpage_rear_ac', variable: 'rearAC' },
                { fieldId: 'custpage_rear_tray_ophan', variable: 'rearTrayOphan' },
                { fieldId: 'custpage_rear_window_bar', variable: 'rearWindowBars' },
                { fieldId: 'custpage_remote_eng_star', variable: 'remoteEngStar' },
                { fieldId: 'custpage_roof_spoiler', variable: 'roofSpoiler' },
                { fieldId: 'custpage_side_stripes', variable: 'sideStripes' },
                { fieldId: 'custpage_ster_wheel_cont', variable: 'sterWheelCont' },
                { fieldId: 'custpage_tinted_win', variable: 'custitem_c60520_matrix_tinted_win' },
                { fieldId: 'custpage_rear_step', variable: 'custitem_c60520_matrix_rear_step' },
                { fieldId: 'custpage_window', variable: 'custitem10'}
            ];
            

            // Loop through each field name
            for (var i = 0; i < fieldNames.length; i++) {
                var fieldName = fieldNames[i];
                var field = currentRecord.getValue({ fieldId: fieldName.fieldId});
                if(field && field.length > 1){
                    alert('Please select only one value for ' + fieldName.variable);// + ' || value is : '+field + ' || length is: '+field.length);
                    currentRecord.setValue({ fieldId: fieldName.fieldId, value: field[0]});
                }
            }
        }


            
    }

    function addItem(matrixItemRecordId){
        try{
            // debugger;
            var cr = currentRecord.get();
            var customItem = cr.getValue({fieldId: 'custitem_c60520_create_custom_item'});                
            var itemId = Number(matrixItemRecordId);
            var my = cr.getValue({fieldId: 'custitem9'});
            var steering = cr.getValue({fieldId: 'custitem_c60520_matrix_steering'});
            var seats2 = cr.getValue({fieldId: 'custitem_c60520_matrix_seats'});
            var fuel3 = cr.getValue({fieldId: 'custitem_c60520_matrix_fuel'});
            var gear = cr.getValue({fieldId: 'custitem_c60520_matrix_gear'});
            var emc = cr.getValue({fieldId: 'custitem_c60520_matrix_ext_main_color'});
            var esc = cr.getValue({fieldId: 'custitem_c60520_matrix_ext_sub_color'});
            var imc = cr.getValue({fieldId: 'custitem_c60520_matrix_int_main_color'});
            var isc = cr.getValue({fieldId: 'custitem_c60520_matrix_int_sub_color'});
            var upholestriy = cr.getValue({fieldId: 'custitem_c60520_matrix_upholestriy'});
            var cabinType = cr.getValue({fieldId: 'custitem_c60520_matrix_cabin_type'});
            var driveTrain = cr.getValue({fieldId: 'custitem_c60520_matrix_drive_train'});
            var bodyType = cr.getValue({fieldId: 'custitem_c60520_matrix_body_type'});
            var territoriy = cr.getValue({fieldId: 'custitem_c60520_matrix_territori'});
            var engineCapacity = cr.getValue({fieldId: 'custitem_c60520_matrix_engine_capacity'});
            var coo = cr.getValue({fieldId: 'custitem_c60520_matrix_coo'});
            var regionalSpec = cr.getValue({fieldId: 'custitem_c60520_matrix_regional_spec'});
            var variantDetails = cr.getValue({fieldId: 'custitem_c60520_matrix_variant_detail'});
            var modifications = cr.getValue({fieldId: 'custitem_c60520_matrix_modifications'});
            var sst = cr.getValue({fieldId: 'custitem_c60520_sound_system_type'});
            var grade = cr.getValue({fieldId: 'custitem_c60520_grade'});
            var doors = cr.getValue({fieldId: 'custitem_c60520_doors'});
            var wheels = cr.getValue({fieldId: 'custitem_c60520_wheels'});
            var wheelsType = cr.getValue({fieldId: 'custitem_c60520_wheels_type'});
            var camera = cr.getValue({fieldId: 'custitem_c60520_camera'});
            var parkingSensor = cr.getValue({fieldId: 'custitem_c60520_parking_sensors'});
            var sfx = cr.getValue({fieldId: 'custitem_c60520_sfx'});
            var tss = cr.getValue({fieldId: 'custitem_c60520_tss'});
            var sunroof = cr.getValue({fieldId: 'custitem_c60520_sunroof'});
            var rearEntType = cr.getValue({fieldId: 'custitem_c60520_rear_ent_type'});
            var extendedBodyKit = cr.getValue({fieldId: 'custitem_c60520_extended_body_kit'});
            var bodyAccents = cr.getValue({fieldId: 'custitem_c60520_body_accents'});
            var sideStep = cr.getValue({fieldId: 'custitem_c60520_side_step'});
            var frontGrill = cr.getValue({fieldId: 'custitem_c60520_front_grill'});
            var sideMoulding = cr.getValue({fieldId: 'custitem_c60520_side_moulding'});
            var powerSeats = cr.getValue({fieldId: 'custitem_c60520_power_seats'});
            var memorySeats = cr.getValue({fieldId: 'custitem_c60520_memory_seats'});
            var headlampType = cr.getValue({fieldId: 'custitem_c60520_headlamp_type'});
            var fogLamps = cr.getValue({fieldId: 'custitem_c60520_fog_lamps'});
            var roofRails = cr.getValue({fieldId: 'custitem_c60520_roof_rails'});
            var seatVentilation = cr.getValue({fieldId: 'custitem_c60520_seat_ventilation'});
            var electricBoot = cr.getValue({fieldId: 'custitem_c60520_electric_boot'});
            var wirelessCharger = cr.getValue({fieldId: 'custitem_c60520_wireless_charger'});
            var remoteEngineStarter = cr.getValue({fieldId: 'custitem_c60520_remote_engine_starter'});
            var rearAcType = cr.getValue({fieldId: 'custitem_c60520_rear_ac_type'});
            var headsUpDisplay = cr.getValue({fieldId: 'custitem_c60520_heads_up_display'});
            var displaySize = cr.getValue({fieldId: 'custitem_c60520_display_size'});
            var tintedRearWindows = cr.getValue({fieldId: 'custitem_c60520_tinted_rear_windows'});
            var speedometerInfoType = cr.getValue({fieldId: 'custitem_c60520_speedometer_info_type'});
            var frontMonoType = cr.getValue({fieldId: 'custitem_c60520_front_mono_type'});
            var headlampWasher = cr.getValue({fieldId: 'custitem_c60520_headlamp_washer'});
            var crawlControl = cr.getValue({fieldId: 'custitem_c60520_crawl_control'});
            var cruiseControl = cr.getValue({fieldId: 'custitem_c60520_cruise_control'});
            var woodGrainIntPackage = cr.getValue({fieldId: 'custitem_c60520_wood_grain_int_package'});
            var airbag = cr.getValue({fieldId: 'custitem_c60520_airbag'});
            var catchAll = cr.getValue({fieldId: 'custitem_c60520_catch_all'});
            var tintedWindow = cr.getValue({ fieldId: 'custitem_c60520_matrix_tinted_win' });
            var rearStep = cr.getValue({ fieldId: 'custitem_c60520_matrix_rear_step' });
            var windows = cr.getValue({ fieldId: 'custitem10' });
            
            var fields = [
                { fieldId: 'matrixoptioncustitem9', variable: my, actualFieldId: 'custitem9' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_steering', variable: steering, actualFieldId: 'custitem_c60520_matrix_steering' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_seats', variable: seats2, actualFieldId: 'custitem_c60520_matrix_seats' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_fuel', variable: fuel3, actualFieldId: 'custitem_c60520_matrix_fuel' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_gear', variable: gear, actualFieldId: 'custitem_c60520_matrix_gear' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_ext_main_color', variable: emc, actualFieldId: 'custitem_c60520_matrix_ext_main_color' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_ext_sub_color', variable: esc, actualFieldId: 'custitem_c60520_matrix_ext_sub_color' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_int_main_color', variable: imc, actualFieldId: 'custitem_c60520_matrix_int_main_color' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_int_sub_color', variable: isc, actualFieldId: 'custitem_c60520_matrix_int_sub_color' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_upholestriy', variable: upholestriy, actualFieldId: 'custitem_c60520_matrix_upholestriy' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_cabin_type', variable: cabinType, actualFieldId: 'custitem_c60520_matrix_cabin_type' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_drive_train', variable: driveTrain, actualFieldId: 'custitem_c60520_matrix_drive_train' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_body_type', variable: bodyType, actualFieldId: 'custitem_c60520_matrix_body_type' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_territori', variable: territoriy, actualFieldId: 'custitem_c60520_matrix_territori' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_engine_capacity', variable: engineCapacity, actualFieldId: 'custitem_c60520_matrix_engine_capacity' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_coo', variable: coo, actualFieldId: 'custitem_c60520_matrix_coo' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_regional_spec', variable: regionalSpec, actualFieldId: 'custitem_c60520_matrix_regional_spec' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_variant_detail', variable: variantDetails, actualFieldId: 'custitem_c60520_matrix_variant_detail' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_modifications', variable: modifications, actualFieldId: 'custitem_c60520_matrix_modifications' },
                { fieldId: 'matrixoptioncustitem_c60520_sound_system_type', variable: sst, actualFieldId: 'custitem_c60520_sound_system_type' },
                { fieldId: 'matrixoptioncustitem_c60520_grade', variable: grade, actualFieldId: 'custitem_c60520_grade' },
                { fieldId: 'matrixoptioncustitem_c60520_doors', variable: doors, actualFieldId: 'custitem_c60520_doors' },
                { fieldId: 'matrixoptioncustitem_c60520_wheels', variable: wheels, actualFieldId: 'custitem_c60520_wheels' },
                { fieldId: 'matrixoptioncustitem_c60520_wheels_type', variable: wheelsType, actualFieldId: 'custitem_c60520_wheels_type' },
                { fieldId: 'matrixoptioncustitem_c60520_camera', variable: camera, actualFieldId: 'custitem_c60520_camera' },
                { fieldId: 'matrixoptioncustitem_c60520_parking_sensors', variable: parkingSensor, actualFieldId: 'custitem_c60520_parking_sensors' },
                { fieldId: 'matrixoptioncustitem_c60520_sfx', variable: sfx, actualFieldId: 'custitem_c60520_sfx' },
                { fieldId: 'matrixoptioncustitem_c60520_tss', variable: tss, actualFieldId: 'custitem_c60520_tss' },
                { fieldId: 'matrixoptioncustitem_c60520_sunroof', variable: sunroof, actualFieldId: 'custitem_c60520_sunroof' },
                { fieldId: 'matrixoptioncustitem_c60520_rear_ent_type', variable: rearEntType, actualFieldId: 'custitem_c60520_rear_ent_type' },
                { fieldId: 'matrixoptioncustitem_c60520_extended_body_kit', variable: extendedBodyKit, actualFieldId: 'custitem_c60520_extended_body_kit' },
                { fieldId: 'matrixoptioncustitem_c60520_body_accents', variable: bodyAccents, actualFieldId: 'custitem_c60520_body_accents' },
                { fieldId: 'matrixoptioncustitem_c60520_side_step', variable: sideStep, actualFieldId: 'custitem_c60520_side_step' },
                { fieldId: 'matrixoptioncustitem_c60520_front_grill', variable: frontGrill, actualFieldId: 'custitem_c60520_front_grill' },
                { fieldId: 'matrixoptioncustitem_c60520_side_moulding', variable: sideMoulding, actualFieldId: 'custitem_c60520_side_moulding' },
                { fieldId: 'matrixoptioncustitem_c60520_power_seats', variable: powerSeats, actualFieldId: 'custitem_c60520_power_seats' },
                { fieldId: 'matrixoptioncustitem_c60520_memory_seats', variable: memorySeats, actualFieldId: 'custitem_c60520_memory_seats' },
                { fieldId: 'matrixoptioncustitem_c60520_headlamp_type', variable: headlampType, actualFieldId: 'custitem_c60520_headlamp_type' },
                { fieldId: 'matrixoptioncustitem_c60520_fog_lamps', variable: fogLamps, actualFieldId: 'custitem_c60520_fog_lamps' },
                { fieldId: 'matrixoptioncustitem_c60520_roof_rails', variable: roofRails, actualFieldId: 'custitem_c60520_roof_rails' },
                { fieldId: 'matrixoptioncustitem_c60520_seat_ventilation', variable: seatVentilation, actualFieldId: 'custitem_c60520_seat_ventilation' },
                { fieldId: 'matrixoptioncustitem_c60520_electric_boot', variable: electricBoot, actualFieldId: 'custitem_c60520_electric_boot' },
                { fieldId: 'matrixoptioncustitem_c60520_wireless_charger', variable: wirelessCharger, actualFieldId: 'custitem_c60520_wireless_charger' },
                { fieldId: 'matrixoptioncustitem_c60520_remote_engine_starter', variable: remoteEngineStarter, actualFieldId: 'custitem_c60520_remote_engine_starter' },
                { fieldId: 'matrixoptioncustitem_c60520_rear_ac_type', variable: rearAcType, actualFieldId: 'custitem_c60520_rear_ac_type' },
                { fieldId: 'matrixoptioncustitem_c60520_heads_up_display', variable: headsUpDisplay, actualFieldId: 'custitem_c60520_heads_up_display' },
                { fieldId: 'matrixoptioncustitem_c60520_display_size', variable: displaySize, actualFieldId: 'custitem_c60520_display_size' },
                { fieldId: 'matrixoptioncustitem_c60520_tinted_rear_windows', variable: tintedRearWindows, actualFieldId: 'custitem_c60520_tinted_rear_windows' },
                { fieldId: 'matrixoptioncustitem_c60520_speedometer_info_type', variable: speedometerInfoType, actualFieldId: 'custitem_c60520_speedometer_info_type' },
                { fieldId: 'matrixoptioncustitem_c60520_front_mono_type', variable: frontMonoType, actualFieldId: 'custitem_c60520_front_mono_type' },
                { fieldId: 'matrixoptioncustitem_c60520_headlamp_washer', variable: headlampWasher, actualFieldId: 'custitem_c60520_headlamp_washer' },
                { fieldId: 'matrixoptioncustitem_c60520_crawl_control', variable: crawlControl, actualFieldId: 'custitem_c60520_crawl_control' },
                { fieldId: 'matrixoptioncustitem_c60520_cruise_control', variable: cruiseControl, actualFieldId: 'custitem_c60520_cruise_control' },
                { fieldId: 'matrixoptioncustitem_c60520_wood_grain_int_package', variable: woodGrainIntPackage, actualFieldId: 'custitem_c60520_wood_grain_int_package' },
                { fieldId: 'matrixoptioncustitem_c60520_airbag', variable: airbag, actualFieldId: 'custitem_c60520_airbag' },
                { fieldId: 'matrixoptioncustitem_c60520_catch_all', variable: catchAll, actualFieldId: 'custitem_c60520_catch_all' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_tinted_win', variable: tintedWindow, actualFieldId: 'custitem_c60520_matrix_tinted_win' },
                { fieldId: 'matrixoptioncustitem_c60520_matrix_rear_step', variable: rearStep, actualFieldId: 'custitem_c60520_matrix_rear_step' },
                { fieldId: 'matrixoptioncustitem10', variable: rearStep, actualFieldId: 'custitem10' }
            ];
            
            alert("field Length"+fields.length);

            if(customItem && (customItem == 'T' || customItem == true || customItem =='True' || customItem == 'true')){
                var createRecord = record.create({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM });
                createRecord.setValue({ fieldId: 'matrixtype', value: 'CHILD' });
                createRecord.setValue({ fieldId: 'parent', value: itemId });
                createRecord.setValue({ fieldId: 'itemid', value: 'Random Name'});
                createRecord.setValue({ fieldId: 'taxschedule', value: 1 });

                for (var i = 0; i < fields.length; i++) {
                    var field = fields[i];
                    var variableValue = field.variable;
                    var variableId = field.fieldId;
                    // Check if the variable has a value
                    if (variableValue && Number(variableValue) > 0) {
                        log.debug('DEBUG:  '+"variableValue is : "+variableValue, "variableId is : "+variableId);
                        createRecord.setValue({ fieldId: variableId, value: variableValue.toString()});
                        // createRecord.setValue({ fieldId: variableId, value: variableValue});
                    }
                }

                alert("After For!");

                var finalSubItemId = createRecord.save({enableSourcing: false,ignoreMandatoryFields: true});
                log.debug("finalSubItemId",finalSubItemId);
                if(finalSubItemId){
                    alert("Submatrix Item Created!");
                    window.location.reload();
                }
            }else{
                alert('Please check "Create Custom Item Box & only selected one option fromm all field!');
            }
        }catch(e){
            log.error("Error Inside addItem Function!", [e.message, e.stack]);
        }
    }

    // function saveRecord(scriptContext){
    //     var currentRecord = scriptContext.currentRecord;        
    //     var fieldValue = currentRecord.getValue({fieldId: 'custpage_ready'});
        
    //     if(fieldValue && (fieldValue == true || fieldValue == 'T')){
    //         return true;
    //     }else{
    //         alert("Please Mark Ready Checkbox True!");
    //         return false;
    //     }
    // }

    return {
        pageInit: pageInit,
        addItem : addItem,
        fieldChanged: fieldChanged,
        // saveRecord: saveRecord
    };
    
});

/*******************************************************************************
*  * Copyright (c) 2024 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Quote.js
* DEVOPS TASK: BACKLOG 71371
* AUTHOR: Anushka Banerjee
* DATE CREATED: 6-3-2024
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */
define(['N/runtime', 'N/email', 'N/search', 'N/record', 'N/url', './lodash.min'], function (runtime, email, search, record, url, lodash) {

    function beforeLoad(context) {
        try {
            let type = context.type;
            let newRecord = context.newRecord;
            let approvalStatus = newRecord.getValue({ fieldId: 'custbody_c60520_wo_app_status' });
            let currentUser = runtime.getCurrentUser();
            log.debug("here", type + "||" + approvalStatus + "||" + currentUser.id + "||" + currentUser.role);

            if (type == 'view') {
                context.form.removeButton('createsalesord');
                context.form.removeButton('createcashsale');
                context.form.removeButton('createinvoice');
                context.form.removeButton('approve');
            }
            if (type == 'view' && approvalStatus && Number(approvalStatus) == 1 && (Number(currentUser.id) == 21 || Number(currentUser.id) == 27 || Number(currentUser.role) == 3)) {
                context.form.clientScriptModulePath = 'SuiteScripts/CSS CS Approve Button.js';
                context.form.addButton({
                    id: 'custpage_accept',
                    label: 'Approve',
                    functionName: 'accept()'
                });
            }
        } catch (error) {
            log.error("Error in beforeLoad", error);
        }
    }

    function beforeSubmit(context) {

    }

    function afterSubmit(context) {
        try {
            const type = context.type;
            let newRecord = context.newRecord;

            log.debug("newRecord", newRecord.type);
            if (type == 'create' && newRecord.type == 'salesorder') {
                log.debug("Creating sales order", newRecord.id);
                record.submitFields({
                    type: 'salesorder',
                    id: newRecord.id,
                    values: { 'custbody_c60520_wo_app_status': 2, 'orderstatus': 'B' }

                });
            }
            else if (type == 'create' && newRecord.type == 'estimate') {
                let newRecord = context.newRecord;
                let lines = newRecord.getLineCount({
                    sublistId: 'item'
                });
                let emailFlag = false;
                let customer = newRecord.getValue({ fieldId: 'entity' });

                //Get the purchase price/ minimum sales price from customer to compare that the total quote/sales order is making a profit
                // let purchasepriceLookup = search.lookupFields({
                //     type: 'customer',
                //     id: item,
                //     columns: 'cost'
                // });
                // log.debug("purchasepriceLookup", purchasepriceLookup);
                let purchasePrice = 35000; // Taking hard-coded value for testing purposes
                let rateTotal = 0;
                for (let iter = 0; iter < lines; iter++) {
                    let rate = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'rate',
                        line: iter
                    });
                    let item = newRecord.getSublistValue({
                        sublistId: 'item',
                        fieldId: 'item',
                        line: iter
                    });
                    // let purchasepriceLookup = search.lookupFields({
                    //     type: 'assemblyitem',
                    //     id: item,
                    //     columns: 'cost'
                    // });
                    // log.debug("purchasepriceLookup", purchasepriceLookup);
                    // let purchasePrice = purchasepriceLookup.cost;
                    rateTotal += +rate;
                    // if (Number(rate) <= Number(purchasePrice)) {
                    //     emailFlag = true;
                    //     break;
                    // }
                    log.debug("rateTotal", rateTotal);
                }
                //Restricted customer
                let isRestricted = search.lookupFields({ type: 'customer', id: customer, columns: 'custentity_c73213_is_restricted_customer' });
                log.debug("isRestricted", isRestricted);
                isRestricted = isRestricted.custentity_c73213_is_restricted_customer;
                if (isRestricted == true || Number(rateTotal) <= Number(purchasePrice)) emailFlag = true;
                //Atleast one line has rate less than or equal to purchase price on item
                emailAndApproval(newRecord, emailFlag);
            }
            else if (type == 'edit') {
                log.debug("in edit mode");
                let oldRecord = context.oldRecord;
                const oldLineItems = lineDataToObject(oldRecord);
                log.debug("oldLineItems", oldLineItems);
                const newLineItems = lineDataToObject(newRecord);
                log.debug("newLineItems", newLineItems);

                const dontCheckFurther = _.isEqual(oldLineItems, newLineItems);
                log.debug("dontCheckFurther", dontCheckFurther);
                if (dontCheckFurther == false) {
                    let emailFlag = false;
                    let customer = newRecord.getValue({ fieldId: 'entity' });
                    //Get the purchase price/ minimum sales price from customer to compare that the total quote/sales order is making a profit
                    // let purchasepriceLookup = search.lookupFields({
                    //     type: 'customer',
                    //     id: item,
                    //     columns: 'cost'
                    // });
                    // log.debug("purchasepriceLookup", purchasepriceLookup);
                    let purchasePrice = 35000; // Taking hard-coded value for testing purposes
                    let rateTotal = 0;
                    Object.values(newLineItems).every((value) => {
                        log.debug(value);
                        // let purchasepriceLookup = search.lookupFields({
                        //     type: 'assemblyitem',
                        //     id: value['item'],
                        //     columns: 'cost'
                        // });
                        // log.debug("purchasepriceLookup", purchasepriceLookup);
                        // let purchasePrice = purchasepriceLookup.cost;
                        // if (Number(value['rate']) <= Number(purchasePrice)) {
                        //     emailFlag = true;
                        //     return false;
                        // }
                        rateTotal+= +value['rate'];
                        log.debug("ratetotal", rateTotal);
                        return true;
                    });
                    //Restricted customer
                    let isRestricted = search.lookupFields({ type: 'customer', id: customer, columns: 'custentity_c73213_is_restricted_customer' });
                    log.debug("isRestricted", isRestricted);
                    isRestricted = isRestricted.custentity_c73213_is_restricted_customer;
                    if (isRestricted == true || Number(rateTotal) <= Number(purchasePrice)) emailFlag = true;
                    log.debug("emailFlag", emailFlag);
                    if (newRecord.type == 'estimate') {
                        emailAndApproval(newRecord, emailFlag);
                    } else {
                        emailAndApprovalSO(newRecord, emailFlag);
                    }
                }

            }
        } catch (error) {
            log.error("Error in afterSubmit", error);
        }
    }

    function lineDataToObject(currentRecord) {
        try {
            const object = {};
            const oldLineCount = currentRecord.getLineCount({ sublistId: 'item' });

            for (let iter = 0; iter < oldLineCount; iter++) {
                let rate = currentRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'rate',
                    line: iter
                });
                let item = currentRecord.getSublistValue({
                    sublistId: 'item',
                    fieldId: 'item',
                    line: iter
                });
                object[iter] = { 'item': item, 'rate': rate };
            }
            return object;
        } catch (error) {
            log.error("Error in lineDataToObject", error);
        }
    }

    function emailAndApproval(newRecord, emailFlag) {
        try {
            if (emailFlag == true) {
                // newRecord.setValue({ fieldId: 'custbody_c60520_wo_app_status', value: 1 });
                record.submitFields({
                    type: 'estimate',
                    id: newRecord.id,
                    values: { 'custbody_c60520_wo_app_status': 1 }

                });
                let quotationNumber = newRecord.getValue({ fieldId: 'tranid' });
                let currentUser = runtime.getCurrentUser().id;
                ///////////////
                var scheme = 'https://';
                var host = url.resolveDomain({ hostType: url.HostType.APPLICATION });
                var recordUrl = url.resolveRecord({ recordType: 'estimate', recordId: newRecord.id, isEditMode: false });
                recordUrl = scheme + host + recordUrl;

                var emailBody = `A Quotation has been raised which has a restricted customer or has an item's rate less than/equal to Purchase Price. Please review and Approve.<br><br><br><a href=${recordUrl}>View Record</a>`;

                var emailSubject = `Quotation has been raised for Approval`;
                var sentEmail = email.send({
                    author: currentUser,
                    body: emailBody,
                    recipients: [21, 27],
                    subject: emailSubject
                });
                log.debug('sentEmail', sentEmail);

            }
            else record.submitFields({
                type: 'estimate',
                id: newRecord.id,
                values: { 'custbody_c60520_wo_app_status': 2 }
            });
        } catch (error) {
            log.error(" Error in emailAndApproval", error);
        }
    }
    function emailAndApprovalSO(newRecord, emailFlag) {
        try {
            if (emailFlag == true) {
                // newRecord.setValue({ fieldId: 'custbody_c60520_wo_app_status', value: 1 });
                record.submitFields({
                    type: 'salesorder',
                    id: newRecord.id,
                    values: { 'custbody_c60520_wo_app_status': 1, 'orderstatus': 'A' }

                });
                // let quotationNumber = newRecord.getValue({ fieldId: 'tranid' });
                let currentUser = runtime.getCurrentUser().id;
                ///////////////
                var scheme = 'https://';
                var host = url.resolveDomain({ hostType: url.HostType.APPLICATION });
                var recordUrl = url.resolveRecord({ recordType: 'salesorder', recordId: newRecord.id, isEditMode: false });
                recordUrl = scheme + host + recordUrl;

                var emailBody = `A Sales Order has been raised which has a restricted customer or has an item's rate less than/equal to Purchase Price. Please review and Approve.<br><br><br><a href=${recordUrl}>View Record</a>`;

                var emailSubject = `Sales Order has been raised for Approval`;
                var sentEmail = email.send({
                    author: currentUser,
                    body: emailBody,
                    recipients: [21, 27],
                    subject: emailSubject
                });
                log.debug('sentEmail', sentEmail);

            }
            else record.submitFields({
                type: 'salesorder',
                id: newRecord.id,
                values: { 'custbody_c60520_wo_app_status': 2, 'orderstatus': 'B' }
            });
        } catch (error) {
            log.error(" Error in emailAndApproval", error);
        }
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    }
});
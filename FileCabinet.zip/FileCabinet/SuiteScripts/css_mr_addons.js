/**
    *@NApiVersion 2.1
    *@NScriptType MapReduceScript
*/
/**
    * Script Name          : CSS MR CREATE SPECIAL ORDER
    * Author               : Naim 
    * Start Date           : March 2022
    * Last Modified Date   : 
    * Description          : This script is responsible to create a special order.
*/
/**
    * 4-April-2023    CD/61276    Akash Sharma    Added BOM & BOMR Creation Code after SKU Creation.   
 */

/**
    * The script uses NetSuite's Map/Reduce pardigm implementation and uses getInputData, map, and summarize stages. When completed,
    * the script deletes existing Pricing data for for qualifying items using the following generalized algorithm:
    * Read the items and price data in getinputdata
    * In map stage, delete the price data that was passed from getInputData stage
    * In summery stage, write the debug log regarding uses and descriptive messages
*/
define(['N/search', 'N/record', 'N/runtime', './Matrix Items.lib.js'],
    /**
        * @param search @param record
    */

    function (search, record, runtime, mat) {


        function getInputData() {

            var schobj = runtime.getCurrentScript();
            var soId = schobj.getParameter({ name: 'custscript_c_sp_so_id' });
            log.debug('soId', soId);

            var customrecord_c60520_order_addonsSearchObj = search.create({
                type: "customrecord_c60520_order_addons",
                filters:
                    [
                        ["custrecord9", "anyof", soId],
                        "AND",
                        ["custrecord11", "is", "T"]
                    ],
                columns:
                    [
                        search.createColumn({ name: "custrecord14", label: "Item" }),
                        search.createColumn({ name: "custrecord15", label: "SO Line Number" }),
                        search.createColumn({ name: "custrecord10", label: "Add On" }),
                        search.createColumn({ name: "custrecord11", label: "Included?" }),
                        search.createColumn({ name: "custrecord16", label: "Show Separately on Paperwork?" }),
                        search.createColumn({ name: "custrecord12", label: "Default Sales Price" }),
                        search.createColumn({ name: "custrecord13", label: "Sales Price" })
                    ]
            });


            return customrecord_c60520_order_addonsSearchObj;

        }


        function map(context) {
            try {

                var mapData = JSON.parse(context.value);
                log.debug("mapData", mapData);

                var lineNumber = mapData.values['custrecord15'];
                var soItem = mapData.values['custrecord14'].value;
                var addOnItem = mapData.values['custrecord10'].value;
                var salesPrice = mapData.values['custrecord13'];
                var addOnItemName = mapData.values['custrecord10'].text;

                context.write({
                    key: lineNumber,
                    value: {
                        'soItem': soItem,
                        'addOnItem': addOnItem,
                        'salesPrice': salesPrice,
                        'addOnItemName': addOnItemName
                    }
                });

            }
            catch (reqError) {
                log.error('log Error', reqError);
            }
        }

        function generateNextWord(inputWord) {
            var outputWord = '';
            var carry = true;

            for (var i = inputWord.length - 1; i >= 0; i--) {
                var charCode = inputWord.charCodeAt(i);

                if (carry) {
                    if (charCode === 90) { // 'Z'
                        outputWord = 'A' + outputWord;
                    } else {
                        outputWord = String.fromCharCode(charCode + 1) + outputWord;
                        carry = false;
                    }
                } else {
                    outputWord = inputWord.charAt(i) + outputWord;
                }
            }

            if (carry) {
                outputWord = 'A' + outputWord;
            }

            return outputWord;
        }




        function reduce(context) {

            try {
                var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];

                var salesLines = context.values.map(JSON.parse);
                log.debug('salesLines', salesLines);
                log.debug('salesLines length', salesLines.length);
                var lineId = context.key;
                log.debug('lineId', lineId);


                var modifcationName = '';
                var modification = '';
                var matrixSubItemRecordId = '';
                var salesLines = salesLines.map(function (obj) {
                    if (obj['addOnItemName']) {
                        modifcationName += obj['addOnItemName'] + '/ '
                    }

                    if (obj['soItem']) {
                        matrixSubItemRecordId = obj['soItem'];
                    }
                });

                if (modifcationName) {
                    modifcationName = modifcationName.substring(0, modifcationName.length - 2);
                    log.debug('modifcationName', modifcationName);

                    var customlist1452SearchObj = search.create({
                        type: "customlist1452",
                        filters:
                            [
                                ["name", "is", modifcationName]
                            ],
                        columns:
                            [
                                search.createColumn({ name: "internalid", label: "Internal ID" }),
                                search.createColumn({ name: "name", sort: search.Sort.ASC, label: "Name" })
                            ]
                    });
                    var searchResultCount = customlist1452SearchObj.runPaged().count;
                    log.debug("customlist1452SearchObj result count", searchResultCount);

                    if (searchResultCount > 0) {
                        var searchResult = customlist1452SearchObj.run().getRange({ start: 0, end: 1 });
                        modification = searchResult[0].getValue({ name: "internalid", label: "Internal ID" });
                    }
                    else {
                        var createRecord = record.create({ type: 'customlist1452' });
                        createRecord.setValue({ fieldId: 'name', value: modifcationName });
                        modification = createRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                    }

                }

                log.debug('modification', modification);
                log.debug('matrixSubItemRecordId', matrixSubItemRecordId);

                var matrixSubItemRecord = record.load({
                    type: 'serializedassemblyitem',
                    id: matrixSubItemRecordId,
                    isDynamic: true
                });

                var itemId = matrixSubItemRecord.getValue({ fieldId: 'parent' });
                var setModelBGK = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_model_bgk' });

                var data = fieldsArray();
                for (var i = 0; i < data.length; i++) {
                    data[i].values = matrixSubItemRecord.getValue({ fieldId: data[i].actualFieldId });
                }
                var itemVariantBGKCombinationSearch = itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, setModelBGK, modification, data);
                log.debug('itemVariantBGKCombinationSearch', itemVariantBGKCombinationSearch);
                var newVersion;

                if (itemVariantBGKCombinationSearch.length > 0) {
                    var replaceItem = itemVariantBGKCombinationSearch[0].getValue({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" });
                    log.debug("replaceItem", replaceItem);

                    var schobj = runtime.getCurrentScript();
                    var soLocation = schobj.getParameter({ name: 'custscript_so_location' });

                    var itemInventorySearch = search.create({
                        type: "assemblyitem",
                        filters:
                            [
                                ["type", "anyof", "Assembly"], "AND",
                                ["internalid", "anyof", Number(replaceItem)], "AND",
                                ["inventorynumber.location", "anyof", Number(soLocation)], "AND",
                                ["inventorynumber.quantityavailable", "greaterthan", "0"]
                            ],
                        columns:
                            [
                                search.createColumn({ name: "quantityavailable", join: "inventoryNumber", label: "Available" }),
                                search.createColumn({ name: "internalid", join: "inventoryNumber", label: "INVENTORY ID" })
                            ]
                    });
                    var locationSearchResultCount = itemInventorySearch.runPaged().count;
                    log.debug("itemInventorySearch result count", locationSearchResultCount);
                    var woCreationFlag = true;

                    if (Number(locationSearchResultCount) > 0) {
                        woCreationFlag = false;
                    }
                    context.write({
                        key: lineId,
                        value: { 'replaceItem': replaceItem, 'woCreation': woCreationFlag }
                    });
                }
                else {
                    var itemVariantSearch = itemVariantCheck(matrixSubItemRecordId, itemId, setModelBGK, data);
                    log.debug('itemVariantSearch Lengh: ' + itemVariantSearch.length, "itemVariantSearch: " + itemVariantSearch);

                    if (itemVariantSearch.length > 1) {
                        var maxAlphabet = itemVariantSearch[0].getValue({ name: "custitem_c60520_var_modified_character", label: "Variant Modified Character" });
                        log.debug('maxAlphabet', maxAlphabet);
                        newVersion = generateNextWord(String(maxAlphabet));
                    }
                    else if (itemVariantSearch.length == 1) {
                        newVersion = 'A';
                    }

                    log.debug('newVersion', newVersion);
                    var variantBGK = matrixSubItemRecord.getText({ fieldId: 'custitem_c60520_matrix_variant_bgk' });
                    var unmodifiedvariantBGK = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk' });
                    var newVariant = variantBGK + newVersion;
                    log.debug('newVariant', newVariant);

                    var variantBGKRecord = record.create({ type: 'customrecord_c60520_variant_bgk' });
                    variantBGKRecord.setValue({ fieldId: 'name', value: newVariant });
                    var variantBGKId = variantBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                    log.debug('variantBGKId', variantBGKId);

                    var extMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                    var extSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                    var intMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_main_color" });
                    var intSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                    var extMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                    var extSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                    var intMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_main_color" });
                    var intSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                    var remainingPrefixForItemNameNumber = callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue);
                    log.debug('remainingPrefixForItemNameNumber', remainingPrefixForItemNameNumber);

                    var createRecord = record.create({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM });

                    createRecord.setValue({ fieldId: 'matrixtype', value: 'CHILD' });
                    createRecord.setValue({ fieldId: 'parent', value: itemId });
                    createRecord.setValue({ fieldId: 'displayname', value: newVariant + "-" + remainingPrefixForItemNameNumber });
                    createRecord.setValue({ fieldId: 'itemid', value: newVariant + "-" + remainingPrefixForItemNameNumber });
                    createRecord.setValue({ fieldId: 'taxschedule', value: 1 });
                    createRecord.setValue({ fieldId: 'custitem_c60520_already_sequenced', value: true });
                    createRecord.setValue({ fieldId: 'custitem_c60520_unm_already_sequenced', value: true });
                    createRecord.setValue({ fieldId: 'custitem_c60520_matrix_model_bgk', value: setModelBGK });
                    createRecord.setValue({ fieldId: 'custitem_c60520_matrix_variant_bgk', value: variantBGKId });
                    createRecord.setValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk', value: unmodifiedvariantBGK });
                    createRecord.setValue({ fieldId: 'custitem_c60520_var_modified_character', value: newVersion });

                    for (var aa = 0; aa < data.length; aa++) {
                        var fieldVar = data[aa].values;
                        if (fieldVar && fieldVar != '' && data[aa].fieldId != 'matrixoptioncustitem_c60520_matrix_modifications') {
                            log.debug("field id", data[aa].fieldId);
                            createRecord.setValue({ fieldId: data[aa].fieldId, value: fieldVar.toString() });
                        }
                    }

                    log.debug("modification", modification);

                    if (modification) {
                        createRecord.setValue({ fieldId: 'matrixoptioncustitem_c60520_matrix_modifications', value: modification.toString() });
                    }

                    var replaceItem = createRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                    log.debug("replaceItem", replaceItem);

                    if (replaceItem) {
                        /**
                         * Creating BOM
                         */

                        var bomRecord = record.create({ type: record.Type.BOM, isDynamic: true });
                        bomRecord.setValue({ fieldId: 'name', value: newVariant + "-" + remainingPrefixForItemNameNumber });
                        bomRecord.setValue({ fieldId: 'assemblyitem', value: replaceItem });
                        bomRecord.setValue({ fieldId: 'includechildren', value: true });

                        var bomRecordId = bomRecord.save();

                        log.debug("BOM Record Created", bomRecordId);

                        /**
                         * Create BOM Revision
                         */
                        var bomRevision = record.create({
                            type: record.Type.BOM_REVISION,
                            isDynamic: true
                        });

                        bomRevision.setValue('name', newVariant + "-" + remainingPrefixForItemNameNumber);
                        bomRevision.setValue('billofmaterials', bomRecordId);
                        bomRevision.setValue('effectivestartdate', new Date());

                        /**
                         * Adding Component for BOM Addon 
                         */

                        var schobj = runtime.getCurrentScript();
                        var soId = schobj.getParameter({ name: 'custscript_c_sp_so_id' });

                        var customrecord_c60520_order_addonsSearchObj = search.create({
                            type: "customrecord_c60520_order_addons",
                            filters:
                                [
                                    ["custrecord9", "anyof", Number(soId)],
                                    "AND",
                                    ["custrecord15", "equalto", (lineId)],
                                    "AND",
                                    ["custrecord11", "is", "T"]
                                ],
                            columns:
                                [
                                    search.createColumn({ name: "custrecord14", label: "Item" }),
                                    search.createColumn({ name: "custrecord10", label: "Add On" }),
                                    search.createColumn({ name: "custrecord11", label: "Included?" }),
                                    search.createColumn({ name: "custrecord12", label: "Default Sales Price" }),
                                    search.createColumn({ name: "custrecord13", label: "Sales Price" }),
                                    search.createColumn({ name: "custrecord15", label: "SO Line Number" }),
                                    search.createColumn({ name: "custrecord17", label: "Quantity" })
                                ]
                        });
                        var searchResultCount = customrecord_c60520_order_addonsSearchObj.runPaged().count;

                        var searchResult = customrecord_c60520_order_addonsSearchObj.run().getRange({ start: 0, end: 1000 });
                        log.debug("searchResult : result countL " + searchResultCount, searchResult);

                        /**
                         * Seting One Main Item Hardcoded
                         */

                        var mainItem = searchResult[0].getValue({ name: "custrecord14", label: "Item" });
                        var addonQuantity = searchResult[0].getValue({ name: "custrecord17", label: "Quantity" });

                        bomRevision.selectNewLine({ sublistId: 'component' });
                        bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'item', value: Number(mainItem) });
                        bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'bomquantity', value: addonQuantity });//
                        bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'quantity', value: addonQuantity });
                        bomRevision.commitLine({ sublistId: 'component' });
                        var savedWOId;

                        for (var x = 0; x < searchResultCount; x++) {
                            var bomrItem = searchResult[x].getValue({ name: "custrecord10", label: "Add On" });
                            log.debug("bomrItem", bomrItem);
                            bomRevision.selectNewLine({ sublistId: 'component' });
                            bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'item', value: bomrItem });
                            bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'bomquantity', value: addonQuantity });
                            bomRevision.setCurrentSublistValue({ sublistId: 'component', fieldId: 'quantity', value: addonQuantity });
                            bomRevision.commitLine({ sublistId: 'component' });
                        }

                        var bomRevisionId = bomRevision.save();
                        log.debug("BOM Revision Record Created", bomRevisionId);

                        /**
                         * Now Attaching BOM to Item's Manufactruing Tab
                         */

                        var itemRecord = record.load({ type: 'serializedassemblyitem', id: replaceItem });
                        var itemLineCount = itemRecord.getLineCount({ sublistId: 'billofmaterials' });
                        if (itemLineCount) {
                            itemLineCount = Number(itemLineCount);
                        } else {
                            itemLineCount = 0;
                        }
                        itemRecord.setSublistValue({ sublistId: 'billofmaterials', fieldId: 'billofmaterials', line: itemLineCount, value: bomRecordId });
                        var itemRecordId = itemRecord.save();

                        log.debug("ITEM Record Saved", itemRecordId);
                    }

                    context.write({
                        key: lineId,
                        value: { 'replaceItem': replaceItem, 'woCreation': true }
                    });
                }

            }
            catch (reqError) {
                log.error('log Error', reqError);
            }
        }

        function summarize(context) {
            try {
                var schobj = runtime.getCurrentScript();
                var soId = schobj.getParameter({ name: 'custscript_c_sp_so_id' });

                var salesObj = record.load({
                    type: 'salesorder',
                    id: soId,
                    isDynamic: true
                });

                var saveRec = false;
                context.output.iterator().each(function (key, value) {
                    var salesItem = salesObj.getSublistValue({ sublistId: 'item', fieldId: 'item', line: key - 1 });
                    log.debug("salesItem", salesItem);
                    log.debug("key", key);
                    lineValues = JSON.parse(value);
                    log.debug("lineValues", lineValues);

                    if (salesItem != lineValues.replaceItem) {
                        var salesItemRate = salesObj.getSublistValue({ sublistId: 'item', fieldId: 'rate', line: key - 1 });
                        var salesItemQty = salesObj.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: key - 1 });
                        var newItem = lineValues.replaceItem;
                        var isWorkOrd = lineValues.woCreation;
                        log.debug("salesItemRate", salesItemRate);
                        log.debug("salesItemQty", salesItemQty);
                        log.debug("newItem", newItem);
                        log.debug("isWorkOrd", isWorkOrd);

                        salesObj.selectLine({ sublistId: 'item', line: key - 1 });
                        salesObj.setCurrentSublistValue({ sublistId: 'item', fieldId: 'item', value: newItem });
                        salesObj.setCurrentSublistValue({ sublistId: 'item', fieldId: 'rate', value: salesItemRate });
                        salesObj.setCurrentSublistValue({ sublistId: 'item', fieldId: 'quantity', value: salesItemQty });
                        salesObj.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_fr_is_work_order', value: isWorkOrd });
                        salesObj.commitLine({ sublistId: 'item' });

                        saveRec = true;
                    }
                    return true;
                });

                log.debug("saveRec", saveRec);
                if (saveRec) {
                    salesObj.setValue({ fieldId: 'custbody_c60520_addons_processing', value: false });
                    salesObj.save({ enableSourcing: true, ignoreMandatoryFields: true });
                } else {
                    record.submitFields({
                        type: 'salesorder',
                        id: soId,
                        values: { 'custbody_c60520_addons_processing': false }
                    });
                }
            }
            catch (reqError) {
                log.error('log Error', reqError);
            }
        }


        function itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, modelBGK, modification, data) {
            log.debug("Inside itemVariantBGKCombinationCheck Function!");

            var allFilters =
                [
                    ["type", "anyof", "Assembly"], "AND",
                    ["matrix", "is", "F"], "AND",
                    ["matrixchild", "is", "T"]
                ];

            //Pushing filters only when value for those filters is entered, else blank.

            if (modelBGK) allFilters.push('AND', ["custitem_c60520_matrix_model_bgk", "anyof", modelBGK]);
            if (itemId) allFilters.push('AND', ["parent", "anyof", itemId]);
            for (var i = 0; i < data.length; i++) {
                //Skipping colors and mdifications since it was supposed to be sent as null
                if (data[i].label == 'Modifications' || data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
                //pushing filters for the rest
                if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
            }
            allFilters.push('AND', ["custitem_c60520_matrix_modifications", "anyof", [modification]]);

            log.debug("FILTERS FROM VARIANT", allFilters);
            var allColumns =
                [
                    search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
                    search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
                    search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
                ];
            var searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
            log.debug("searchData", searchData);
            return searchData;

        }


        function itemVariantCheck(matrixSubItemRecordId, itemId, modelBGK, data) {
            log.debug("Inside itemVariantCheck Function!");

            var allFilters =
                [
                    ["type", "anyof", "Assembly"], "AND",
                    ["matrix", "is", "F"], "AND",
                    ["matrixchild", "is", "T"]
                ];

            //Pushing filters only when value for those filters is entered, else blank.

            for (var i = 0; i < data.length; i++) {
                //Skipping colors and mdifications since it was supposed to be sent as null
                if (data[i].label == 'Modifications' || data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
                //pushing filters for the rest
                if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
            }

            // log.debug("FILTERS FROM VARIANT", allFilters);
            var allColumns =
                [
                    // search.createColumn({ name: "custitem_c60520_variant_modifica_seq", sort: search.Sort.DESC, label: "Variant Modification Sequence" }),
                    search.createColumn({ name: "custitem_c60520_var_modified_character", label: "Variant Modified Character" }),
                    search.createColumn({ name: "internalid", sort: search.Sort.DESC, label: "Internal ID" }),
                    search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
                    search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
                ];
            var searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
            log.debug("searchData", searchData);
            return searchData;

        }


        function callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue) {
            log.debug("Inside callRemainingPrefixItemNameSearch Function!");
            var mainString = "";
            log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);
            log.debug("COLOR NAME DEBUG", "extMainColText: " + extMainColText + " | extSubColText: " + extSubColText + " | intMainColText: " + intMainColText + " | intSubColText: " + intSubColText);

            intMainColValue = Number(intMainColValue);
            intSubColValue = Number(intSubColValue);
            extMainColValue = Number(extMainColValue);
            extSubColValue = Number(extSubColValue);

            // log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);

            intSubColTextTemp = String(intSubColText).toLowerCase();
            intMainColTextTemp = String(intMainColText).toLowerCase();
            extMainColTextTemp = String(extMainColText).toLowerCase();
            extSubColTextTemp = String(extSubColText).toLowerCase();

            if ((extMainColTextTemp != '') && (extSubColTextTemp != '') && extMainColTextTemp != extSubColTextTemp) {
                mainString += extMainColText + "(" + extSubColText + ")";
            } else if (extMainColTextTemp != '') {
                mainString += extMainColText;
            } else if (extSubColTextTemp != '') {
                mainString += extSubColText;
            }

            if ((intMainColTextTemp != '') && (intSubColTextTemp != '') && intMainColTextTemp != intSubColTextTemp) {
                mainString += "/" + intMainColText + "(" + intSubColText + ")";
                flag = true;
            } else if (intMainColTextTemp != '') {
                mainString += "/" + intMainColText;
                flag = true;
            } else if (intSubColTextTemp != '') {
                mainString += "/" + intSubColText;
                flag = true;
            }
            return mainString;
        }


        function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
            try {
                var arrSearchResults = [];
                var count = 1000, min = 0, max = 1000;
                var searchObj = false;

                if (recordType == null) {
                    recordType = null;
                }

                if (searchId) {
                    searchObj = search.load({ id: searchId });
                    if (searchFilter) {
                        searchObj.addFilters(searchFilter);
                    }
                    if (searchColumns) {
                        searchObj.addColumns(searchColumns);
                    }
                }
                else {
                    searchObj = search.create({ type: recordType, filters: searchFilter, columns: searchColumns })
                }

                var rs = searchObj.run();
                searchColumns.push(rs.columns);
                allColumns = rs.columns;

                while (count == 1000) {
                    var resultSet = rs.getRange({ start: min, end: max });
                    if (resultSet != null) {
                        arrSearchResults = arrSearchResults.concat(resultSet);
                        min = max;
                        max += 1000;
                        count = resultSet.length;
                    }
                }
            }
            catch (e) {
                log.debug('Error searching for Assembly Item:- ', e.message);
            }
            return arrSearchResults;
        }


        return {
            getInputData: getInputData,
            map: map,
            reduce: reduce,
            summarize: summarize
        };
    });					
/*******************************************************************************
*  * Copyright (c) 2024 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE WO Approved and PO Received.js
* DEVOPS TASK: BL/77430
* AUTHOR: Anushka Banerjee
* DATE CREATED: 13-05-2024
* DESCRIPTION: UE to hide 'Create Build' button.
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
/**
 *@NApiVersion 2.1
 *@NScriptType UserEventScript
 */
define(['N/query'], function (query) {

    function beforeLoad(context) {
        try {
            let newRecord = context.newRecord;
            let type = context.type;
            if (type == 'view') {
                let approvalStatus = newRecord.getValue({ fieldId: 'custbody_c60520_wo_app_status' });
                let flag = true;
                let form = context.form;
                let lineCount = newRecord.getLineCount({ sublistId: 'item' });
                let poArray = [];
                for (let iter = 0; iter < lineCount; iter++) {
                    let itemType = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'itemtype', line: iter });
                    if (itemType == 'InvtPart') {
                        let linePO = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_wo_related_po', line: iter });
                        if (!linePO || linePO.length == 0) {
                            flag = false;
                            break;
                        }
                        else {
                            poArray.push(linePO);
                        }
                    }
                }
                if (flag) {
                    let queryStr = `select status, BUILTIN.DF(status) from transaction where id in (${poArray.toString()})`;
                    let result = query.runSuiteQL({ query: queryStr }).asMappedResults();
                    log.debug("result", result);
                    for (let iter = 0; iter < result.length; iter++) {
                        if (result[iter].status != 'F') {
                            flag = false;
                            break;
                        }
                    }
                }
                if (approvalStatus != 2 || flag == false) {
                    form.removeButton({ id: 'createbuild' });
                }
            }

        } catch (error) {
            log.error("Error in beforeLoad", error);
        }
    }

    function beforeSubmit(context) {

    }

    function afterSubmit(context) {

    }

    return {
        beforeLoad: beforeLoad,
        // beforeSubmit: beforeSubmit,
        // afterSubmit: afterSubmit
    }
});

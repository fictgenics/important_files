/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 */

define(['N/record', 'N/runtime', 'N/error'], function (record, runtime, error) {


    function beforeSubmit(context) {
        try {
            log.debug('beforeSubmit()', 'Start Script');
            var currentRec = context.newRecord;

            var userObj = runtime.getCurrentUser();
            var userDepartment = userObj.department;

            var assignedByDepartment = currentRec.getValue({
                fieldId: 'custevent_assigned_by_department'
            });

            if (assignedByDepartment) {
                currentRec.setValue({
                    fieldId: 'custevent_assigned_by_department',
                    value: userDepartment
                });

            }


            log.debug('beforeSubmit()', 'End Script');
            return true;
        } catch (e) {
            log.error('beforeSubmit() :: Error', 'errorMessage=' + e.message);
            return false;
        }
    }

    return {
        beforeSubmit: beforeSubmit
    };
});
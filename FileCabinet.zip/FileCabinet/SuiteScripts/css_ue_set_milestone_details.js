/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/record', 'N/search'], function (record, search) {


	function afterSubmit(context) {
		try {

			var recordOrder = context.newRecord;
			var recId = recordOrder.id;

			var estimateRec = record.load({
				type: 'purchaseorder',
				id: recId
			});

			var approvalStatus = estimateRec.getValue({
				fieldId: 'approvalstatus'
			});

			log.debug('approvalStatus', approvalStatus);
			if (approvalStatus == 1) {
				var tranId = estimateRec.getValue({
					fieldId: 'tranid'
				});
				var totalAmt = estimateRec.getValue({
					fieldId: 'total'
				});

				var custId = estimateRec.getValue({
					fieldId: 'entity'
				});

				var textName = 'Purchase_Order#' + tranId + '_';


				var count = estimateRec.getLineCount({
					sublistId: 'recmachcustrecord_c59306_purchase_order'
				});
				log.debug('DEBUG', 'count: ' + count + '===' + 'totalAmt: ' + totalAmt);
				if (count > 0) {
					var totalQty = 0;
					var lineCnt = estimateRec.getLineCount({ sublistId: 'item' });

					for (var x = 0; x < lineCnt; x++) {
						var quantity = estimateRec.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: x });
						totalQty = parseFloat(totalQty) + parseFloat(quantity);
					}

					for (var aa = 0; aa < count; aa++) {

						var recName = estimateRec.getSublistValue({
							sublistId: 'recmachcustrecord_c59306_purchase_order',
							fieldId: 'name',
							line: aa
						});

						var index = recName.indexOf(tranId);
						if (index == -1) {
							var milestoneType = estimateRec.getSublistText({
								sublistId: 'recmachcustrecord_c59306_purchase_order',
								fieldId: 'custrecord_c59306_purchase_miles_type',
								line: aa
							});

							var name = textName + milestoneType;
							estimateRec.setSublistValue({
								sublistId: 'recmachcustrecord_c59306_purchase_order',
								fieldId: 'name',
								value: name,
								line: aa
							});

							estimateRec.setSublistValue({
								sublistId: 'recmachcustrecord_c59306_purchase_order',
								fieldId: 'custrecord_c59306_vendor',
								value: custId,
								line: aa
							});

							estimateRec.setSublistValue({
								sublistId: 'recmachcustrecord_c59306_purchase_order',
								fieldId: 'custrecord_c59306_quantity',
								value: totalQty,
								line: aa
							});
						}

						var milestonePercent = estimateRec.getSublistValue({
							sublistId: 'recmachcustrecord_c59306_purchase_order',
							fieldId: 'custrecord_c59306_milestone',
							line: aa
						});

						var milestoneAmt = parseFloat((totalAmt * milestonePercent) / 100);
						estimateRec.setSublistValue({
							sublistId: 'recmachcustrecord_c59306_purchase_order',
							fieldId: 'custrecord_c59306_milestone_amount',
							value: milestoneAmt,
							line: aa
						});
						
						var appliedAmt = estimateRec.getSublistValue({
							sublistId: 'recmachcustrecord_c59306_purchase_order',
							fieldId: 'custrecord_c59306_milestone_applied_amt',
							line: aa
						});
						
						var remainAmt = milestoneAmt;
						if(appliedAmt){
							remainAmt = milestoneAmt - appliedAmt; 
						}

						estimateRec.setSublistValue({
							sublistId: 'recmachcustrecord_c59306_purchase_order',
							fieldId: 'custrecord_c59306_milestone_remain_amt',
							value: remainAmt,
							line: aa
						});

					}

					var recordId = estimateRec.save({
						ignoreMandatoryFields: true
					});
					log.debug('DEBUG', 'recordId: ' + recordId);
				}
			}

		} catch (e) {
			log.error('ERROR', 'Exception: ' + e.toString());
		}
	}

	return {
		afterSubmit: afterSubmit
	};
});
/**
* @NApiVersion 2.1
* @NScriptType MapReduceScript
*/
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Calculating Accrued Leave MR Trigger
* DEVOPS TASK: DT/46387
* AUTHOR: Akash Sharma
* DATE MODIFIED: 4 Mar, 2022
* DESCRIPTION: This Script is for calculating & recalculating leaves of
* each employee weekly, monthly & yearly.                            
*****************************************************************************/
define(['N/query', 'N/record', 'N/format', 'N/runtime', './Matrix Items.lib.js'],
  /**
  * @param{query} query
  * @param{record} record
  * @param{format} format
  * @param{runtime} runtime
  */
  (query, record, format, runtime, mat) => {
    /**
    * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
    * @param {Object} inputContext
    * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
    *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
    * @param {Object} inputContext.ObjectRef - Object that references the input data
    * @typedef {Object} ObjectRef
    * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
    * @property {string} ObjectRef.type - Type of the record instance that contains the input data
    * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
    * @since 2015.2
    */

    const getInputData = (inputContext) => {
      try {

        let itemId = runtime.getCurrentScript().getParameter({ name: 'custscript_qdd_item' });
        log.debug("itemId --->", itemId);

        let tempAr = [];
        tempAr.push(itemId);
        return tempAr;

      } catch (err) {
        log.error("Error Inside Get Input Data -->", [err.message, err.stack]);
      }

    }

    /**
    * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
    * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
    * context.
    * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
    *     is provided automatically based on the results of the getInputData stage.
    * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
    *     function on the current key-value pair
    * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
    *     pair
    * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
    *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
    * @param {string} mapContext.key - Key to be processed during the map stage
    * @param {string} mapContext.value - Value to be processed during the map stage
    * @since 2015.2
    */

    const map = (mapContext) => {
      try {

        log.debug("mapContext", mapContext);
        let itemId = JSON.parse(mapContext.value);
        log.debug("itemId", itemId);

        /**
       * Query for fetching ID's of Custom Field
       */

        let idFetch = runSuiteQuery("SELECT id, name, scriptid FROM customfield");
        /**
         * Fetching Selected Values
         */

        let mainArr = [];

        var data = fieldsArray();
        let itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

        let parentItem = itemRecord.getValue({ fieldId: 'parent' });
        var iter = 1;
        data.forEach(field => {
          var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
          // let insideObj = {'data':fieldVar, };
          if (fieldVar && fieldVar != '') {
            /**
             * Add this ID to main array & we'll create them in map
             */

            for (let i = 0; i < idFetch.length; i++) {
              let fieldIdText = (String(idFetch[i]['scriptid'])).toLowerCase();

              if (fieldIdText == (String(field.actualFieldId)).toLowerCase()) {
                mainArr.push({ 'curFieldId': field.actualFieldId, 'intid': idFetch[i]['id'], 'name': idFetch[i]['name'], 'itemId': itemId, 'sequence': iter });
                iter++;
                log.debug('DATA', 'curFieldId: ' + field.actualFieldId + ' || intid: ' + idFetch[i]['id'] + ' || name: ' + idFetch[i]['name'] + ' || itemId: ' + itemId + ' || sequence: ' + iter);
              }
            }
          }
        });
        log.debug("mainArr", mainArr);

        let qualityDataRecId = runtime.getCurrentScript().getParameter({ name: 'custscript_recordid' });

        let parentItemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: parentItem });

        /**
         * Create Quality Inspection
         */

        let qualityInspectionRecord = record.create({ type: 'customrecord_qm_quality_inspection' });
        qualityInspectionRecord.setValue({ fieldId: 'name', value: 'Attribute Check' + itemId });
        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_description', value: "Major Attribute Check at time of receiving to ensure we don't need to convert it to another car variant." });
        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_type', value: 1 });
        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_method', value: 1 });
        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_trans_freq', value: 0 });
        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_sampling_rqmt', value: 1 });
        let savedqualityInspectionRecord = qualityInspectionRecord.save();

        log.debug("savedqualityInspectionRecord", savedqualityInspectionRecord);

        if (savedqualityInspectionRecord) {
          log.debug("Inside For Loop", mainArr.length);
          let parentItemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: parentItem });

          for (let x = 0; x < mainArr.length; x++) {

            let curFieldId = mainArr[x].curFieldId;
            let intid = mainArr[x].intid;
            let itemId = mainArr[x].itemId;
            let sequence = mainArr[x].sequence;
            let optionName = mainArr[x].name;

            let actualParentValues = parentItemRecord.getValue({ fieldId: curFieldId });
            let splittedValue;
            if (actualParentValues && actualParentValues != '') {
              splittedValue = String(actualParentValues).split(",").join(";");
            }

            /**
             * Adding Line Level of Quality Inspection/ Inspection Data Field
             */

            let inspectionDataField = record.create({ type: 'customrecord_qm_inspection_properties' });
            inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_seq', value: sequence });
            inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_type', value: 10 });
            inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_insp', value: savedqualityInspectionRecord });



            let qualityInspectionField = record.create({ type: 'customrecord_qm_inspection_fields' });
            qualityInspectionField.setValue({ fieldId: 'name', value: optionName });
            qualityInspectionField.setValue({ fieldId: 'custrecord_qm_field_data_type', value: 10 });
            qualityInspectionField.setValue({ fieldId: 'custrecord_qm_options', value: splittedValue });
            qualityInspectionField.setValue({ fieldId: 'custrecord_qm_quality_insp_mandatory', value: true });
            let savedQualityInspectionField = qualityInspectionField.save();
            log.debug("savedQualityInspectionField", savedQualityInspectionField);

            let savedInspectionDataField;
            if (savedQualityInspectionField) {
              inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_field', value: savedQualityInspectionField });
              savedInspectionDataField = inspectionDataField.save();
              log.debug("savedInspectionDataField", savedInspectionDataField);

            }

            let qddRec = record.create({ type: 'customrecord_qm_quality_detail' });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_parent', value: Number(qualityDataRecId) });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_item', value: Number(itemId) });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_data_type', value: 10 });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_sequence', value: sequence });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_status', value: 4 });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_data_dtl_mandatory', value: true });
            qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_inspection', value: savedqualityInspectionRecord });
            qddRec.setValue({ fieldId: 'custrecord_qm_qdd_datatype_values', value: splittedValue });

            if (savedQualityInspectionField) qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_field', value: savedQualityInspectionField });
            let savedqddRec = qddRec.save();
            log.debug("savedqddRec", savedqddRec);

          }
        }
      } catch (err) {
        log.error("Error Inside Map -->", [err.message, err.stack]);
      }


    }



    /**
    * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
    * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
    * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
    *     provided automatically based on the results of the map stage.
    * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
    *     reduce function on the current group
    * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
    * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
    *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
    * @param {string} reduceContext.key - Key to be processed during the reduce stage
    * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
    *     for processing
    * @since 2015.2
    */
    const reduce = (reduceContext) => {

    }


    /**
    * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
    * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
    * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
    * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
    *     script
    * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
    * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
    *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
    * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
    * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
    * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
    *     script
    * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
    * @param {Object} summaryContext.inputSummary - Statistics about the input stage
    * @param {Object} summaryContext.mapSummary - Statistics about the map stage
    * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
    * @since 2015.2
    */
    const summarize = (summaryContext) => {
      log.debug("Summarize Complete!");
    }


    function runSuiteQuery(queryString) {
      log.debug("Query", queryString);
      let resultSet = query.runSuiteQL({
        query: queryString
      });
      //log.debug("Query wise Data", resultSet.asMappedResults());
      if (resultSet && resultSet.results && resultSet.results.length > 0) {
        return resultSet.asMappedResults();
      } else {
        return [];
      }
    }

    return { getInputData, map, reduce, summarize }

  });

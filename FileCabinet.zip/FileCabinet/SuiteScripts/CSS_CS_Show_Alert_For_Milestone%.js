/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: CSS_CS_Show_Alert_For_Milestone%.js
* DEVOPS TASK: ENH 58005,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 9/Feb/2022
* DESCRIPTION: T'Approved'.
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/currentRecord', 'N/search'],

    function (currentRecord, search) {

        function pageInit(context) {
            if (context.mode == 'copy') {
                var currentRec = context.currentRecord;
                currentRec.setValue({ fieldId: 'custbody_c58005_max_count', value: 0, ignoreFieldChange: true });
            }
        }

        function saveRecord(context) {

            try {
                var currentRecord = context.currentRecord;
                var count = currentRecord.getLineCount('recmachcustrecord_c58005_quotation');
                log.debug('count', count);
                if (count > 0) {
                    var perecent = 0.0;
                    for (var aa = 0; aa < count; aa++) {

                        var milestonePer = currentRecord.getSublistValue({
                            sublistId: 'recmachcustrecord_c58005_quotation',
                            fieldId: 'custrecord_c58005_milestone',
                            line: aa
                        });
                        log.debug('milestonePer', milestonePer);
                        perecent += milestonePer;
                    }
                    if (perecent != 100.0 || perecent != '100.0') {
                        alert('Total Milestone% should be 100.');
                        return false;
                    }
                }
                return true;
            }
            catch (ex) {
                log.error('Error', 'Message: ' + ex.toString());
            }
        }


        function fieldChanged(context) {
            var sublistFieldName = context.fieldId;
            if (sublistFieldName == 'terms') {
                var currentRecord = context.currentRecord;
                var terms = currentRecord.getValue({ fieldId: 'terms' });
                if (terms) {
                    var addLines = true;
                    var lineCnt = currentRecord.getLineCount('recmachcustrecord_c58005_quotation');
                    if (lineCnt > 0) {
                        var lineTerms = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord_c58005_quotation', fieldId: 'custrecord_c58005_milestone_terms', line: 0 });
                        if (lineTerms == terms) {
                            addLines = false;
                        }
                    }

                    if (addLines) {
                        if (lineCnt > 0) {
                            for (var x = 0; x < lineCnt; x++) {
                                currentRecord.removeLine({ sublistId: 'recmachcustrecord_c58005_quotation', line: 0, ignoreRecalc: true });
                            }
                        }
                        var customrecord_c57685_milestone_pay_tepSearchObj = search.create({
                            type: "customrecord_c57685_milestone_pay_tep",
                            filters:
                                [
                                    ["custrecord_c57685_payment_term", "anyof", terms]
                                ],
                            columns:
                                [
                                    search.createColumn({ name: "custrecord_c57685_payment_term", label: "custrecord_c57685_payment_term" }),
                                    search.createColumn({ name: "custrecord_c57685_milestone_type", label: "Milestone Type" }),
                                    search.createColumn({ name: "custrecord_c57685_milestone_percentage", label: "Milestone Percentage" })
                                ]
                        });
                        var searchResultCount = customrecord_c57685_milestone_pay_tepSearchObj.runPaged().count;

                        customrecord_c57685_milestone_pay_tepSearchObj.run().each(function (result) {
                            var milestoneTerms = result.getValue({ name: "custrecord_c57685_payment_term", label: "custrecord_c57685_payment_term" });
                            var milestoneType = result.getValue({ name: "custrecord_c57685_milestone_type", label: "Milestone Type" });
                            var milestonePercent = result.getValue({ name: "custrecord_c57685_milestone_percentage", label: "Milestone Percentage" });

                            var newLine = currentRecord.selectNewLine({ sublistId: 'recmachcustrecord_c58005_quotation' });
                            newLine.setCurrentSublistValue({ sublistId: 'recmachcustrecord_c58005_quotation', fieldId: 'custrecord_c58005_milestone_terms', value: milestoneTerms, ignoreFieldChange: true, forceSyncSourcing: true });
                            newLine.setCurrentSublistValue({ sublistId: 'recmachcustrecord_c58005_quotation', fieldId: 'custrecord_c58005_milestone_type', value: milestoneType, ignoreFieldChange: true, forceSyncSourcing: true });
                            newLine.setCurrentSublistValue({ sublistId: 'recmachcustrecord_c58005_quotation', fieldId: 'custrecord_c58005_milestone', value: parseFloat(milestonePercent), ignoreFieldChange: true, forceSyncSourcing: true });
                            newLine.commitLine({ sublistId: 'recmachcustrecord_c58005_quotation', ignoreRecalc: true });

                            return true;
                        });
                    }
                }
            }
        }

        return {
            pageInit: pageInit,
            fieldChanged: fieldChanged,
            saveRecord: saveRecord
        }
    }
);
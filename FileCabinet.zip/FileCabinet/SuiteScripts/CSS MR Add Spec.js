/*******************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS MR Add Spec.js
* DEVOPS TASK: 
* AUTHOR: Anushka Banerjee
* DATE CREATED: 28-Nov-2023
* DESCRIPTION: MAp reduce to add spec to child items
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
/**
 *@NApiVersion 2.1
 *@NScriptType MapReduceScript
 */
define(['N/runtime', 'N/query', 'N/record'], function (runtime, query, record) {

    function getInputData() {
        try {
            var runTimeContext = runtime.getCurrentScript();
            // Parent Item
            var parentId = runTimeContext.getParameter({ name: 'custscript_parent_item_id' });
            // New Specifications to add
            var specsToAdd = runTimeContext.getParameter({ name: 'custscript_new_specs' });
            specsToAdd = specsToAdd.split(',');
            // Get child items
            var queryStr = `select id from item where parent = ${parentId.toString()}`;
            var result = query.runSuiteQL({ query: queryStr }).asMappedResults();
            log.debug("result", result);
            var array = new Array(); 
            if (result.length > 0) {
                for (var i = 0; i < result.length; i++) {
                    array.push({ "id": result[i].id, "specsToAdd": specsToAdd });
                }
            }

            return array;
        }
        catch (err) {
            log.error("Error in getInputData", err);
        }
    }

    function map(context) {
        try {
            var itemData = JSON.parse(context.value);
            log.debug("itemData.specsToAdd", itemData.specsToAdd);
            var itemRecord = record.load({type: record.Type.ASSEMBLY_ITEM,id: itemData.id});
            for (var i = 0; i < itemData.specsToAdd.length - 1; i++) {
                var field = 'matrixoption' + itemData.specsToAdd[i];
                itemRecord.setText({ fieldId: field, text: '-Undefined-' });
            }
            itemRecord.save();
        } catch (err) {
            log.error("Error in map:", err);
        }
    }

    return {
        getInputData: getInputData,
        map: map
    }
});

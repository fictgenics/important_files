/**
* @NApiVersion 2.x
* @NScriptType ClientScript
* @NModuleScope SameAccount
*/

/*******************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Validate Maximum Prepayment.js
* DEVOPS TASK: BL/59545
* AUTHOR: Akash Sharma
* DATE CREATED: 9-March-2023
* DESCRIPTION: FOR stopping user to save Vendor Prepayment & Purchase order if 
* Maximum Prepayment field has amount >100 
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/

define(['N/search', 'N/record'], function (search, record) {

  /**
  * Function to be executed after page is initialized.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
  *
  * @since 2015.2
  */
  function pageInit(scriptContext) {
    log.debug("Inside page init function");
  }


  /**
  * Onclick save
  */
  function saveRecord(scriptContext) {
    var currentRecord = scriptContext.currentRecord;
    var paymentAmount;

    var vendorId = Number(currentRecord.getValue({ fieldId: 'entity' }));
    if (vendorId) {
      log.debug("currentRecord.type", currentRecord.type);
      if (currentRecord.type == 'purchaseorder') {
        paymentAmount = currentRecord.getValue({ fieldId: 'total' });
      } else if (currentRecord.type == 'vendorprepayment') {
        paymentAmount = currentRecord.getValue({ fieldId: 'payment' });
      }

      // log.debug("paymentAmount", paymentAmount);
      // var fieldLookup = search.lookupFields({
      //   type: search.Type.VENDOR,
      //   id: vendorId,
      //   columns: ['custentity_c59306_maximum_prepayment']
      // });

      // var maximumPrepayment = fieldLookup.custentity_c59306_maximum_prepayment;
      // log.debug("maximumPrepayment", maximumPrepayment);

      // if (maximumPrepayment && (Number(maximumPrepayment) < Number(paymentAmount))) {
      //   alert("Payment Amount exceeded Maximum Prepayment Amount!");
      //   return false;
      // }
    }

    var mileStoneId = Number(currentRecord.getValue({ fieldId: 'custbody_c59306__purchase_milestone' }));
    if (mileStoneId) {
      record.submitFields({
        type: 'customrecord_c59306_purchase_milestone',
        id: mileStoneId,
        values: { 'custrecord_c59306_milestone_applied_amt': paymentAmount },
      });
    }
    return true;
  }

  return {
    pageInit: pageInit,
    saveRecord: saveRecord
  };

});

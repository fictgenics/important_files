/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript
 */
define(['N/record','N/runtime','N/search'],
function(record,runtime,search) {

    function beforeSubmit(context)
    {
        
    }
 return {
    beforeSubmit: beforeSubmit
    };

});
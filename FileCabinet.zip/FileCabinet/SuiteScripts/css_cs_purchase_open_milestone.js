/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: css_cs_open_payment.js
* DEVOPS TASK: ENH 58209,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 9/Feb/2022
* DESCRIPTION: T'Approved'.
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/currentRecord', 'N/search'],

    function (currentRecord, search) {

        function fieldChanged(context) {
            var sublistName = context.sublistId;
            var sublistFieldName = context.fieldId;
            if (sublistName == 'custpage_open_milestone_list' && sublistFieldName == 'custpage_mark_payment') {
                var currentRecord = context.currentRecord;
                var markPayment = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_mark_payment' });
                if (markPayment) {
                    var milestoneAmt = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_amount' });
                    var currentApplied = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_current_applied' });
                    var appliedToAmt = milestoneAmt - currentApplied;

                    currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: appliedToAmt, ignoreFieldChange: false });
                }
                else {
                    currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: '', ignoreFieldChange: false });
                }
            }

            if (sublistName == 'custpage_open_milestone_list' && sublistFieldName == 'custpage_applied_now') {
                var currentRecord = context.currentRecord;
                var appliedTo = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now' });
                if (appliedTo) {
                    var milestoneAmt = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_milestone_amount' });
                    var currentApplied = currentRecord.getCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_current_applied' });
                    var appliedToAmt = milestoneAmt - currentApplied;

                    if (parseFloat(appliedTo) > parseFloat(appliedToAmt)) {
                        currentRecord.setCurrentSublistValue({ sublistId: 'custpage_open_milestone_list', fieldId: 'custpage_applied_now', value: '', ignoreFieldChange: false });
                        alert('You enter extra applied amount.');
                    }
                }
            }
        }


        function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
            try {
                var arrSearchResults = [];
                var count = 1000,
                    min = 0,
                    max = 1000;
                var searchObj = false;
                if (recordType == null) {
                    recordType = null;
                }
                if (searchId) {
                    searchObj = search.load({
                        id: searchId
                    });
                    if (searchFilter) {
                        searchObj.filterExpression = searchFilter;
                    }
                } else {
                    searchObj = search.create({
                        type: recordType,
                        filters: searchFilter,
                        columns: searchColumns
                    })
                }

                var rs = searchObj.run();
                //searchColumns.push(rs.columns);
                //allColumns = rs.columns;

                while (count == 1000) {
                    var resultSet = rs.getRange({
                        start: min,
                        end: max
                    });
                    if (resultSet != null) {
                        arrSearchResults = arrSearchResults.concat(resultSet);
                        min = max;
                        max += 1000;
                        count = resultSet.length;
                    }
                }
            } catch (e) {
                //log.debug('Error searching for Customer:- ', e.message);
            }
            return arrSearchResults;
        }

        return {
            fieldChanged: fieldChanged
        }
    }
);
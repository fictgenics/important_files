/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
/*******************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Add Addon.js
* DEVOPS TASK: BL/68139
* AUTHOR: Akash Sharma
* DATE CREATED: 20-Dec-2023
* DESCRIPTION: This is a suitelet for Split PO & Bills to multiple projects.
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
define(['N/ui/serverWidget', 'N/runtime', 'N/record', 'N/log', 'N/https', 'N/http', 'N/url', 'N/search', 'N/query', 'N/redirect', 'N/format', './lodash.min'],

    function (serverWidget, runtime, record, log, https, http, url, search, query, redirect, format, lodash) {
        /**
         * Definition of the Suitelet script trigger point.
         *
         * @param {Object} context
         * @param {Record} context.currentRecord - Current form record
         * @param {ServerRequest} context.request - Encapsulation of the incoming request
         * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
         * @Since 2015.2
         */

        function onRequest(context) {
            if (context.request.method === 'GET') {
                try {
                    log.debug("********Suitelet GET Started********");
                    var parameters = context.request.parameters;
                    log.debug("parameters", parameters);
                    var form = serverWidget.createForm({ title: 'Add Addons' });

                    /**
                     * Adding Header Field Values from Parameter
                     */

                    var quotationId = parameters.qid || "";
                    // quotationId = 313902;
                    var quotationField = form.addField({ id: 'custpage_quotation', type: serverWidget.FieldType.SELECT, label: 'Quotation', source: 'transaction' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    quotationField.defaultValue = quotationId;

                    var itemId = parameters.itemid || "";
                    // itemId = 4643
                    if (!itemId) {
                        var failureForm = serverWidget.createForm({ title: 'Failure!' });
                        var successtext = 'Item not found!';
                        var msg = failureForm.addField({ id: 'custpage_html', type: 'inlinehtml', label: 'Process' });
                        msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
                        context.response.writePage({ pageObject: failureForm });
                    }

                    var itemField = form.addField({ id: 'custpage_item', type: serverWidget.FieldType.SELECT, label: 'Item', source: 'item' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    itemField.defaultValue = itemId;

                    var lineNum = parameters.linenum || "";
                    // lineNum = 1;
                    if (!lineNum) {
                        var failureForm = serverWidget.createForm({ title: 'Failure!' });
                        var successtext = 'Line Num Not Found!';
                        var msg = failureForm.addField({ id: 'custpage_html', type: 'inlinehtml', label: 'Process' });
                        msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
                        context.response.writePage({ pageObject: failureForm });
                    }
                    var addonLineField = form.addField({ id: 'custpage_addon_line', type: serverWidget.FieldType.TEXT, label: 'Addon Line' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    addonLineField.defaultValue = lineNum;

                    var lineQty = parameters.lqty || "";
                    var lineQtyField = form.addField({ id: 'custpage_line_qty', type: serverWidget.FieldType.TEXT, label: 'Line Quantity' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    lineQtyField.defaultValue = lineQty;

                    var subitemOf = parameters.sio || "";
                    var itemVariant = parameters.iv || "";
                    var itemModel = parameters.im || "";
                    // subitemOf = 2527;
                    // itemVariant = 1639;
                    // itemModel = 45;

                    /**
                     * Add a logic to get all addons already added
                     */

                    var alreadyInsertedAddon = [];

                    var customrecord_c60520_order_addonsSearchObj = search.create({
                        type: "customrecord_c60520_order_addons",
                        filters: [["custrecord15", "equalto", lineNum], "AND", ["custrecord9.internalid", "anyof", quotationId], "AND", ["custrecord11", "is", "T"]],
                        columns: [search.createColumn({ name: "internalid", join: "CUSTRECORD10", summary: "GROUP", sort: search.Sort.ASC, label: "Internal ID" })]
                    });
                    var searchResultCount = customrecord_c60520_order_addonsSearchObj.runPaged().count;
                    log.debug("customrecord_c60520_order_addonsSearchObj result count", searchResultCount);
                    customrecord_c60520_order_addonsSearchObj.run().each(function (result) {
                        alreadyInsertedAddon.push(Number(result.getValue({ name: "internalid", join: "CUSTRECORD10", summary: "GROUP", sort: search.Sort.ASC, label: "Internal ID" })))
                        return true;
                    });

                    log.debug("alreadyInsertedAddon", alreadyInsertedAddon);

                    var addOnArray = [];

                    if (subitemOf) {
                        var customrecord_c60520_makes_bgk_recSearchObj = search.create({
                            type: "customrecord_c60520_makes_bgk_rec",
                            filters: [["custrecord4", "anyof", subitemOf]],
                            columns:
                                [
                                    search.createColumn({ name: "custrecord_c60520_make_add_on", label: "Add-On" }),
                                    search.createColumn({ name: "custrecord4", label: "Make (BGK)" }),
                                    search.createColumn({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" })
                                ]
                        });

                        customrecord_c60520_makes_bgk_recSearchObj.run().each(function (result) {
                            var json = {};
                            json['addOnName'] = result.getText({ name: "custrecord_c60520_make_add_on", label: "Add-On" });
                            json['addOnId'] = result.getValue({ name: "custrecord_c60520_make_add_on", label: "Add-On" });
                            json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" });
                            var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
                            if (index == -1 && alreadyInsertedAddon.indexOf(Number(result.getValue({ name: "custrecord_c60520_make_add_on", label: "Add-On" }))) == -1) {
                                addOnArray.push(json);
                            }
                            return true;
                        });
                    }

                    if (itemVariant) {
                        var customrecord_c60520_variant_bgk_recSearchObj = search.create({
                            type: "customrecord_c60520_variant_bgk_rec",
                            filters: [["custrecord8", "anyof", itemVariant]],
                            columns:
                                [
                                    search.createColumn({ name: "custrecord8", label: "Variant (BGK)" }),
                                    search.createColumn({ name: "custrecord7", label: "Add-On" }),
                                    search.createColumn({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" })
                                ]
                        });

                        customrecord_c60520_variant_bgk_recSearchObj.run().each(function (result) {
                            var json = {};
                            json['addOnName'] = result.getText({ name: "custrecord7", label: "Add-On" });
                            json['addOnId'] = result.getValue({ name: "custrecord7", label: "Add-On" });
                            json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" });
                            var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
                            if (index == -1 && alreadyInsertedAddon.indexOf(Number(result.getValue({ name: "custrecord7", label: "Add-On" }))) == -1) {
                                addOnArray.push(json);
                            }
                            return true;
                        });
                    }


                    if (itemModel) {
                        var customrecord_c60520_model_line_bgk_recSearchObj = search.create({
                            type: "customrecord_c60520_model_line_bgk_rec",
                            filters: [["custrecord6", "anyof", itemModel]],
                            columns:
                                [
                                    search.createColumn({ name: "custrecord5", label: "Add-On" }),
                                    search.createColumn({ name: "custrecord6", label: "Model Line (BGK)" }),
                                    search.createColumn({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" })
                                ]
                        });

                        customrecord_c60520_model_line_bgk_recSearchObj.run().each(function (result) {
                            var json = {};
                            json['addOnName'] = result.getText({ name: "custrecord5", label: "Add-On" });
                            json['addOnId'] = result.getValue({ name: "custrecord5", label: "Add-On" });
                            json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" });
                            var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
                            if (index == -1 && alreadyInsertedAddon.indexOf(Number(result.getValue({ name: "custrecord5", label: "Add-On" }))) == -1) {
                                addOnArray.push(json);
                            }
                            return true;
                        });
                    }

                    // log.debug("addOnArray length: " + addOnArray.length, "addOnArray: " + JSON.stringify(addOnArray));
                    addOnArray = JSON.parse(JSON.stringify(addOnArray));
                    log.debug("addOnArray length: ", addOnArray);

                    form.addSubtab({ id: 'custpage_entry_tab1', label: 'Select Addons To Insert' });

                    var sublist1 = form.addSublist({ id: 'custpage_sublist1', type: serverWidget.SublistType.LIST, label: 'Sub Sublist', tab: 'custpage_entry_tab1' });
                    sublist1.addField({ id: 'custpage_check', type: serverWidget.FieldType.CHECKBOX, label: 'Select' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                    sublist1.addField({ id: 'custpage_addon_id', type: serverWidget.FieldType.TEXT, label: 'Addon ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    sublist1.addField({ id: 'custpage_addon_name', type: serverWidget.FieldType.TEXT, label: 'Addon Name' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });
                    sublist1.addField({ id: 'custpage_addon_price', type: serverWidget.FieldType.FLOAT, label: 'Price' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.INLINE });





                    /**
                     * Adding Data
                     */

                    var temp = addOnArray.length;
                    var iter = 0;
                    for (var x = 0; x < temp; x++) {
                        // log.debug("alreadyInsertedAddon.indexOf(Number(addOnArray[x].addOnId))", alreadyInsertedAddon.indexOf(Number(addOnArray[x].addOnId)));
                        // log.debug("data", Number(addOnArray[x].addOnId));
                        sublist1.setSublistValue({ id: 'custpage_addon_id', line: x, value: addOnArray[x].addOnId });
                        sublist1.setSublistValue({ id: 'custpage_addon_name', line: x, value: addOnArray[x].addOnName });
                        if (addOnArray[x].addOnPrice)
                            sublist1.setSublistValue({ id: 'custpage_addon_price', line: x, value: addOnArray[x].addOnPrice });
                    }

                    form.addSubmitButton({ label: 'Submit' });
                    // form.clientScriptFileId = getfileId('CSS CS Split PO.js');
                    context.response.writePage(form);

                }
                catch (err) {
                    log.error("error in if of showing addons is", err);
                }
            } else {
                try {
                    log.debug("********Suitelet POST Started********");

                    /**
                     * Getting All parameters
                     */
                    var params = context.request;
                    log.debug("Parameters", params.parameters);

                    /**
                     * Adding Addons to Quotation
                     */
                    var itemCount1 = context.request.getLineCount({ group: 'custpage_sublist1' });
                    log.debug("itemCount1", itemCount1);

                    var savedArr = [];
                    // var lineIdArr = [];
                    // Variable to store total add -on price per line
                    var addonPrice = 0;
                    if (itemCount1 >= 1) {

                        for (var x = 0; x < itemCount1; x++) {
                            var isSelected = params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_check', line: x });

                            if (isSelected == 'T' || isSelected == true || isSelected == 'True' || isSelected == 'true') {
                                var addonRecord = record.create({ type: 'customrecord_c60520_order_addons' });
                                // log.debug("Number(params.parameters.custpage_quotation) ", Number(params.parameters.custpage_quotation));
                                addonRecord.setValue({ fieldId: 'custrecord9', value: Number(params.parameters.custpage_quotation) });
                                // log.debug("Number(params.parameters.custpage_item)", Number(params.parameters.custpage_item));
                                addonRecord.setValue({ fieldId: 'custrecord14', value: Number(params.parameters.custpage_item) });
                                addonRecord.setValue({ fieldId: 'custrecord15', value: Number(params.parameters.custpage_addon_line) });
                                // log.debug("params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_id', line: x })", params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_id', line: x }));
                                addonRecord.setValue({ fieldId: 'custrecord10', value: params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_id', line: x }) });
                                addonRecord.setValue({ fieldId: 'custrecord11', value: true });
                                addonRecord.setValue({ fieldId: 'custrecord17', value: Number(params.parameters.custpage_line_qty) });
                                if (params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_price', line: x }))
                                    addonRecord.setValue({ fieldId: 'custrecord12', value: params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_price', line: x }) });
                                var savedAddonRecord = addonRecord.save();
                                log.debug("savedAddonRecord", savedAddonRecord);
                                savedArr.push(savedAddonRecord);
                                addonPrice += +params.getSublistValue({ group: 'custpage_sublist1', name: 'custpage_addon_price', line: x }) * Number(params.parameters.custpage_line_qty);
                            }
                        }

                        if (savedArr.length > 0) {
                            var successForm = serverWidget.createForm({ title: 'Success!' });
                            var successtext = 'Addons Processed Successfully!';
                            var msg = successForm.addField({ id: 'custpage_html', type: 'inlinehtml', label: 'Process' });
                            msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
                            context.response.writePage({ pageObject: successForm });
                            // Load and set addon line value on quotation
                            var recordType = params.parameters.entryformquerystring.split("&rec=")[1];
                            log.debug("recordType", recordType);
                            if (recordType == 'salesorder') {
                                var salesRecord = record.load({ type: 'salesorder', id: Number(params.parameters.custpage_quotation), isDynamic: false });
                                // quotationRecord.selectLine({ sublistId: 'item', line: Number(params.parameters.custpage_addon_line) });
                                var currAddonPrice = salesRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', line: Number(params.parameters.custpage_addon_line - 1) });
                                log.debug("addonPrice", addonPrice);
                                salesRecord.setSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', value: currAddonPrice + addonPrice, line: Number(params.parameters.custpage_addon_line - 1) });
                                var currentAmount = +salesRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: Number(params.parameters.custpage_addon_line - 1) });
                                salesRecord.setSublistValue({ sublistId: 'item', fieldId: 'amount', value: currentAmount + addonPrice, line: Number(params.parameters.custpage_addon_line - 1) });
                                salesRecord.save();
                            }
                            else {
                                var quotationRecord = record.load({ type: 'estimate', id: Number(params.parameters.custpage_quotation), isDynamic: false });
                                // quotationRecord.selectLine({ sublistId: 'item', line: Number(params.parameters.custpage_addon_line) });
                                var currAddonPrice = quotationRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', line: Number(params.parameters.custpage_addon_line - 1) });
                                log.debug("addonPrice", addonPrice);
                                quotationRecord.setSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', value: currAddonPrice + addonPrice, line: Number(params.parameters.custpage_addon_line - 1) });
                                var currentAmount = +quotationRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: Number(params.parameters.custpage_addon_line - 1) });
                                quotationRecord.setSublistValue({ sublistId: 'item', fieldId: 'amount', value: currentAmount + addonPrice, line: Number(params.parameters.custpage_addon_line - 1) });
                                quotationRecord.save();
                            }
                            // quotationRecord.commitLine({ sublistId: 'item', ignoreRecalc: true });
                        }

                        if (recordType == 'salesorder') redirect.toRecord({ id: Number(params.parameters.custpage_quotation), type: 'salesorder', isEditMode: false });
                        else redirect.toRecord({ id: Number(params.parameters.custpage_quotation), type: 'estimate', isEditMode: false });


                    }
                }
                catch (e) {
                    log.error('Error in POST', e)
                }
            }
        }

        function formattingDate(objDate) {
            try {

                objDate = format.parse({ type: format.Type.DATE, value: objDate });
                log.debug("After Format", objDate);
                objDate = format.format({ type: format.Type.DATE, value: objDate });
                log.debug("After Parse", objDate);

                return objDate;
            } catch (e) {
                log.error("Error Inside formattingDate Function", e.message);
            }
        }
        function parsingDate(objDate) {
            try {

                objDate = format.parse({ type: format.Type.DATE, value: objDate });
                log.debug("After Parse", objDate);
                return objDate;
            } catch (e) {
                log.error("Error Inside formattingDate Function", e.message);
            }
        }

        function runSuiteQuery(queryName, queryString) {
            log.debug("Query String For : " + queryName + "->", queryString);
            var resultSet = query.runSuiteQL({ query: queryString });
            log.debug("Query Mapped Data For : " + queryName + "->", resultSet.asMappedResults());
            if (resultSet && resultSet.results && resultSet.results.length > 0) {
                return resultSet.asMappedResults();
            } else {
                return [];
            }
        }

        function getfileId(clientScript) {
            //we can make it as function to reuse.
            var search_folder = search.create({
                type: 'folder',
                filters: [{
                    name: 'name',
                    join: 'file',
                    operator: 'is',
                    values: clientScript
                }],
                columns: [{
                    name: 'internalid',
                    join: 'file',
                }]
            });
            var searchFolderId = '';
            var searchFolderName = '';
            search_folder.run().each(function (result) {
                searchFolderId = result.getValue({
                    name: 'internalid',
                    join: 'file'
                });
                log.debug('searchFolderId', searchFolderId);
                return true;
            });
            return searchFolderId;
        }

        return {
            onRequest: onRequest
        };

    });
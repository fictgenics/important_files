/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope public
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME:CSS_CS_Release_Inventory.js
* DEVOPS TASK: ENH/, BL/72172
* AUTHOR: Shalini Srivastava
* DATE CREATED: 4 March,2024
* DESCRIPTION: .
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*****************************************************************************/ 
 define(['N/currentRecord','N/search','N/https','N/record','N/url'],
	function(currentRecord,search,https,record,url) { 
		function pageInit(context){

		}
		function releaseInventory(recordId, authorId) {
			try {
				var output = url.resolveScript({
                    scriptId: "customscript_su_release_inventory_on_so",
                    deploymentId: "customdeploy_su_release_inventory_on_so",
                    params: { 'recordId': recordId}
                });
                var response = https.get({
                    url: output
                });
                var urlo = window.location.href;
                window.open(urlo, '_self')
				
			} catch (e) {
				log.error("Error Inside releaseInventory Function", e.message);
			}
		}	
		function getNumber(id) {
			var ret;
			ret = parseFloat(id);
			if(isNaN(ret)) {
				ret = 0;
			}
			return ret;
		}
		return {
			releaseInventory:releaseInventory,
			pageInit:pageInit
		};
	}
 );
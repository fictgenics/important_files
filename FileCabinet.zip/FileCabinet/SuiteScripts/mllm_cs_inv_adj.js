
 function FieldChanged(type, name)
 {

	if (name == 'custcol_advs_item_number' && type == 'inventory')
	{
		//nlapiLogExecution('DEBUG', ' name ' ,name); 
		//nlapiLogExecution('DEBUG', ' type ' ,type); 
		var itemNum = nlapiGetCurrentLineItemValue('inventory','custcol_advs_item_number');	
		//nlapiLogExecution('DEBUG', ' itemNum ' ,itemNum); 
		nlapiSetCurrentLineItemValue('inventory', 'item', itemNum) ;
	}
	
	return;
 }
 
function LineInit(type)
 {
	nlapiDisableLineItemField('inventory', 'item', true);
 }

 
 function PageInit(type)
 {
	nlapiDisableLineItemField('inventory', 'item', true);
 }
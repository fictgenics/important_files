/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

define(['N/record', 'N/search'], function (record, search) {
    var hasFulfillmentRequests = false;
    var hasSalesOrder = false;
    var milestoneArr = [];
    var mode;
    function pageInit(context) {

        try {
            var currentRecord = context.currentRecord;
            mode = context.mode;
            /**
             * If current Record type is SalesOrder -> then milestone should be validated, whether there are any milestone with fulfillment tagged or not?
             * If tagged then disable fields else allow changes.
             * 
             * If current Record type is Quotation -> then milestone should be validated, whether there are any milestone with SalesOrder tagged or not?
             * If tagged then disable fields else allow changes.
             */

            var recordType = currentRecord.type;

            if (recordType == 'estimate') { //For Quotataion
                var quotationId = currentRecord.id;
                var customrecord_c58005_payment_milestoneSearchObj = search.create({
                    type: "customrecord_c58005_payment_milestone",
                    filters:
                        [
                            ["custrecord_c58005_quotation", "anyof", quotationId]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "internalid", label: "Internal ID" }),
                            search.createColumn({ name: "custrecord_c58005_salesorder", label: "Sales Order" }),
                            search.createColumn({ name: "custrecord_c58005_milestone", label: "Milestone %" })
                        ]
                });
                var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
                customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                    /**
                     * If any line has Sales order, disable item sublist columns 
                     */
                    var currentLineSO = result.getValue({ name: "custrecord_c58005_salesorder", label: "Sales Order" });
                    if (currentLineSO) hasSalesOrder = true;
                    milestoneArr.push({ "milestone": Number(result.getValue({ name: "internalid", label: "Internal ID" })), "percentage": result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }) });
                    return true;
                });
            } else if (recordType == 'salesorder') { //For Sales Order
                var salesOrderId = currentRecord.id;
                var customrecord_c58005_payment_milestoneSearchObj = search.create({
                    type: "customrecord_c58005_payment_milestone",
                    filters: [
                        ["custrecord_c58005_salesorder", "anyof", salesOrderId]
                    ],
                    columns: [
                        search.createColumn({ name: "internalid", label: "Internal ID" }),
                        search.createColumn({ name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request" }),
                        search.createColumn({ name: "custrecord_c58005_milestone", label: "Milestone %" })
                    ]
                });
                var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

                if (searchResultCount > 0) {
                    customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                        /**
                         * If any line has fulfillment request, disable item sublist columns 
                         */
                        var currentLineFR = result.getValue({ name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request" });
                        if (currentLineFR) hasFulfillmentRequests = true;
                        milestoneArr.push({ "milestone": Number(result.getValue({ name: "internalid", label: "Internal ID" })), "percentage": result.getValue({ name: "custrecord_c58005_milestone", label: "Milestone %" }) });
                        return true;
                    });
                }
            }

            log.debug("recordType: " + recordType, "milestoneArr: " + milestoneArr);

            /**
             *  Disable the item sublist fields if there are any related fulfillment requests
             */

            log.debug("hasFulfillmentRequests: " + hasFulfillmentRequests, "hasSalesOrder: " + hasSalesOrder);
            if (hasFulfillmentRequests || hasSalesOrder) {
                var itemLineCount = currentRecord.getLineCount({ sublistId: 'item' });
                if (itemLineCount > 0) {
                    log.debug("Disabling Inside PageInit Function");

                    for (var i = 0; i < itemLineCount; i++) {
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'item', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'quantity', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'rate', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'amount', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'grossamt', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'taxcode', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'taxrate1', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'item', fieldId: 'tax1amt', line: i }).isDisabled = true;
                    }
                }
                /**
                 * Add code for no addons to be modified
                 */

                var addonLineCount = currentRecord.getLineCount({ sublistId: 'recmachcustrecord9' });
                if (addonLineCount > 0) {

                    for (var i = 0; i < itemLineCount; i++) {
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord9', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord10', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord12', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord13', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord14', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord15', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord16', line: i }).isDisabled = true;
                        currentRecord.getSublistField({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord17', line: i }).isDisabled = true;
                    }
                }
            }
        } catch (e) {
            log.error("Error Inside Page Init", e.message);
        }
    }

    function fieldChanged(context) {
        var currentRecord = context.currentRecord;
        var sublistName = context.sublistId;
        var sublistFieldName = context.fieldId;

        var currentUpdateMilestoneValue = currentRecord.getValue({ fieldId: 'custbody_update_milestone' });
        // Check if the sublist is 'item' and any related field for any chaanges
        if (!currentUpdateMilestoneValue && sublistName === 'item' && (sublistFieldName === 'quantity' || sublistFieldName === 'amount' || sublistFieldName === 'rate' || sublistFieldName === 'grossamt' || sublistFieldName === 'taxcode' || sublistFieldName === 'taxrate1' || sublistFieldName === 'tax1amt')) {
            currentRecord.setValue({ fieldId: 'custbody_update_milestone', value: true });
            log.debug("Marked Update Milestone True in ")
        }
    }

    function saveRecord(context) {
        var currentRecord = context.currentRecord;

        /**
         * Checking Record Type:
         * 
         * If Record is quotation: we have to divide amount equally to each milestone, if there is no SO created.
         *      If total amount is deacreased/increased then it will be adjusted to the all milestone.
         * If Record is salesorder: we have to divide the amount into remaining milestone.
         *      If total amount is deacreased/increased then it will be adjusted to the all except order milestone & increase/deacrese should be considered properly.
         */
        // Check if the milestone update flag is set

        if (mode == 'edit') {
            // var recordType = currentRecord.type;
            // var updateMilestoneFlag = currentRecord.getValue({ fieldId: 'custbody_update_milestone' });

            // log.debug("Inside Save Record", "recordType: " + recordType + " || updateMilestoneFlag: " + updateMilestoneFlag);
            // if (recordType == 'estimate') {
            //     log.debug("hasFulfillmentRequests: " + hasFulfillmentRequests, "hasSalesOrder: " + hasSalesOrder);

            //     if (updateMilestoneFlag && !hasSalesOrder) {
            //         var salesOrderId = currentRecord.id;

            //         alert("Milestones will be updated!");
            //         var totalAmount = currentRecord.getValue({ fieldId: 'total' });

            //         for (var i = 0; i < milestoneArr.length; i++) {
            //             log.debug("Milestone Data", "milestone: " + milestoneArr[i].milestone + " || percentage: " + milestoneArr[i].percentage);
            //             var milestoneRecord = record.load({ type: 'customrecord_c58005_payment_milestone', id: milestoneArr[i].milestone });

            //             /**
            //              * Calculate the milestone amount based on the percentage and total sales order amount
            //              */
            //             var milestoneAmount = (totalAmount * milestoneArr[i].percentage);
            //             log.debug("Index is : " + i, "milestoneAmount: " + milestoneAmount);

            //             // milestoneRecord.setValue({ fieldId: 'custrecord_c58005_milestone_amount', value: milestoneAmount });
            //         }

            //         /**
            //          * Reset the milestone update flag
            //          */
            //         currentRecord.setValue({ fieldId: 'custbody_update_milestone', value: false });
            //     }
            // } else if (recordType == 'salesorder') {

            // }
            try {
                var lineCount = currentRecord.getLineCount({ sublistId: 'item' });
                for (var i = 0; i < lineCount; i++) {
                    var rate = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'rate', line: i });
                    var quantity = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i });
                    var addon = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', line: i })
                    var amount = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'amount', line: i });
                    if (amount != (rate * quantity + addon)) {
                        // currentRecord.setSublistValue({ sublistId: 'item', fieldId: 'amount', line: i, value: rate * quantity + addon });
                        currentRecord.selectLine({ sublistId: 'item', line: i });
                        currentRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'amount', value: rate * quantity + addon });
                        currentRecord.commitLine({ sublistId: 'item' });
                    }
                }
                var addonLines = currentRecord.getLineCount({ sublistId: 'recmachcustrecord9' });
                log.debug("addonLines", addonLines);
                var addonObject = new Object();

                for (var i = 0; i < addonLines; i++) {
                    /**
                     * 0:Object
                    custrecord10:"4645"
                    custrecord10_display:"JBL Sound System"
                    custrecord11:"T"
                    custrecord12:"100.00"
                    custrecord14:"5451"
                    custrecord14_display:"BELTA : RBELTA1.5P_5-White/Black"
                    custrecord15:"2"
                    custrecord16:"F"
                    custrecord17:"1"
                    custrecord9:"315358"
                    id:"1643"
                    owner:"39383"
                    sys_id:"7821006222829504"
                    sys_parentid:"7821006222525283"
                    version:"0"
                     */
                    var itemLine = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord15', line: i });
                    var quantity = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord17', line: i });
                    var price = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord12', line: i });
                    if(!price) price = 0;
                    if (addonObject.hasOwnProperty(itemLine - 1)) {
                        addonObject[itemLine - 1] += quantity * price;
                    }
                    else {
                        addonObject[itemLine - 1] = quantity * price;
                    }
                }
                log.debug("addonObject", addonObject);
                var objectKeys = Object.keys(addonObject);

                for (var index = 0; index < objectKeys.length; index++) {
                    var key = objectKeys[index];
                    var itemPrice = currentRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', line: parseInt(key, 10) });
                    if (itemPrice != addonObject[key]) {
                        currentRecord.selectLine({ sublistId: 'item', line: parseInt(key, 10) });
                        currentRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_addon_price', value: addonObject[key] });
                        currentRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'amount', value: rate * quantity + addonObject[key] });
                        currentRecord.commitLine({ sublistId: 'item' });
                    }
                }
            } catch (error) {
                log.error("Error in saveRecord addon price", error);
            }
        }


        return true;
    }

    return {
        pageInit: pageInit,
        fieldChanged: fieldChanged,
        saveRecord: saveRecord
    };
});
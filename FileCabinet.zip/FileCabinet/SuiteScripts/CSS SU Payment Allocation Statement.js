/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */ 
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Payment Allocation PDF.js
* DEVOPS TASK: BL/59158
* AUTHOR: Akash Sharma
* DATE CREATED: 14-March-2023
* DESCRIPTION: This script is to generate pdf.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/record', 'N/ui/serverWidget', 'N/url', 'N/render', 'N/xml', 'N/format','N/search','N/query', 'N/currency'],

    (record, serverWidget, url, render, xml, format,search, query, currency) => {
		const FORM_LABEL = "Apply PDF Filters!";
		
		const onRequest = (scriptContext) => {
			
			if(scriptContext.request.method == 'GET'){
    		
                renderPageOnGet(scriptContext);
                
            }
		}

		function renderPageOnGet(scriptContext){
			log.debug("Inside renderPageOnGet  Function!");

			let parameters = scriptContext.request.parameters;
            let fromPDF = parameters.frompdf || "";

			log.debug("parameters",parameters);

			if(fromPDF == 'true' || fromPDF == true){
				var customerId = Number(parameters.customerid);
				log.debug("When frompdf param is true", "customerId : "+customerId);
				
				var fromDate = parameters.fromdate;
				var toDate = parameters.todate;

				// log.debug("fromDate",fromDate);
				// log.debug("toDate",toDate);
				try{

					var getData = searchData(customerId, fromDate, toDate);		
					// log.debug("getData", getData);

					var currencySymbol = runSuiteQuery("select displaysymbol from currency where id = (select currency from customer where id = "+customerId+")");
					currencySymbol = currencySymbol[0]['displaysymbol'];
					log.debug("currencySymbol", currencySymbol);

					var appliedInvAmtSearchObj = search.create({
						type: "customerdeposit",
						filters:
							[
								["type","anyof","CustDep"], 
								"AND", 
								["mainline","is","F"],
								"AND", 
      							["customer.internalid","anyof",customerId]
							],
						columns:
							[
								search.createColumn({name: "debitfxamount",join: "applyingTransaction",summary: "SUM",sort: search.Sort.ASC,label: "Amount (Debit) (Foreign Currency)"}),
								search.createColumn({name: "amount",summary: "SUM",label: "Amount"})
							]
					});
		
					var appliedInvAmtSearchResultCount = appliedInvAmtSearchObj.runPaged().count;
					var totalDeposit;
					var appliedInvAmt = 0;
					if(appliedInvAmtSearchResultCount > 0){
						var appliedInvAmtSearchResult = appliedInvAmtSearchObj.run().getRange({ start: 0, end: 1 });

						totalDeposit = (appliedInvAmtSearchResult[0].getValue({name: "amount",summary: "SUM",label: "Amount"})); //1
						if(!totalDeposit) totalDeposit = 0.0;
						appliedInvAmt = (appliedInvAmtSearchResult[0].getValue({name: "debitfxamount",join: "applyingTransaction",summary: "SUM",sort: search.Sort.ASC,label: "Amount (Debit) (Foreign Currency)"})); //2
						if(!appliedInvAmt) appliedInvAmt = 0.0;
					}
					

					

					var nonInvoicedAmt = runSuiteQuery(`select sum(custrecord_c58005_milestone_applied_amt) as non_invoiced_amount from customrecord_c58005_payment_milestone where custrecord_c58005_customer = ${customerId} and custrecord_c58005_invoice is null`); //3
					nonInvoicedAmt = (nonInvoicedAmt[0]['non_invoiced_amount']);
					if(!nonInvoicedAmt) nonInvoicedAmt = 0.0;

					var fieldLookup = search.lookupFields({
						type: search.Type.CUSTOMER,
						id: customerId,
						columns: ['depositbalance']
					});
					var openDepositBalance = (fieldLookup.depositbalance); //4
					if(!openDepositBalance) openDepositBalance = 0.0;

					

					var unpaidInvoicesQuery = runSuiteQuery(`select balancesearch, altname from customer where id = ${customerId}`); //5
					// log.debug("unpaidInvoices query", unpaidInvoices);
					unpaidInvoices = (unpaidInvoicesQuery[0]['balancesearch']);
					if(!unpaidInvoices) unpaidInvoices = 0.0;
					log.debug("unpaidInvoices", unpaidInvoices);
					log.debug("unpaidInvoices[0]['altname']",unpaidInvoicesQuery[0]['altname']);
					
					

					var unpaidMileStoneBalance = runSuiteQuery(`select sum(custrecord_c58005_milestone_amount) as unappliedamt from customrecord_c58005_payment_milestone where custrecord_c58005_customer = ${customerId} and custrecord_c58005_milestone_applied_amt = 0`); //6
					unpaidMileStoneBalance = (unpaidMileStoneBalance[0]['unappliedamt']);
					if(!unpaidMileStoneBalance) unpaidMileStoneBalance = 0.0;

					var excessShortageOfDeposits = (openDepositBalance - unpaidInvoices - unpaidMileStoneBalance); //7
					if(!excessShortageOfDeposits) excessShortageOfDeposits = 0.0;

					var totalInvoiceToDate = runSuiteQuery(`select sum(foreigntotal) as totalamount from transaction t where t.type = 'CustInvc' and t.entity = ${customerId}`); //8
					totalInvoiceToDate = ((totalInvoiceToDate[0]['totalamount']));

					var openSalesOrderValueSearchObj = search.create({
						type: "salesorder",
						filters:
							[
								["type","anyof","SalesOrd"], 
								"AND", 
								["status","anyof","SalesOrd:D","SalesOrd:A","SalesOrd:F","SalesOrd:E","SalesOrd:B"], 
								"AND", 
								["customer.internalid","anyof",customerId], 
								"AND", 
								["mainline","is","F"]
							],
						columns:
							[
								search.createColumn({name: "fxamount",summary: "SUM",sort: search.Sort.ASC,label: "Amount (Foreign Currency)"})
							]
					});
		
					var openSalesOrderValueSearchResultCount = openSalesOrderValueSearchObj.runPaged().count;
					var openSalesOrderValue = 0.0;
					if(openSalesOrderValueSearchResultCount > 0){
						var openSalesOrderValueSearchResult = openSalesOrderValueSearchObj.run().getRange({ start: 0, end: 1 });
						openSalesOrderValue = (openSalesOrderValueSearchResult[0].getValue({name: "fxamount",summary: "SUM",sort: search.Sort.ASC,label: "Amount (Foreign Currency)"})); //9
						if(!openSalesOrderValue) openSalesOrderValue = 0.0;
					}

					var addressText = getData[0].getValue({name: "billaddress", join: "CUSTRECORD_C58005_CUSTOMER", label: "Billing Address"});

					log.debug("totalDeposit", totalDeposit);
					log.debug("appliedInvAmt", appliedInvAmt);
					log.debug("nonInvoicedAmt", nonInvoicedAmt);
					log.debug("openDepositBalance", openDepositBalance);
					log.debug("unpaidInvoices", unpaidInvoices);
					log.debug("unpaidMileStoneBalance", unpaidMileStoneBalance);
					log.debug("excessShortageOfDeposits", excessShortageOfDeposits);
					log.debug("totalInvoiceToDate", totalInvoiceToDate);
					log.debug("openSalesOrderValue", openSalesOrderValue);
					log.debug("addressText",addressText);


					
		
					var logo = 'http://5676368-sb1.shop.netsuite.com/core/media/media.nl?id=21&c=5676368_SB1&h=0iUmFiqoj2gtER7MvyrfZfWk1ExT3GTx0kpBg4oRUMN2bpqn';
					logo = xml.escape({
						xmlText : logo
					});
					// var mainXml = '<?xml version="1.0"?><!DOCTYPE pdf PUBLIC "-//big.faceless.org//report" "report-1.1.dtd">';
					var mainXml = '<?xml version="1.0"?><!DOCTYPE pdf PUBLIC "-//big.faceless.org//report" "report-1.1.dtd">';
					mainXml += '<pdf width="800" height="600"><head>';
					mainXml += '<macrolist>';
					mainXml += '<macro id="nlheader">';
					mainXml += '<table width="100%" style="border: 0px solid black;"><tr align="left">';
					mainXml += '<td><table width = "550px" style="border: 0px solid black;"><tr><td><img src="'+logo+'" width="222" height="60"/></td></tr>';
					mainXml += '<tr><td></td></tr>';
					mainXml += '<tr><td></td>';
					mainXml += '<td></td></tr>';
					mainXml += '<tr><td>Customer Name :</td>';
					mainXml += '<td>'+unpaidInvoicesQuery[0]['altname']+'</td></tr>';
					mainXml += '<tr><td></td>';
					mainXml += '<td></td></tr>';
					mainXml += '<tr><td>Customer Bill TO Address :</td>';
					mainXml += '<td>'+addressText+'</td></tr>';
					mainXml += '</table></td>';
					mainXml += '<td><table width="800px" align = "right" style="border: 0px solid black;">';

					mainXml += '<tr align="right"><td><b>Total Deposits To Date :</b></td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(totalDeposit).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td>';
					mainXml += '<td></td>';
					mainXml += '<td>Total Invoices to Date :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(totalInvoiceToDate).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td>Amount Applied against Previous Invoices :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(appliedInvAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td>';
					mainXml += '<td></td>';
					mainXml += '<td>Open Sales Order Value :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(openSalesOrderValue).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td>Amount Applied against Active Milestones :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(nonInvoicedAmt).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td><b>Open Deposit Balance :</b></td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(openDepositBalance).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td>Unpaid Invoices :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(unpaidInvoices).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td>Total Unapplied Milestone Balance :</td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(unpaidMileStoneBalance).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';

					mainXml += '<tr align="right"><td><b>Excess/Shortage of Deposits* :</b></td>';
					mainXml += '<td align="right">'+currencySymbol+" "+`${parseFloat(excessShortageOfDeposits).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')}`+'</td></tr>';
					
					mainXml += '</table></td></tr></table>';
					mainXml += '</macro>';
					mainXml += '</macrolist>';
					mainXml += '</head>';			
					mainXml += '<body header="nlheader" header-height="15%" footer="nlfooter" footer-height="1%" size="A3-LANDSCAPE">';		
					
					// mainXml += '<br/><br/>'; 
		
					mainXml += '<p><h3>Customer Statement of Account</h3></p>';
		
					 
					if(getData.length > 0){
						// mainXml += '<table style="width:100%; float:left; border: 0.3px solid black; cellspacing:0; padding-top: 10px;" cellpadding="5" >';
						mainXml += '<table width="100%" style="border: 0.3px grey; cellpadding:2px; padding-bottom: 0px; cellspacing:0px; font-size:13px;">'; 
						mainXml += '<thead>'
						mainXml += '<tr>';
						// mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Quotation</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Order Info</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>SO Amount</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b># of Cars</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Fulfillment #</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Stage</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Exp Date</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;"><p style="text-align: left;"><b>Item (VINs)</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;" width = "130px"><p style="text-align: left;"><b>Milestone</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;" width = "100px"><p style="text-align: left;"><b>Amount Due</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;" width = "100px"><p style="text-align: left;"><b>Applied Payment</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;" width = "70px"><p style="text-align: left;"><b>Reversable?</b></p></th>';
						mainXml += '<th style="border: 0.3px solid grey;" width = "60px"><p style="text-align: left;"><b>Invoice #</b></p></th>';
						// mainXml += '<th style="border: 0.3px solid grey;" width = "30px"><p style="text-align: left;"><b>Paid</b></p></th>';
						
						mainXml += '</tr>';
						mainXml += '</thead>';
						// log.debug("When (getData.length > 0) == true", getData.length);
		
						for(var i = 0; i < getData.length; i++){
							var quotationVal = getData[i].getText({name: "custrecord_c58005_quotation", label: "Quotation"});
							var orderNumber = getData[i].getText({name: "custrecord_c58005_salesorder", label: "Sales Order"});
							var poNumber = getData[i].getValue({name: "formulatext", formula: "{custrecord_c58005_salesorder.otherrefnum}", label: "Formula (Text)"});
							// log.debug("poNumber", poNumber);
							if(!poNumber){
								poNumber = "";
							}
							var soAmount = parseFloat(getData[i].getValue({name: "total",join: "CUSTRECORD_C58005_SALESORDER",label: "Amount (Transaction Total)"}));
							if(soAmount){
								soAmount = parseFloat(soAmount).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
							}else{
								soAmount = 0.0;
							}
							var ofCars = getData[i].getValue({name: "quantity",join: "CUSTRECORD_C58005_ITEM_FULFILLMENT",label: "Quantity"});
							// log.debug("ofCars", ofCars);
							var fulfillment = getData[i].getText({name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request"});
							var iFulfillment = getData[i].getValue({name: "custrecord_c58005_item_fulfillment", label: "Item Fulfillment"});
							if(iFulfillment)
								iFulfillment = (getData[i].getText({name: "custrecord_c58005_item_fulfillment", label: "Item Fulfillment"})).split("#")[1];
							else
								iFulfillment = "";

							var expDate = getData[i].getValue({name: "trandate",join: "CUSTRECORD_C58005_SALESORDER",label: "Date"});
							if(expDate){
								expDate = format.parse({type: format.Type.DATE, value: expDate});
								expDate = expDate.getDate()+"/"+Number(expDate.getMonth()+1)+"/"+expDate.getFullYear();
							}else{
								expDate = "";
							}
							
							var item = getData[i].getText({name: "item",join: "CUSTRECORD_C58005_ITEM_FULFILLMENT",label: "Item"});
							var srLotNum = (getData[i].getValue(getData[i].columns[11]));
							srLotNum = srLotNum.replaceAll("\n",",");
							// log.debug("srLotNum",srLotNum);
							var milestone = getData[i].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
							var amountDue = getData[i].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"});
							var reversable = '';
							var appliedAmount = getData[i].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"});							
							var invoice = getData[i].getValue({name: "custrecord_c58005_invoice", label: "Invoice"});
							var invoiceName = getData[i].getText({name: "custrecord_c58005_invoice", label: "Invoice"});
							if(invoice)
								invoiceName = invoiceName.split("#")[1];
							else
								invoiceName = "";
							var paid = '';

							var soQty = getData[i].getValue({name: "quantity", join: "CUSTRECORD_C58005_SALESORDER", label: "Quantity"});

							var invStatus = getData[i].getText({name: "statusref",join: "CUSTRECORD_C58005_INVOICE",label: "IV Status"});
							var frStatus = getData[i].getText({name: "statusref",join: "CUSTRECORD_C58005_FULFILLMENT_REQUEST",label: "FR Status"});
							// log.debug("invStatus", invStatus);
							// log.debug("frStatus",frStatus);

							var stage;
							if(invoiceName && invStatus && invStatus == 'Paid In Full'){
								stage = 'Closed';
							}else if(invoiceName && invStatus && invStatus != 'Paid In Full'){
								stage = 'Pending Final Bill Payment';
							}else if(iFulfillment){ //
								stage = 'Pending Shipment';
							// }else if('item fulfillment but the respective milestone did not funded yet'){ //
							// 	stage = 'Pending Shipment Funds';
							}else if(fulfillment && frStatus && frStatus == 'In Progress' && !iFulfillment){
								stage = 'Pending Work Order Completion';
							}else if(fulfillment && frStatus && frStatus != 'In Progress'){
								stage = 'Pending Work Order Funds';
							}else if(orderNumber && !fulfillment){
								stage = 'Pending Work Order Release';
							}else if(quotationVal && !orderNumber){
								stage = 'Pending Order Placement Funds';
							}
							
							

								if(i==0){
									mainXml += '<tr>';
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">Quotation<br/>'+quotationVal.split("#")[1]+'<br/>'+orderNumber+'<br/>'+poNumber+'</p></td>';
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+currencySymbol+" "+soAmount+'</p></td>';
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+soQty+'</p></td>';
									if(fulfillment && iFulfillment)
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+fulfillment.split("#")[1]+'<br/>'+iFulfillment+'</p></td>';
									else
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><br/></p></td>';
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+stage+'</p></td>';
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+expDate+'</p></td>';
									if(item)
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><b>'+item+'</b><br/><br/>- Qty: '+ofCars+'<br/>- VINs :'+srLotNum+'</p></td>';
									else
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';

									/**
									 * Setting Milestone
									 */
									var mileStoneArr = [];
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
									mainXml += '<table width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+milestone+'</p></td></tr>';
									if(milestone){
										mileStoneArr.push(i);
										
									}
									for(var k = i+1; k < getData.length; k++){
										if(fulfillment == getData[k].getText({name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request"})){
											if(getData[k-1].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}) != getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})){
												if((mileStoneArr.indexOf(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})) == -1) && mileStoneArr.length < 4){
													// log.debug(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}));
													mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
													mainXml += getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
													mainXml += '</p></td></tr>';
													mileStoneArr.push(k);
												}
											}											
										}else{
											break;
										}
									}			
									log.debug("mileStoneArr",mileStoneArr);						
									mainXml += '</table></p></td>';

									
									/**
									 * Setting Amount
									 */
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
									mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
									mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
									for(var l = 1; l < 4; l++){
									mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
									}
									mainXml += '</table></p></td>';

									/**
									 * Setting Applied Amount
									 */
									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
									mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
									if(parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
									mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
									else
									mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';

									for(var l = 1; l < 4; l++){
									if(parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
									mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
									else
									mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';
									}

									mainXml += '</table></p></td>';


									/**
									 * Setting Reversable
									 */

									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
									mainXml += '<table width = "82px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
									for(var l = 0; l < 4; l++){
										if(l == 0)
										mainXml += '<tr><td style="border-top-width:0.2px; border: 0px solid lightgrey;"><p style="text-align: left;">';
										else
										mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
										var booleanValue;
										var currentMileStone = getData[mileStoneArr[l]].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
										if(currentMileStone == 'Delivery Phase'){
											if(iFulfillment){
												booleanValue = 'No';
											}else{
												booleanValue = 'Yes';
											}
										}else if(currentMileStone == 'Order Phase'){
											if(orderNumber){
												booleanValue = 'No';
											}else{
												booleanValue = 'Yes';
											}											
										}else if(currentMileStone == 'Post-Delivery'){
											if(invoiceName){
												booleanValue = 'No';
											}else{
												booleanValue = 'Yes';
											}											
										}else if(currentMileStone == 'Work Order Release'){
											if(fulfillment.split("#")[1]){
												booleanValue = 'No';
											}else{
												booleanValue = 'Yes';
											}											
										}
										mainXml += booleanValue;
										mainXml += '</p></td></tr>';
									}
									mainXml += '</table></p></td>';

									/**
									 * Setting Invoice
									 */

									mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
									if(invoiceName)
									mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+invoiceName+'</p></td></tr>';
									else
									mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;"><br/></p></td></tr>';
									
			
									mainXml += '</table></p></td>';
									mainXml += '</tr>'; 
								}
								else{
									if(orderNumber == getData[i-1].getText({name: "custrecord_c58005_salesorder", label: "Sales Order"})){
										if(fulfillment != getData[i-1].getText({name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request"})){
											mainXml += '<tr>';
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';
											if(fulfillment && iFulfillment)
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+fulfillment.split("#")[1]+'<br/>'+iFulfillment+'</p></td>';
											else
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><br/></p></td>';
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+stage+'</p></td>';
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+expDate+'</p></td>';
											if(item)
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><b>'+item+'</b><br/><br/>- Qty: '+ofCars+'<br/>- VINs :'+srLotNum+'</p></td>';
											else
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';
		
											/**
											 * Setting Milestone
											 */
							
											var mileStoneArr = [];
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
											mainXml += '<table width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+milestone+'</p></td></tr>';
											if(milestone){
												mileStoneArr.push(i);
												// log.debug(milestone);
											}
											for(var k = i+1; k < getData.length; k++){
												if(fulfillment == getData[k].getText({name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request"})){
													if(getData[k-1].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}) != getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})){
														if((mileStoneArr.indexOf(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})) == -1) && mileStoneArr.length < 4){
															// log.debug(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}));
															mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
															mainXml += getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
															mainXml += '</p></td></tr>';
															mileStoneArr.push(k);
														}
													}											
												}else{
													break;
												}
											}									
											mainXml += '</table></p></td>';
											log.debug("mileStoneArr",mileStoneArr);	
		
											/**
											 * Setting Amount
											 */

											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
											mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
											mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
											for(var l = 1; l < 4; l++){
											mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
											}
											mainXml += '</table></p></td>';
		
											/**
											 * Setting Applied Amount
											 */

											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
											mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
											if(parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
											mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
											else
											mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';

											for(var l = 1; l < 4; l++){
											if(parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
											mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
											else
											mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';
											}

											mainXml += '</table></p></td>';
											
											
											/**
											 * Setting Reversable
											 */

											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
											mainXml += '<table width = "82px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
											for(var l = 0; l < 4; l++){
												if(l == 0)
												mainXml += '<tr><td style="border-top-width:0.2px; border: 0px solid lightgrey;"><p style="text-align: left;">';
												else
												mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
												var booleanValue;
												var currentMileStone = getData[mileStoneArr[l]].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
												if(currentMileStone == 'Delivery Phase'){
													if(iFulfillment){
														booleanValue = 'No';
													}else{
														booleanValue = 'Yes';
													}
												}else if(currentMileStone == 'Order Phase'){
													if(orderNumber){
														booleanValue = 'No';
													}else{
														booleanValue = 'Yes';
													}											
												}else if(currentMileStone == 'Post-Delivery'){
													if(invoiceName){
														booleanValue = 'No';
													}else{
														booleanValue = 'Yes';
													}											
												}else if(currentMileStone == 'Work Order Release'){
													if(fulfillment.split("#")[1]){
														booleanValue = 'No';
													}else{
														booleanValue = 'Yes';
													}											
												}
												mainXml += booleanValue;
												mainXml += '</p></td></tr>';
											}
											mainXml += '</table></p></td>';
		
											/**
											 * Setting Invoice
											 */
		
											mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
											if(invoiceName)
											mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+invoiceName+'</p></td></tr>';
											else
											mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;"><br/></p></td></tr>';
											
											mainXml += '</table></p></td>';
											mainXml += '</tr>'; 
										}
									}else if(orderNumber != getData[i-1].getText({name: "custrecord_c58005_salesorder", label: "Sales Order"})){
										mainXml += '<tr>';
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">Quotation<br/>'+quotationVal.split("#")[1]+'<br/>'+orderNumber+'<br/>'+poNumber+'</p></td>';
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+currencySymbol+" "+soAmount+'</p></td>';
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+soQty+'</p></td>';
										if(fulfillment && iFulfillment)
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+fulfillment.split("#")[1]+'<br/>'+iFulfillment+'</p></td>';
										else
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><br/></p></td>';
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+stage+'</p></td>';
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">'+expDate+'</p></td>';
										if(item)
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"><b>'+item+'</b><br/><br/>- Qty: '+ofCars+'<br/>- VINs :'+srLotNum+'</p></td>';
										else
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;"></p></td>';
										/**
										 * Setting Milestone
										 */

										var mileStoneArr = [];
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
										mainXml += '<table width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+milestone+'</p></td></tr>';
										if(milestone){
											mileStoneArr.push(i);
											// log.debug(milestone);
										}
										for(var k = i+1; k < getData.length; k++){
											if(fulfillment == getData[k].getText({name: "custrecord_c58005_fulfillment_request", label: "Fulfillment Request"})){
												if(getData[k-1].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}) != getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})){
													if((mileStoneArr.indexOf(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"})) == -1) && mileStoneArr.length < 4){
														// log.debug(getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"}));
														mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
														mainXml += getData[k].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
														mainXml += '</p></td></tr>';
														mileStoneArr.push(k);
													}
												}											
											}else{
												break;
											}
										}									
										mainXml += '</table></p></td>';
	
										log.debug("mileStoneArr",mileStoneArr);	
										
										/**
										 * Setting Amount
										 */
										
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
										mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
										mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
										for(var l = 1; l < 4; l++){
										mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
										}
										mainXml += '</table></p></td>';
	
										/**
										 * Setting Applied Amount
										 */	

										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
										mainXml += '<table  width = "132px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
										if(parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
										mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[0]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
										else
										mainXml += '<tr><td style="border-top-width:0px;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';

										for(var l = 1; l < 4; l++){
										if(parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})) > 0)
										mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+" "+parseFloat(getData[mileStoneArr[l]].getValue({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"})).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+'</p></td></tr>';
										else
										mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">'+currencySymbol+' 0.0</p></td></tr>';
										}

										mainXml += '</table></p></td>';

										/**
										 * Setting Reversable
										 */

										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
										mainXml += '<table width = "82px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;">';
										for(var l = 0; l < 4; l++){
											if(l == 0)
											mainXml += '<tr><td style="border-top-width:0.2px; border: 0px solid lightgrey;"><p style="text-align: left;">';
											else
											mainXml += '<tr><td style="border-top-width:0.2px; border: 0.3px solid lightgrey;"><p style="text-align: left;">';
											var booleanValue;
											var currentMileStone = getData[mileStoneArr[l]].getText({name: "custrecord_c58005_milestone_type", label: "Milestone Type"});
											if(currentMileStone == 'Delivery Phase'){
												if(iFulfillment){
													booleanValue = 'No';
												}else{
													booleanValue = 'Yes';
												}
											}else if(currentMileStone == 'Order Phase'){
												if(orderNumber){
													booleanValue = 'No';
												}else{
													booleanValue = 'Yes';
												}											
											}else if(currentMileStone == 'Post-Delivery'){
												if(invoiceName){
													booleanValue = 'No';
												}else{
													booleanValue = 'Yes';
												}											
											}else if(currentMileStone == 'Work Order Release'){
												if(fulfillment.split("#")[1]){
													booleanValue = 'No';
												}else{
													booleanValue = 'Yes';
												}											
											}
											mainXml += booleanValue;
											mainXml += '</p></td></tr>';
										}
										mainXml += '</table></p></td>';
	
										/**
										 * Setting Invoice
										 */
	
										mainXml += '<td style="border: 0.3px solid grey;"><p style="text-align: left;">';
										if(invoiceName)
										mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;">'+invoiceName+'</p></td></tr>';
										else
										mainXml += '<table width = "62px" style = "border:0px; cellpadding:0px; padding-bottom: 0px; cellspacing:0;"><tr><td style="border-top-width:0px;"><p style="text-align: left;"><br/></p></td></tr>';
										
										mainXml += '</table></p></td>';
										mainXml += '</tr>'; 
									}									
								}								
						}
						mainXml += '</table>';
					}				
					mainXml +=  '</body>\n</pdf>';	
		
					// log.debug('mainXml',mainXml);
					scriptContext.response.renderPdf(
					{
						xmlString: mainXml
					});
				}
				catch(e){
					log.debug('Exception while PDF Generate : ',[e.message, e.stack]);
					scriptContext.response.write("Something went wrong!");
				}
			}else{
				log.debug("When frompdf param is false");
				let form = serverWidget.createForm({title: FORM_LABEL});
				form.clientScriptModulePath = './CSS CS Payment Allocation PDF.js';

				let fromDateField = form.addField({id: 'custpage_pas_fromdate', label: 'From Date', type: serverWidget.FieldType.DATE});
				let toDateField = form.addField({id: 'custpage_pas_todate', label: 'To Date', type: serverWidget.FieldType.DATE});
				let customerField = form.addField({id: 'custpage_pas_customer', label: 'Customer', type: serverWidget.FieldType.SELECT, source: 'customer'});
				if(parameters.customerid){
					customerField.defaultValue = parameters.customerid;
					customerField.updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
				}

				

				form.addButton({id: 'custbutton_generate_pdf', label: 'Generate PDF', functionName: 'generatePDF('+Number(parameters.customerid)+')'});
				scriptContext.response.writePage(form);
			}
		}
		
		function runSuiteQuery(queryString) {
			log.debug("Query", queryString);
			var resultSet = query.runSuiteQL({query: queryString});
			log.debug("Query wise Data", resultSet.asMappedResults());
			if(resultSet && resultSet.results && resultSet.results.length > 0) {
				return resultSet.asMappedResults();
			} else {
				return [];
			}
		}

		function isNotNull(aVal){
			if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
				return true;
			else
				return false;
		}

		function searchData(customerId, fromDate, toDate){
			log.debug("Inside searchData Function!");
			var filters = [
				["custrecord_c58005_customer","anyof",customerId], 
				// "AND", 
				// ["custrecord_c58005_salesorder.mainline","is","T"], 
				// "AND", 
				// ["custrecord_c58005_fulfillment_request.mainline","is","F"], 
				"AND", 
				["custrecord_c58005_item_fulfillment.cogs","is","F"]
				// "AND", 
				// ["custrecord_c58005_item_fulfillment.shipping","is","F"], 
				// "AND", 
				// ["custrecord_c58005_item_fulfillment.taxline","is","F"]
				
			 ];

			if(fromDate && toDate){
            	filters.push("AND",["created","within",fromDate+" 12:00 am",toDate+" 11:59 pm"]);
            }
			// log.debug("filters",filters);

			 var columns = [
				search.createColumn({name: "custrecord_c58005_quotation", sort: search.Sort.ASC, label: "Quotation"}),
				search.createColumn({name: "custrecord_c58005_salesorder", sort: search.Sort.ASC, label: "Sales Order"}),
				search.createColumn({name: "total",join: "CUSTRECORD_C58005_SALESORDER",label: "Amount (Transaction Total)"}),
				search.createColumn({name: "custrecord_c58005_fulfillment_request", sort: search.Sort.ASC, label: "Fulfillment Request"}),
				search.createColumn({name: "trandate",join: "CUSTRECORD_C58005_SALESORDER",label: "Date"}),
				search.createColumn({name: "custrecord_c58005_milestone_type", sort: search.Sort.ASC, label: "Milestone Type"}),
				search.createColumn({name: "custrecord_c58005_milestone_amount", label: "Milestone Amount"}),
				search.createColumn({name: "custrecord_c58005_milestone_applied_amt", label: "Milestone Applied Amount"}),
				search.createColumn({name: "custrecord_c58005_invoice", label: "Invoice"}),
				search.createColumn({name: "item",join: "CUSTRECORD_C58005_ITEM_FULFILLMENT",label: "Item"}),
				search.createColumn({name: "quantity",join: "CUSTRECORD_C58005_ITEM_FULFILLMENT",label: "Quantity"}),
				search.createColumn({name: "serialnumbers",join: "CUSTRECORD_C58005_ITEM_FULFILLMENT",label: "Serial/Lot Numbers"}),
				search.createColumn({name: "custrecord_c58005_item_fulfillment", label: "Item Fulfillment"}),
				search.createColumn({name: "formulatext", formula: "{custrecord_c58005_salesorder.otherrefnum}", label: "Formula (Text)"}),
				search.createColumn({name: "billaddress", join: "CUSTRECORD_C58005_CUSTOMER", label: "Billing Address"}),
				search.createColumn({name: "quantity", join: "CUSTRECORD_C58005_SALESORDER", label: "Quantity"}),
				search.createColumn({name: "formulanumeric", formula: "CASE WHEN {custrecord_c58005_salesorder.internalid} > 0 THEN 1 ELSE 0 End", label: "SO Created"}),
				search.createColumn({name: "formulanumeric", formula: "CASE WHEN {custrecord_c58005_fulfillment_request.internalid} > 0 THEN 1 ELSE 0 End", label: "FR Created"}),
				search.createColumn({name: "formulanumeric", formula: "CASE WHEN {custrecord_c58005_item_fulfillment.internalid} > 0 THEN 1 ELSE 0 End", label: "IF Created"}),
				search.createColumn({name: "formulanumeric", formula: "CASE WHEN {custrecord_c58005_invoice.internalid} > 0 THEN 1 ELSE 0 End", label: "IV Created"}),
				search.createColumn({name: "statusref",join: "CUSTRECORD_C58005_INVOICE",label: "IV Status"}),
				search.createColumn({name: "statusref",join: "CUSTRECORD_C58005_FULFILLMENT_REQUEST",label: "FR Status"})
			 ];

			 var searcResults = searchAllRecord('customrecord_c58005_payment_milestone',null,filters,columns);
			 return searcResults;
		}

		function searchAllRecord(recordType,searchId,searchFilter,searchColumns){       
			try{   
				var arrSearchResults =[];
				var count = 1000,min = 0,max = 1000;
				var searchObj = false;
				
				if(recordType==null){
					recordType=null;
				}
				
				if (searchId)
				{
					searchObj = search.load({id : searchId});
					if (searchFilter)
					{
						searchObj.addFilters(searchFilter);
					}
					if (searchColumns)
					{
						searchObj.addColumns(searchColumns);
					}          
				}
				else
				{
					searchObj = search.create({type:recordType,filters:searchFilter,columns:searchColumns})
				}
				
				var rs = searchObj.run();           
				searchColumns.push(rs.columns);
				allColumns = rs.columns;
				
				while (count == 1000)
				{
					var resultSet = rs.getRange({start : min,end :max});                                           
					if(resultSet!=null)
					{
						arrSearchResults = arrSearchResults.concat(resultSet);
						min = max;
						max += 1000;
						count = resultSet.length;
					}
				}
			}
			catch (e)
			{
				log.debug( 'Error searching for Customer:- ', e.message);
			}
			return arrSearchResults;
		}


		return {onRequest}

    });
		



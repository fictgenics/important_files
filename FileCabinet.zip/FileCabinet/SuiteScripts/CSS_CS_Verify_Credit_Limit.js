/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH 57685,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/currentRecord', 'N/search', 'N/record', 'N/url', 'N/https'],

    function (currentRecord, search, record, url, https) {

        function pageInit(context) {

        }
        function onVerifyLimitButton(recId) {
            var rec = currentRecord.get();
            var custId = rec.id;
            var searchObj = search.create({
                type: "customrecord_c58005_payment_milestone",
                filters:
                    [
                        ["custrecord_c58005_customer.creditlimit", "greaterthan", "0.00"],
                        "AND",
                        ["custrecord_c58005_customer", "anyof", recId],
                        "AND",
                        ["custrecord_c58005_milestone_type", "anyof", "1"], "AND", ["custrecord_c58005_quotation.status", "anyof", "Estimate:A"],
                        "AND",
                        ["custrecord_c58005_quotation.mainline", "is", "T"]
                    ],
                columns:
                    [
                        search.createColumn({
                            name: "custrecord_c58005_milestone_amount",
                            summary: "SUM",
                            label: "Milestone Amount"
                        }),
                        search.createColumn({
                            name: "creditlimit",
                            join: "custrecord_c58005_customer",
                            summary: "GROUP",
                            label: "Credit Limit"
                        })
                    ]
            });
            var searchResult = searchObj.run().getRange(0, 1000);
            var creditLimit = 0;
            var milestoneAmt = 0;
            if (searchResult != null && searchResult != 0) {
                creditLimit = searchResult[0].getValue({ name: 'creditlimit', join: 'custrecord_c58005_customer', summary: 'GROUP' });
                milestoneAmt = searchResult[0].getValue({ name: 'custrecord_c58005_milestone_amount', summary: 'SUM' });
            }

            if (parseFloat(creditLimit) > parseFloat(milestoneAmt)) {
                var resp = confirm('Do you want to convert?');
                if (resp) {
                    var appliedAmt = milestoneAmt;
                    var unAppliedAmt = creditLimit - milestoneAmt;
                    record.submitFields({
                        type: 'customer',
                        id: recId,
                        values: {
                            'custentity_c58005_customer_applied_amt': milestoneAmt,
                            'custentity_c58005_customer_unapplied_amt': unAppliedAmt
                        }
                    });

                    var suiteletUrl = url.resolveScript({
                        scriptId: 'customscript_sl_convert_quotation',
                        deploymentId: 'customdeploy_sl_convert_quotation',
                        returnExternalUrl: false,
                        params: {
                            'custscript_customer': custId,
                        }
                    });

                    var headerObj = {
                        name: 'Accept-Language',
                        value: 'en-us'
                    };
                    https.post.promise({
                        url: suiteletUrl,
                        body: 'My POST Data',
                        headers: headerObj
                    });
                    window.location.reload();
                    return false;
                }
            }
            else {
                alert('Quotation will not be converted because credit limit is less than Applied amount.');
            }
            return true;

        }
        return {
            pageInit: pageInit,
            onVerifyLimitButton: onVerifyLimitButton
        }


        function getNumber(id) {
            var ret;
            ret = parseFloat(id);
            if (isNaN(ret)) {
                ret = 0;
            }
            return ret;
        }

        function isNotNull(aString) {

            if (aString && aString !== 'undefined' && aString !== null && aString !== '' && aString !== 'null')
                return true;
            else
                return false;
        }


    }
);
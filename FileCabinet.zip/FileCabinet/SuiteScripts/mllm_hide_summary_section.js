function hidesummaryBeforeLoad(type) 
{ 
  	var field = nlapiGetField('subtotal');
  	if(field != null) 
    {
		field.setDisplayType('hidden');
	}
  
    var field = nlapiGetField('taxtotal');
  	if(field != null) 
    {
		field.setDisplayType('hidden');
	}
  	
  	var field = nlapiGetField('total');
  	if(field != null) 
    {
		field.setDisplayType('hidden');
	}
  
    var field = nlapiGetField('altshippingcost');
  	if(field != null) 
    {
		field.setDisplayType('hidden');
	}
  
    var field = nlapiGetField('altshippingcost');
  	if(field != null) 
    {
		field.setDisplayType('hidden');
	} 
}
function afterSubmit(type)
{
    try{

        if(type == 'create' || type == 'edit'){

            var recId = nlapiGetRecordId();
            var recType = nlapiGetRecordType();

            var itemRecord = nlapiLoadRecord(recType, recId);
            var vendorCnt = itemRecord.getLineItemCount('itemvendor');
            if(vendorCnt > 0){
               var leastPrice = [];
                //var baseP = 0;
                //var vendorId = null;
                for(var i = 1; i <= vendorCnt; i++){
                    
                    itemRecord.selectNewLineItem('itemvendor');
                    //var vendorName = getCurrentLineItemValue('itemvendor', 'vendor');

                    var subRecord = itemRecord.viewLineItemSubrecord('itemvendor', 'itemvendorprice', i);
                    //vendorprice itemvendorpricelines 
                    subRecord.selectNewLineItem('itemvendorpricelines');
                    var vendorPrice = Number(subRecord.getLineItemValue('itemvendorpricelines', 'vendorprice', 1));
                    if(vendorPrice){
                        leastPrice.push(vendorPrice);
                        
                    }


                }

                var leastP = Math.min.apply(null, leastPrice);
                
                nlapiSubmitField(recType, recId, 'cost', leastP);
            }

        }

    }catch(ex){
        nlapiLogExecution('DEBUG', 'DETAILS', ex.message);
    }
}
/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/search','N/currentRecord','N/ui/serverWidget', './Matrix Items.lib.js'],(search, currentRecord,serverWidget,mat) => {
    const beforeLoad = (scriptContext) => {
        try{
            let newRec = scriptContext.newRecord;
            let parentItem = newRec.getValue({fieldId: 'parent'});
            // log.debug("parentItem", parentItem);
            if(scriptContext.type == 'view' || scriptContext.type =='edit')
            {
                var fields = contextValues(scriptContext);

                fields.forEach(function(fieldObj){
                    var fieldID = fieldObj.actualFieldId;
                    var fieldValue = newRec.getValue({ fieldId: fieldID });
                    //If field is empty then disable
                    if (!fieldValue || fieldValue.length <= 0 || fieldValue == "") {
                        // log.debug("when no value found", fieldID);
                        scriptContext.form.getField({id: fieldID}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
                    } 
                });
            }
            if ((scriptContext.type === scriptContext.UserEventType.VIEW) && !(parentItem)) {
                scriptContext.form.addButton({id : "custpage_open_suitelet_add_item",label : "Create Item",functionName : 'openSuiteletItemAdd(' + newRec.id + ')'});
                scriptContext.form.addButton({id : "custpage_open_suitelet_add_option",label : "Add Option",functionName : 'openSuiteletOptionAdd(' + newRec.id + ')'});
                scriptContext.form.clientScriptModulePath = "./CSS CS Create Matrix Item.js";                                    
            } else if((scriptContext.type === scriptContext.UserEventType.VIEW) && (parentItem)){
                scriptContext.form.addButton({id : "custpage_open_suitelet_add_item",label : "Duplicate Item",functionName : 'openSuiteletItemDuplicate('+ parentItem + ',' + newRec.id + ')'});
                scriptContext.form.clientScriptModulePath = "./CSS CS Create Matrix Item.js"; 
            }
            
        }catch(e){
            log.error("Error inside before load", [e.message,e.stack]);
        }
    }
    return {beforeLoad}
});
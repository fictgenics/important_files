/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope Public
 */
define(['N/record', 'N/search', 'N/encode', 'N/https', 'N/file', 'N/email'], function (record, search, encode, https, file, emailmod) {

  function beforeLoad(context) {
    try {
      let newRecordObj = context.newRecord;

      let lineCount = newRecordObj.getLineCount({
        sublistId: "item"
      });

      log.debug("lineCount",lineCount);

      for(var lineNumber = 0; lineNumber<lineCount;lineNumber++){
        newRecordObj.setSublistValue({
          sublistId: "item",
          fieldId: "custcol_c61406_line_id",
          line: lineNumber,
          value: lineNumber+1
        })
      }

     


    } catch (e) {
      log.error("An error occurred", e.toString());
    }
  }

  const isNotNull = (data) => {
    if (data == null || data == '' || data == undefined) return false;
    return true;
  }

  return {
    beforeLoad: beforeLoad
  };
});
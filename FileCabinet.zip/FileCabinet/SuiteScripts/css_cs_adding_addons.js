/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: CSS_CS_Show_Alert_For_Milestone%.js
* DEVOPS TASK: ENH 58005,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 9/Feb/2022
* DESCRIPTION: T'Approved'.
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/currentRecord', 'N/search', './lodash.min'],

	function (currentRecord, search, lodash) {


		// function validateLine(context) {
		// 	var sublistName = context.sublistId;
		// 	if (sublistName == 'item') {
		// 		var currentRecord = context.currentRecord;
		// 		var currIndex = currentRecord.getCurrentSublistIndex({ sublistId: 'item' });
		// 		var addOnArray = [];
		// 		var lineItem = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'item' });
		// 		var lineNumber = currentRecord.findSublistLineWithValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord14', value: lineItem });
		// 		var lineIndex = currentRecord.findSublistLineWithValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord15', value: Number(currIndex) + 1 });

		// 		if (lineNumber == -1 && lineIndex == -1) {
		// 			var subitemOf = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_subitem_of' });
		// 			var itemVariant = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_variant' });
		// 			var itemModel = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_model' });

		// 			if (subitemOf) {
		// 				var customrecord_c60520_makes_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_makes_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord4", "anyof", subitemOf]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord_c60520_make_add_on", label: "Add-On" }),
		// 							search.createColumn({ name: "custrecord4", label: "Make (BGK)" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_makes_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord_c60520_make_add_on", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});
		// 			}

		// 			if (itemVariant) {
		// 				var customrecord_c60520_variant_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_variant_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord8", "anyof", itemVariant]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord8", label: "Variant (BGK)" }),
		// 							search.createColumn({ name: "custrecord7", label: "Add-On" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_variant_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord7", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});


		// 			}


		// 			if (itemModel) {
		// 				var customrecord_c60520_model_line_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_model_line_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord6", "anyof", itemModel]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord5", label: "Add-On" }),
		// 							search.createColumn({ name: "custrecord6", label: "Model Line (BGK)" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_model_line_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord5", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});
		// 			}


		// 			//alert(JSON.stringify(addOnArray));
		// 			for (var x = 0; x < addOnArray.length; x++) {
		// 				currentRecord.selectNewLine({ sublistId: 'recmachcustrecord9' });

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord14',
		// 					value: lineItem,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord15',
		// 					value: Number(currIndex) + 1,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord10',
		// 					value: addOnArray[x].addOnId,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord10',
		// 					value: addOnArray[x].addOnId,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord12',
		// 					value: addOnArray[x].addOnPrice,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord13',
		// 					value: addOnArray[x].addOnPrice,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.commitLine({ sublistId: 'recmachcustrecord9' });
		// 			}

		// 		}
		// 		else if (lineNumber == -1 && lineIndex > -1) {
		// 			var lineNum = currentRecord.getLineCount({ sublistId: 'recmachcustrecord9' });
		// 			for (var x = lineNum - 1; x >= 0; x--) {
		// 				var addOnLine = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord15', line: x });
		// 				if (addOnLine == Number(currIndex) + 1) {
		// 					currentRecord.removeLine({ sublistId: 'recmachcustrecord9', line: x, ignoreRecalc: true });
		// 				}
		// 			}

		// 			var subitemOf = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_subitem_of' });
		// 			var itemVariant = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_variant' });
		// 			var itemModel = currentRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_item_model' });

		// 			if (subitemOf) {
		// 				var customrecord_c60520_makes_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_makes_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord4", "anyof", subitemOf]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord_c60520_make_add_on", label: "Add-On" }),
		// 							search.createColumn({ name: "custrecord4", label: "Make (BGK)" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_makes_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord_c60520_make_add_on", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD_C60520_MAKE_ADD_ON", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});
		// 			}

		// 			if (itemVariant) {
		// 				var customrecord_c60520_variant_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_variant_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord8", "anyof", itemVariant]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord8", label: "Variant (BGK)" }),
		// 							search.createColumn({ name: "custrecord7", label: "Add-On" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_variant_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord7", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD7", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});


		// 			}


		// 			if (itemModel) {
		// 				var customrecord_c60520_model_line_bgk_recSearchObj = search.create({
		// 					type: "customrecord_c60520_model_line_bgk_rec",
		// 					filters:
		// 						[
		// 							["custrecord6", "anyof", itemModel]
		// 						],
		// 					columns:
		// 						[
		// 							search.createColumn({ name: "custrecord5", label: "Add-On" }),
		// 							search.createColumn({ name: "custrecord6", label: "Model Line (BGK)" }),
		// 							search.createColumn({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" })
		// 						]
		// 				});

		// 				customrecord_c60520_model_line_bgk_recSearchObj.run().each(function (result) {
		// 					var json = {};
		// 					json['addOnId'] = result.getValue({ name: "custrecord5", label: "Add-On" });
		// 					json['addOnPrice'] = result.getValue({ name: "baseprice", join: "CUSTRECORD5", label: "Base Price" });
		// 					var index = _.findIndex(addOnArray, function (o) { return o.addOnId == json['addOnId']; });
		// 					if (index == -1) {
		// 						addOnArray.push(json);
		// 					}
		// 					return true;
		// 				});
		// 			}


		// 			//alert(JSON.stringify(addOnArray));
		// 			for (var x = 0; x < addOnArray.length; x++) {
		// 				currentRecord.selectNewLine({ sublistId: 'recmachcustrecord9' });

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord14',
		// 					value: lineItem,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord15',
		// 					value: Number(currIndex) + 1,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord10',
		// 					value: addOnArray[x].addOnId,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord10',
		// 					value: addOnArray[x].addOnId,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord12',
		// 					value: addOnArray[x].addOnPrice,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.setCurrentSublistValue({
		// 					sublistId: 'recmachcustrecord9',
		// 					fieldId: 'custrecord13',
		// 					value: addOnArray[x].addOnPrice,
		// 					forceSyncSourcing: true
		// 				});

		// 				currentRecord.commitLine({ sublistId: 'recmachcustrecord9' });
		// 			}
		// 		}
		// 	}

		// 	return true;
		// }


		function validateDelete(context) {
			var sublistName = context.sublistId;
			if (sublistName === 'item') {
				var currentRecord = context.currentRecord;
				var currIndex = currentRecord.getCurrentSublistIndex({ sublistId: 'item' });
				var lineNum = currentRecord.getLineCount({ sublistId: 'recmachcustrecord9' });

				for (var x = lineNum - 1; x >= 0; x--) {
					var addOnLine = currentRecord.getSublistValue({ sublistId: 'recmachcustrecord9', fieldId: 'custrecord15', line: x });
					if (addOnLine == Number(currIndex) + 1) {
						currentRecord.removeLine({ sublistId: 'recmachcustrecord9', line: x, ignoreRecalc: true });
					}
				}
			}

			return true;
		}


		return {
			// validateLine: validateLine,
			validateDelete: validateDelete
		}
	}
);
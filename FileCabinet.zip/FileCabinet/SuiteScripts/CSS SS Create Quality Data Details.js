/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 */
/*****************************************************************************
 *  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SS Create Quality Data Details.js
* DEVOPS TASK: ----
* AUTHOR: Akash Sharma
* DATE MODIFIED: 25 Oct, 2023
* DESCRIPTION: This Script is for calculating quality data details.                      
*****************************************************************************/
define(['N/format', 'N/query', 'N/record', 'N/runtime', './Matrix Items.lib.js'],
    (format, query, record, runtime, mat) => {
        /**
         * Defines the Scheduled script trigger point.
         * @param {Object} scriptContext
         * @param {string} scriptContext.type - Script execution context. Use values from the scriptContext.InvocationType enum.
         * @since 2015.2
         */
        const execute = (scriptContext) => {
            try {
                // let actionType = Number(runtime.getCurrentScript().getParameter({ name: 'custscript_action_type' }));
                let itemId = runtime.getCurrentScript().getParameter({ name: 'custscript_qdd_item' });
                log.debug("itemId --->", itemId);
                let qualityDataRecIdArr = runtime.getCurrentScript().getParameter({ name: 'custscript_recordid' });
                if (!qualityDataRecIdArr) return;
                else qualityDataRecIdArr = qualityDataRecIdArr.split(",");

                for (let iteration = 0; iteration < qualityDataRecIdArr.length; iteration++) {
                    let qualityDataRecId = qualityDataRecIdArr[iteration];
                    log.debug("qualityDataRecId", qualityDataRecId);

                    let actionType = iteration + 1;
                    log.debug("Current Action ", actionType);

                    if (actionType == 1) {
                        /**
                       * Query for fetching ID's of Custom Field
                       */

                        let idFetch = runSuiteQuery("SELECT id, name, scriptid FROM customfield");
                        /**
                         * Fetching Selected Values
                         */

                        let mainArr = [];

                        var data = fieldsArray();
                        let itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

                        let parentItem = itemRecord.getValue({ fieldId: 'parent' });
                        var iter = 1;
                        data.forEach(field => {
                            var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
                            // let insideObj = {'data':fieldVar, };
                            if (fieldVar && fieldVar != '') {
                                /**
                                 * Add this ID to main array & we'll create them in map
                                 */

                                for (let i = 0; i < idFetch.length; i++) {
                                    let fieldIdText = (String(idFetch[i]['scriptid'])).toLowerCase();

                                    if (fieldIdText == (String(field.actualFieldId)).toLowerCase()) {
                                        mainArr.push({ 'curFieldId': field.actualFieldId, 'intid': idFetch[i]['id'], 'name': idFetch[i]['name'], 'itemId': itemId, 'sequence': iter });
                                        iter++;
                                        log.debug('DATA', 'curFieldId: ' + field.actualFieldId + ' || intid: ' + idFetch[i]['id'] + ' || name: ' + idFetch[i]['name'] + ' || itemId: ' + itemId + ' || sequence: ' + iter);
                                    }
                                }
                            }
                        });
                        // log.debug("mainArr", mainArr);

                        /**
                         * Create Quality Inspection
                         */
                        // let countSequence = runSuiteQuery("SELECT count(custrecord_qm_inspection_description) as total FROM customrecord_qm_quality_inspection where custrecord_qm_inspection_description = 'Attribute Check'");
                        // let newName = 'Attribute Check' + "_" + countSequence[0]['total'];
                        let newName = 'Attribute Check' + "_" + getDateStamp();
                        // log.debug("countSequence: " + countSequence[0]['total'], "newName: " + newName);
                        let qualityInspectionRecord = record.create({ type: 'customrecord_qm_quality_inspection' });
                        qualityInspectionRecord.setValue({ fieldId: 'name', value: newName });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_description', value: "Major Attribute Check at time of receiving to ensure we don't need to convert it to another car variant." });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_type', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_method', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_trans_freq', value: 0 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_sampling_rqmt', value: 1 });
                        let savedqualityInspectionRecord = qualityInspectionRecord.save();

                        log.debug("savedqualityInspectionRecord", savedqualityInspectionRecord);

                        if (savedqualityInspectionRecord) {
                            // log.debug("Inside For Loop", mainArr.length);
                            let parentItemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: parentItem });

                            for (let x = 0; x < mainArr.length; x++) {

                                let curFieldId = mainArr[x].curFieldId;
                                let intid = mainArr[x].intid;
                                let itemId = mainArr[x].itemId;
                                let sequence = mainArr[x].sequence;
                                let optionName = mainArr[x].name;

                                let actualParentValues = parentItemRecord.getText({ fieldId: curFieldId });
                                let splittedValue;
                                if (actualParentValues && actualParentValues != '') {
                                    splittedValue = String(actualParentValues).split(",");
                                    splittedValue.push('other');
                                    splittedValue = splittedValue.join(",");
                                }

                                /**
                                 * Adding Line Level of Quality Inspection/ Inspection Data Field
                                 */

                                let inspectionDataField = record.create({ type: 'customrecord_qm_inspection_properties' });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_seq', value: sequence });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_type', value: 10 });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_insp', value: savedqualityInspectionRecord });



                                let qualityInspectionField = record.create({ type: 'customrecord_qm_inspection_fields' });
                                qualityInspectionField.setValue({ fieldId: 'name', value: optionName });
                                qualityInspectionField.setValue({ fieldId: 'custrecord_qm_field_data_type', value: 10 });
                                qualityInspectionField.setValue({ fieldId: 'custrecord_qm_options', value: splittedValue });
                                qualityInspectionField.setValue({ fieldId: 'custrecord_qm_quality_insp_mandatory', value: true });
                                let savedQualityInspectionField = qualityInspectionField.save();
                                log.debug("savedQualityInspectionField", savedQualityInspectionField);

                                let savedInspectionDataField;
                                if (savedQualityInspectionField) {
                                    inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_field', value: savedQualityInspectionField });
                                    savedInspectionDataField = inspectionDataField.save();
                                    log.debug("savedInspectionDataField", savedInspectionDataField);

                                }

                                let qddRec = record.create({ type: 'customrecord_qm_quality_detail' });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_parent', value: Number(qualityDataRecId) });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_item', value: Number(itemId) });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_data_type', value: 10 });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_sequence', value: sequence });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_status', value: 4 });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_data_dtl_mandatory', value: true });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_inspection', value: savedqualityInspectionRecord });
                                qddRec.setValue({ fieldId: 'custrecord_qm_qdd_datatype_values', value: splittedValue });

                                if (savedQualityInspectionField) qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_field', value: savedQualityInspectionField });
                                let savedqddRec = qddRec.save();
                                log.debug("savedqddRec", savedqddRec);

                            }

                            let qdataRec = record.load({ type: 'customrecord_qm_quality_data', id: qualityDataRecId });
                            qdataRec.setValue({ fieldId: 'custrecord_qm_quality_data_inspection', value: savedqualityInspectionRecord });

                            let inspValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                            let specValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                            let qdActionType = qdataRec.getValue({ fieldId: 'custrecord_qm_action_type' });

                            let qsiQuery = runSuiteQuery("Select id, custrecord_qm_action_type_qsi from customrecord_qm_applied_inspections where custrecord_qm_applied_insp_specification = " + specValue + "");

                            for (var xx = 0; xx < qsiQuery.length; xx++) {
                                var qsiActionType = Number(qsiQuery[xx]['custrecord_qm_action_type_qsi']);
                                var qsiId = Number(qsiQuery[xx]['id']);
                                if (qsiActionType == qdActionType) {
                                    record.submitFields({
                                        type: 'customrecord_qm_applied_inspections',
                                        id: qsiId,
                                        values: { 'custrecord_qm_applied_insp_inspection': inspValue },
                                    });
                                }
                            }

                            let savedQdataRec = qdataRec.save();
                            log.debug("savedQdataRec", savedQdataRec);

                        }
                    } else if (actionType == 2) {
                        /**
                         * Create Quality Inspection
                         */
                        // let countSequence = runSuiteQuery("SELECT count(custrecord_qm_inspection_description) as total FROM customrecord_qm_quality_inspection where custrecord_qm_inspection_description = 'Car Condition Check'");
                        // let newName = 'Car Condition' + "_" + countSequence[0]['total'];
                        let newName = 'Car Condition' + "_" + getDateStamp();
                        // log.debug("countSequence: " + countSequence[0]['total'], "newName: " + newName);
                        let qualityInspectionRecord = record.create({ type: 'customrecord_qm_quality_inspection' });
                        qualityInspectionRecord.setValue({ fieldId: 'name', value: newName });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_description', value: "Car Condition Check" });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_type', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_method', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_trans_freq', value: 0 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_sampling_rqmt', value: 1 });
                        let savedqualityInspectionRecord = qualityInspectionRecord.save();

                        log.debug("savedqualityInspectionRecord", savedqualityInspectionRecord);

                        let mainArr = [
                            { 'fieldName': 'Windshield Wiper Issue', 'dataType': 'Text', 'sequence': 6 },
                            { 'fieldName': 'Windshield Wiper Check?', 'dataType': 'Boolean', 'sequence': 5 },
                            { 'fieldName': 'Seat Belts Checked?', 'dataType': 'Boolean', 'sequence': 4 },
                            { 'fieldName': 'Seat Belt Issue Description', 'dataType': 'Text', 'sequence': 3 },
                            { 'fieldName': 'Battery Voltage', 'dataType': 'Decimal', 'sequence': 2 },
                            { 'fieldName': 'Air Conditioning Temperature Check', 'dataType': 'Decimal', 'sequence': 1 }
                        ]

                        if (savedqualityInspectionRecord) {
                            // log.debug("Inside For Loop", mainArr.length);
                            for (let x = 0; x < mainArr.length; x++) {

                                let fieldName = mainArr[x].fieldName;
                                let dataType = mainArr[x].dataType;
                                let sequence = mainArr[x].sequence;

                                /**
                                 * Adding Line Level of Quality Inspection/ Inspection Data Field
                                 */

                                let inspectionDataField = record.create({ type: 'customrecord_qm_inspection_properties' });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_seq', value: sequence });
                                inspectionDataField.setText({ fieldId: 'custrecord_qm_inspection_prop_type', text: dataType });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_insp', value: savedqualityInspectionRecord });



                                let qualityInspectionField = record.create({ type: 'customrecord_qm_inspection_fields' });
                                qualityInspectionField.setValue({ fieldId: 'name', value: fieldName });
                                qualityInspectionField.setText({ fieldId: 'custrecord_qm_field_data_type', text: dataType });
                                let savedQualityInspectionField = qualityInspectionField.save();
                                log.debug("savedQualityInspectionField", savedQualityInspectionField);

                                let savedInspectionDataField;
                                if (savedQualityInspectionField) {
                                    inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_field', value: savedQualityInspectionField });
                                    savedInspectionDataField = inspectionDataField.save();
                                    log.debug("savedInspectionDataField", savedInspectionDataField);

                                }

                                let qddRec = record.create({ type: 'customrecord_qm_quality_detail' });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_parent', value: Number(qualityDataRecId) });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_item', value: Number(itemId) });
                                qddRec.setText({ fieldId: 'custrecord_qm_quality_detail_data_type', text: dataType });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_sequence', value: sequence });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_status', value: 4 });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_data_dtl_mandatory', value: true });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_inspection', value: savedqualityInspectionRecord });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_qdd_datatype_values', value: splittedValue });

                                if (savedQualityInspectionField) qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_field', value: savedQualityInspectionField });
                                let savedqddRec = qddRec.save();
                                log.debug("savedqddRec", savedqddRec);


                            }
                            // record.submitFields({
                            //     type: 'customrecord_qm_quality_data',
                            //     id: qualityDataRecId,
                            //     values: { 'custrecord_qm_quality_data_inspection': savedqualityInspectionRecord },
                            // });
                            let qdataRec = record.load({ type: 'customrecord_qm_quality_data', id: qualityDataRecId });
                            qdataRec.setValue({ fieldId: 'custrecord_qm_quality_data_inspection', value: savedqualityInspectionRecord });

                            let inspValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                            let specValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                            let qdActionType = qdataRec.getValue({ fieldId: 'custrecord_qm_action_type' });

                            let qsiQuery = runSuiteQuery("Select id, custrecord_qm_action_type_qsi from customrecord_qm_applied_inspections where custrecord_qm_applied_insp_specification = " + specValue + "");

                            for (var xx = 0; xx < qsiQuery.length; xx++) {
                                var qsiActionType = Number(qsiQuery[xx]['custrecord_qm_action_type_qsi']);
                                var qsiId = Number(qsiQuery[xx]['id']);
                                if (qsiActionType == qdActionType) {
                                    record.submitFields({
                                        type: 'customrecord_qm_applied_inspections',
                                        id: qsiId,
                                        values: { 'custrecord_qm_applied_insp_inspection': inspValue },
                                    });
                                }
                            }

                            let savedQdataRec = qdataRec.save();
                            log.debug("savedQdataRec", savedQdataRec);

                        }
                    } else if (actionType == 3) {
                        /**
                         * Create Quality Inspection
                         */

                        // let countSequence = runSuiteQuery("SELECT count(custrecord_qm_inspection_description) as total FROM customrecord_qm_quality_inspection where custrecord_qm_inspection_description = 'Car Photos'");
                        // let newName = 'Car Photos' + "_" + countSequence[0]['total'];
                        let newName = 'Car Photos' + "_" + getDateStamp();
                        // log.debug("countSequence: " + countSequence[0]['total'], "newName: " + newName);
                        let qualityInspectionRecord = record.create({ type: 'customrecord_qm_quality_inspection' });
                        qualityInspectionRecord.setValue({ fieldId: 'name', value: newName });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_description', value: "Car Photos" });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_type', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_method', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_trans_freq', value: 0 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_sampling_rqmt', value: 1 });
                        let savedqualityInspectionRecord = qualityInspectionRecord.save();

                        log.debug("savedqualityInspectionRecord", savedqualityInspectionRecord);

                        let mainArr = [
                            { 'fieldName': 'Photo 1', 'dataType': 'Image', 'sequence': 1 },
                            { 'fieldName': 'Photo 2', 'dataType': 'Image', 'sequence': 2 },
                            { 'fieldName': 'Photo 3', 'dataType': 'Image', 'sequence': 3 },
                            { 'fieldName': 'Photo 4', 'dataType': 'Image', 'sequence': 4 },
                            { 'fieldName': 'Photo 5', 'dataType': 'Image', 'sequence': 5 },
                            { 'fieldName': 'Photo 6', 'dataType': 'Image', 'sequence': 6 },
                            { 'fieldName': 'Photo 7', 'dataType': 'Image', 'sequence': 7 },
                            { 'fieldName': 'Photo 8', 'dataType': 'Image', 'sequence': 8 },
                            { 'fieldName': 'Photo 9', 'dataType': 'Image', 'sequence': 9 },
                            { 'fieldName': 'Photo 10', 'dataType': 'Image', 'sequence': 10 },
                            { 'fieldName': 'Defect Count', 'dataType': 'Integer', 'sequence': 11 }

                        ]

                        if (savedqualityInspectionRecord) {
                            // log.debug("Inside For Loop", mainArr.length);
                            for (let x = 0; x < mainArr.length; x++) {

                                let fieldName = mainArr[x].fieldName;
                                let dataType = mainArr[x].dataType;
                                let sequence = mainArr[x].sequence;

                                /**
                                 * Adding Line Level of Quality Inspection/ Inspection Data Field
                                 */

                                let inspectionDataField = record.create({ type: 'customrecord_qm_inspection_properties' });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_seq', value: sequence });
                                inspectionDataField.setText({ fieldId: 'custrecord_qm_inspection_prop_type', text: dataType });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_insp', value: savedqualityInspectionRecord });
                                inspectionDataField.setValue({ fieldId: 'customrecord_qm_inspection_properties', value: "Take a Photo" });

                                let qualityInspectionField = record.create({ type: 'customrecord_qm_inspection_fields' });
                                qualityInspectionField.setValue({ fieldId: 'name', value: fieldName });
                                qualityInspectionField.setText({ fieldId: 'custrecord_qm_field_data_type', text: dataType });
                                let savedQualityInspectionField = qualityInspectionField.save();
                                log.debug("savedQualityInspectionField", savedQualityInspectionField);

                                let savedInspectionDataField;
                                if (savedQualityInspectionField) {
                                    inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_field', value: savedQualityInspectionField });
                                    savedInspectionDataField = inspectionDataField.save();
                                    log.debug("savedInspectionDataField", savedInspectionDataField);

                                }

                                let qddRec = record.create({ type: 'customrecord_qm_quality_detail' });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_parent', value: Number(qualityDataRecId) });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_item', value: Number(itemId) });
                                qddRec.setText({ fieldId: 'custrecord_qm_quality_detail_data_type', text: dataType });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_sequence', value: sequence });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_status', value: 4 });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_data_dtl_mandatory', value: true });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_inspection', value: savedqualityInspectionRecord });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_qdd_datatype_values', value: splittedValue });

                                if (savedQualityInspectionField) qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_field', value: savedQualityInspectionField });
                                let savedqddRec = qddRec.save();
                                log.debug("savedqddRec", savedqddRec);

                            }
                            // record.submitFields({
                            //     type: 'customrecord_qm_quality_data',
                            //     id: qualityDataRecId,
                            //     values: { 'custrecord_qm_quality_data_inspection': savedqualityInspectionRecord },
                            // });

                            let qdataRec = record.load({ type: 'customrecord_qm_quality_data', id: qualityDataRecId });
                            qdataRec.setValue({ fieldId: 'custrecord_qm_quality_data_inspection', value: savedqualityInspectionRecord });

                            let inspValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                            let specValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                            let qdActionType = qdataRec.getValue({ fieldId: 'custrecord_qm_action_type' });

                            let qsiQuery = runSuiteQuery("Select id, custrecord_qm_action_type_qsi from customrecord_qm_applied_inspections where custrecord_qm_applied_insp_specification = " + specValue + "");

                            for (var xx = 0; xx < qsiQuery.length; xx++) {
                                var qsiActionType = Number(qsiQuery[xx]['custrecord_qm_action_type_qsi']);
                                var qsiId = Number(qsiQuery[xx]['id']);
                                if (qsiActionType == qdActionType) {
                                    record.submitFields({
                                        type: 'customrecord_qm_applied_inspections',
                                        id: qsiId,
                                        values: { 'custrecord_qm_applied_insp_inspection': inspValue },
                                    });
                                }
                            }

                            let savedQdataRec = qdataRec.save();
                            log.debug("savedQdataRec", savedQdataRec);

                        }
                    } else if (actionType == 4) {
                        /**
                         * Create Quality Inspection
                         */

                        // let countSequence = runSuiteQuery("SELECT count(custrecord_qm_inspection_description) as total FROM customrecord_qm_quality_inspection where custrecord_qm_inspection_description = 'Reference Photo'");
                        // let newName = 'Reference Photo' + "_" + countSequence[0]['total'];
                        let newName = 'Reference Photo' + "_" + getDateStamp();
                        // log.debug("countSequence: " + countSequence[0]['total'], "newName: " + newName);
                        let qualityInspectionRecord = record.create({ type: 'customrecord_qm_quality_inspection' });
                        qualityInspectionRecord.setValue({ fieldId: 'name', value: newName });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_description', value: "Reference Photo" });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_type', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_method', value: 1 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_trans_freq', value: 0 });
                        qualityInspectionRecord.setValue({ fieldId: 'custrecord_qm_inspection_sampling_rqmt', value: 1 });
                        let savedqualityInspectionRecord = qualityInspectionRecord.save();

                        log.debug("savedqualityInspectionRecord", savedqualityInspectionRecord);

                        let mainArr = [
                            { 'fieldName': 'Photo 1', 'dataType': 'Image', 'sequence': 1 },
                            { 'fieldName': 'Photo 2', 'dataType': 'Image', 'sequence': 2 },
                            { 'fieldName': 'Photo 3', 'dataType': 'Image', 'sequence': 3 },
                            { 'fieldName': 'Photo 4', 'dataType': 'Image', 'sequence': 4 },
                            { 'fieldName': 'Photo 5', 'dataType': 'Image', 'sequence': 5 },
                            { 'fieldName': 'Photo 6', 'dataType': 'Image', 'sequence': 6 },
                            { 'fieldName': 'Photo 7', 'dataType': 'Image', 'sequence': 7 },
                            { 'fieldName': 'Photo 8', 'dataType': 'Image', 'sequence': 8 },
                            { 'fieldName': 'Photo 9', 'dataType': 'Image', 'sequence': 9 },
                            { 'fieldName': 'Photo 10', 'dataType': 'Image', 'sequence': 10 },
                            // { 'fieldName': 'Defect Count', 'dataType': 'Integer', 'sequence': 11 }

                        ]

                        if (savedqualityInspectionRecord) {
                            // log.debug("Inside For Loop", mainArr.length);
                            for (let x = 0; x < mainArr.length; x++) {

                                let fieldName = mainArr[x].fieldName;
                                let dataType = mainArr[x].dataType;
                                let sequence = mainArr[x].sequence;

                                /**
                                 * Adding Line Level of Quality Inspection/ Inspection Data Field
                                 */

                                let inspectionDataField = record.create({ type: 'customrecord_qm_inspection_properties' });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_seq', value: sequence });
                                inspectionDataField.setText({ fieldId: 'custrecord_qm_inspection_prop_type', text: dataType });
                                inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_insp', value: savedqualityInspectionRecord });
                                inspectionDataField.setValue({ fieldId: 'customrecord_qm_inspection_properties', value: "Take a Photo" });

                                let qualityInspectionField = record.create({ type: 'customrecord_qm_inspection_fields' });
                                qualityInspectionField.setValue({ fieldId: 'name', value: fieldName });
                                qualityInspectionField.setText({ fieldId: 'custrecord_qm_field_data_type', text: dataType });
                                let savedQualityInspectionField = qualityInspectionField.save();
                                log.debug("savedQualityInspectionField", savedQualityInspectionField);

                                let savedInspectionDataField;
                                if (savedQualityInspectionField) {
                                    inspectionDataField.setValue({ fieldId: 'custrecord_qm_inspection_prop_field', value: savedQualityInspectionField });
                                    savedInspectionDataField = inspectionDataField.save();
                                    log.debug("savedInspectionDataField", savedInspectionDataField);

                                }

                                let qddRec = record.create({ type: 'customrecord_qm_quality_detail' });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_parent', value: Number(qualityDataRecId) });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_item', value: Number(itemId) });
                                qddRec.setText({ fieldId: 'custrecord_qm_quality_detail_data_type', text: dataType });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_sequence', value: sequence });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_status', value: 4 });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_data_dtl_mandatory', value: true });
                                qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_inspection', value: savedqualityInspectionRecord });
                                // qddRec.setValue({ fieldId: 'custrecord_qm_qdd_datatype_values', value: splittedValue });

                                if (savedQualityInspectionField) qddRec.setValue({ fieldId: 'custrecord_qm_quality_detail_field', value: savedQualityInspectionField });
                                let savedqddRec = qddRec.save();
                                log.debug("savedqddRec", savedqddRec);

                            }
                            // record.submitFields({
                            //     type: 'customrecord_qm_quality_data',
                            //     id: qualityDataRecId,
                            //     values: { 'custrecord_qm_quality_data_inspection': savedqualityInspectionRecord },
                            // });

                            let qdataRec = record.load({ type: 'customrecord_qm_quality_data', id: qualityDataRecId });
                            qdataRec.setValue({ fieldId: 'custrecord_qm_quality_data_inspection', value: savedqualityInspectionRecord });

                            let inspValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_inspection' });
                            let specValue = qdataRec.getValue({ fieldId: 'custrecord_qm_quality_data_target' });
                            let qdActionType = qdataRec.getValue({ fieldId: 'custrecord_qm_action_type' });

                            let qsiQuery = runSuiteQuery("Select id, custrecord_qm_action_type_qsi from customrecord_qm_applied_inspections where custrecord_qm_applied_insp_specification = " + specValue + "");

                            for (var xx = 0; xx < qsiQuery.length; xx++) {
                                var qsiActionType = Number(qsiQuery[xx]['custrecord_qm_action_type_qsi']);
                                var qsiId = Number(qsiQuery[xx]['id']);
                                if (qsiActionType == qdActionType) {
                                    record.submitFields({
                                        type: 'customrecord_qm_applied_inspections',
                                        id: qsiId,
                                        values: { 'custrecord_qm_applied_insp_inspection': inspValue },
                                    });
                                }
                            }

                            let savedQdataRec = qdataRec.save();
                            log.debug("savedQdataRec", savedQdataRec);

                        }
                    }
                }


            } catch (err) {
                log.error("Error Inside Get Input Data -->", [err.message, err.stack]);
            }
        }

        function getDateStamp(){
            return String(new Date()).split(" ")[0]+" "+String(new Date()).split(" ")[1]+" "+String(new Date()).split(" ")[2]+" "+String(new Date()).split(" ")[3]+" "+String(new Date()).split(" ")[4];
        }
        function runSuiteQuery(queryString) {
            log.debug("Query", queryString);
            let resultSet = query.runSuiteQL({
                query: queryString
            });
            log.debug("Query wise Data", resultSet.asMappedResults());
            if (resultSet && resultSet.results && resultSet.results.length > 0) {
                return resultSet.asMappedResults();
            } else {
                return [];
            }
        }

        return { execute }

    });

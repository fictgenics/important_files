/**
* @NApiVersion 2.1
* @NScriptType Suitelet
*/

/*******************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Create Item.js
* DEVOPS TASK: 
* AUTHOR: Akash Sharma
* DATE CREATED: 29-May-2023
* DESCRIPTION: Suitelet to Create Matrix SubItem
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/

define(['N/ui/serverWidget', 'N/format', 'N/search', 'N/record', 'N/url', 'N/redirect', './Matrix Items.lib.js', 'N/task', 'N/ui/message', 'N/query'],

  (serverWidget, format, search, record, url, redirect, mat, task, message, query) => {
    /*
    * Form Label
    * Pagination Page Size
    */
    const FORM_LABEL = "";

    /**
    * Defines the Suitelet script trigger point.
    * @param {Object} scriptContext
    * @param {ServerRequest} scriptContext.request - Incoming request
    * @param {ServerResponse} scriptContext.response - Suitelet response
    * @since 2015.2
    */
    const onRequest = (scriptContext) => {

      if (scriptContext.request.method == 'GET') {
        renderPageOnGet(scriptContext);
      } else {
        renderPageOnPost(scriptContext);
      }
    }

    function buildSourceList(selectedValues, selectedText, fieldVal) {
      // Create an array of objects containing both value and text
      var combinedArray = selectedValues.map((value, index) => ({ value, text: selectedText[index] }));

      // Sort the array of objects based on the 'value' property
      combinedArray.sort((a, b) => a.value - b.value);

      // Extract the sorted values and texts back into separate arrays
      sortedValues = combinedArray.map(item => item.value);
      sortedText = combinedArray.map(item => item.text);

      // log.debug("sortedValues", sortedValues);
      // log.debug("sortedText", sortedText);

      for (var x = 0; x < selectedValues.length; x++) {
        fieldVal.addSelectOption({
          value: selectedValues[x],
          text: selectedText[x]
        });
      }
      fieldVal.isMandatory = true;
    }

    function buildSourceListDefault(selectedValues, selectedText, fieldVal, selections) {
      // Create an array of objects containing both value and text
      var combinedArray = selectedValues.map((value, index) => ({ value, text: selectedText[index] }));

      // Sort the array of objects based on the 'value' property
      combinedArray.sort((a, b) => a.value - b.value);

      // Extract the sorted values and texts back into separate arrays
      sortedValues = combinedArray.map(item => item.value);
      sortedText = combinedArray.map(item => item.text);

      // log.debug("sortedValues", sortedValues);
      // log.debug("sortedText", sortedText);

      for (var x = 0; x < selectedValues.length; x++) {
        fieldVal.addSelectOption({
          value: selectedValues[x],
          text: selectedText[x]
        });
      }

      fieldVal.defaultValue = selections;
      fieldVal.isMandatory = true;
    }
    /**
    * Creating Suitelet
    * 
    * @param {scriptContext} context 
    */
    function renderPageOnGet(context) {

      try {

        /*
        * Getting Parameters from the URL of the Suitelet
        */
        let parameters = context.request.parameters;
        let matrixItemRecordId = parameters.mrecid || "";
        let recordFromSuitelet = parameters.mrecsl || "";
        let itemAddCall = parameters.itemadd || "";
        let optionAddCall = parameters.optionadd || "";
        let mrspecadd = parameters.mrspecadd || "";
        let duplicateAdd = parameters.dupadd || "";
        let subRecordId = parameters.msrecid || "";

        // log.debug("PARAMETERS on GET:", parameters + "| matrixItemRecordId:" + matrixItemRecordId + "| recordFromSuitelet:" + recordFromSuitelet);

        /*
        * Creating Suitelet Form
        */
        let form;
        let matrixOptions = getSelectedMatrixOptions(matrixItemRecordId);
        var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: matrixItemRecordId });
        var itemSubRecord;

        var data = fieldsArray();
        var formData = contextValues(context);

        if (itemAddCall == 'true' || itemAddCall == true) {
          form = serverWidget.createForm({ title: "Create SubMatrix Item" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            requestType.defaultValue = 'T';


            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }


            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              var fieldText = itemRecord.getText({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                var valueSplit = fieldVar;
                var textSplit = fieldText;
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: [] }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                buildSourceList(valueSplit, textSplit, myField);
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Create Item');
          context.response.writePage(form);
        } else if (duplicateAdd == 'true' || duplicateAdd == true) {
          itemSubRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: subRecordId });

          form = serverWidget.createForm({ title: "Duplicate SubMatrix Item" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            requestType.defaultValue = 'T';

            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              var fieldText = itemRecord.getText({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                let smy = itemSubRecord.getValue({ fieldId: field.actualFieldId });
                var valueSplit = fieldVar;
                var textSplit = fieldText;
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: [] }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                buildSourceListDefault(valueSplit, textSplit, myField, smy);
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Create Item');
          context.response.writePage(form);
        } else if (optionAddCall == 'true' || optionAddCall == true) {
          form = serverWidget.createForm({ title: "Matrix Item Option Selector" });
          if (matrixOptions.length > 0) {
            let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })

            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                log.debug("fieldVar type: " + typeof fieldVar, "fieldVar value: " + fieldVar);
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: field.sourceList }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                myField.defaultValue = (String(fieldVar)).split(",");

              }
            });
          }
          // form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Add Options');
          context.response.writePage(form);
        } else if (mrspecadd == 'true' || mrspecadd == true) {
          form = serverWidget.createForm({ title: "Add New Spec" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let addingSpec = form.addField({ id: 'custpage_spec_add', type: serverWidget.FieldType.CHECKBOX, label: 'Spec Add' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            addingSpec.defaultValue = 'T';


            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            formData.forEach(fields => {
              var fieldVar = itemRecord.getValue({ fieldId: fields.actualFieldId });
              if (fieldVar == '' && fields.actualFieldId != 'custitem_c60520_matrix_ext_main_color' && fields.actualFieldId != 'custitem_c60520_matrix_ext_sub_color' && fields.actualFieldId != 'custitem_c60520_matrix_int_main_color' && fields.actualFieldId != 'custitem_c60520_matrix_int_sub_color') {
                form.addField({ id: String(fields.formField).toLowerCase(), type: serverWidget.FieldType.CHECKBOX, label: String(fields.label), source: String(fields.sourceList) }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Add Selected Specs');
          context.response.writePage(form);
        }
      } catch (e) {
        log.error("ERROR", e);
        context.response.write("Something went wrong");
      }
    }

    function renderPageOnPost(context) {

      /*
      * Getting Date from Pro-rate Date field to create Payment record
      */

      let allParameters = context.request.parameters;
      let itemId = allParameters.custpage_intid;
      let specAdd = allParameters.custpage_spec_add;
      if (specAdd == 'T' || specAdd == 'true' || specAdd == true) {
        log.debug("allParameters", allParameters);
        callSpecAdd(itemId, context);
      } else {
        let requestType = allParameters.custpage_request_type;

        if (requestType == 'T' || requestType == 'true' || requestType == true) {
          callAddItem(itemId, context);
        } else {
          callAddOption(itemId, context);
        }
      }



    }

    function callAddItem(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });
          var createRecord = record.create({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM });
          createRecord.setValue({ fieldId: 'matrixtype', value: 'CHILD' });
          createRecord.setValue({ fieldId: 'parent', value: Number(itemId) });
          createRecord.setValue({ fieldId: 'itemid', value: 'Random Name' });
          createRecord.setValue({ fieldId: 'taxschedule', value: 1 });
          var brand = itemRecord.getValue({ fieldId: 'class' });
          createRecord.setValue({ fieldId: 'class', value: brand });
          var data = contextValues(context);

          for (var i = 0; i < data.length; i++) {
            var currentValue = data[i].suiteletField;
            if (currentValue) {
              log.debug("data[i].fieldId: " + data[i].fieldId, "currentValue.toString() : " + currentValue.toString());
              createRecord.setValue({ fieldId: data[i].fieldId, value: currentValue.toString() });
            }
          }

          var finalSubItemId = createRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
          log.debug("finalSubItemId", finalSubItemId);

          if (finalSubItemId) {
            for (var i = 0; i < data.length; i++) {
              var checkVal = itemRecord.getValue({ fieldId: data[i].actualFieldId });
              if (checkVal != data[i].values && data[i].values.length > 0) {
                itemRecord.setValue({ fieldId: data[i].actualFieldId, value: data[i].values });
                log.debug("Fields being set", data[i].actualFieldId + " " + data[i].values);
              }
            }
            log.debug("item record before save", itemRecord);
            itemRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
            //Renaming
            {
              /**
               * Header Level Data
               */
              log.debug("item record after save", itemRecord);
              var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });
              let subItem = itemRecord.getText({ fieldId: 'parent' }); //Variant
              let subItemId = itemRecord.getValue({ fieldId: 'internalid' });

              /**
               * Only Run If parent has no value
               */

              if (!subItem) {

                /**
                 * Search to Find Maximum Sequence
                 */

                let assemblyitemSearchObjVariant = search.create({
                  type: "assemblyitem",
                  filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                  columns: [search.createColumn({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" })]
                });
                let assemblyitemSearchObjVariantResult = assemblyitemSearchObjVariant.run().getRange({ start: 0, end: 1 });
                let maxSequenceVariant = assemblyitemSearchObjVariantResult[0].getValue({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" });
                log.debug("maxSequenceVariant", maxSequenceVariant);

                let assemblyitemSearchObjUnmodifiedVariant = search.create({
                  type: "assemblyitem",
                  filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                  columns: [search.createColumn({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" })]
                });
                let assemblyitemSearchObjUnmodifiedVariantResult = assemblyitemSearchObjUnmodifiedVariant.run().getRange({ start: 0, end: 1 });
                let maxSequenceUnmodifiedVariant = assemblyitemSearchObjUnmodifiedVariantResult[0].getValue({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" });
                log.debug("maxSequenceUnmodifiedVariant", maxSequenceUnmodifiedVariant);

                // log.debug("Item is Parent!");

                let itemIdText = itemRecord.getText({ fieldId: 'itemid' }); //Item Name/Number

                /**
                 * Getting Line Count & Loading Each Matrix Sub Item!
                 */

                let matrixSublistLineCount = itemRecord.getLineCount({ sublistId: 'matrixmach' });
                log.debug("matrixSublistLineCount", matrixSublistLineCount);
                if (matrixSublistLineCount > 0) {

                  /**
                   * Looping Over Matrix Sub Item Sublist
                   */

                  for (let iter = 0; iter < matrixSublistLineCount; iter++) {

                    /**
                     * Matrix SubTab Data
                     */

                    let matrixSubItemRecordId = Number(itemRecord.getSublistValue({ sublistId: 'matrixmach', fieldId: 'mtrxid', line: iter }));
                    log.debug("matrixSubItemRecordId: " + matrixSubItemRecordId, "iter: " + iter);
                    let matrixSubItemRecord = record.load({ type: 'serializedassemblyitem', id: matrixSubItemRecordId });

                    let steering = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_steering_list' }); //Steerling List 
                    let engineCapacity = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_engine_capacity' }); //Engine Capacity List 
                    let fuel = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_fuel' }); //Fuel List 
                    // log.debug("steering",steering);
                    // log.debug("engineCapacity",engineCapacity);
                    // log.debug("fuel",fuel);

                    /**
                     * Creating MODEL (BGK) 
                     */

                    let steeringAbv;
                    if (steering.length > 0) {
                      steeringAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_steering_list', id: Number(steering), columns: ['abbreviation'] })).abbreviation;
                    } else {
                      steeringAbv = "";
                    }

                    let engineCapacityAbv;
                    if (engineCapacity.length > 0) {
                      engineCapacityAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_eng_cap_list', id: Number(engineCapacity), columns: ['abbreviation'] })).abbreviation;
                    } else {
                      engineCapacityAbv = "";
                    }

                    let fuelAbv;
                    if (fuel.length > 0) {
                      fuelAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_fuel_list', id: Number(fuel), columns: ['abbreviation'] })).abbreviation;
                    } else {
                      fuelAbv = "";
                    }

                    let modelBGK = steeringAbv + itemIdText + engineCapacityAbv + fuelAbv;
                    log.debug("MODEL Name :", modelBGK);

                    /**
                     * If this name doesn't exit then create else set value of MODEL (BGK) Record
                     */

                    let setModelBGK;

                    let findModelBGK = runSuiteQuery("findModelBGK", "SELECT id FROM customrecord_c60520_model_bgk WHERE name = '" + modelBGK + "'");
                    if (findModelBGK.length > 0) {
                      setModelBGK = Number(findModelBGK[0]['id']);
                      matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_model_bgk', value: setModelBGK });
                      log.debug("MODEL ID From Query: " + setModelBGK);
                    } else {
                      let modelBGKRecord = record.create({ type: 'customrecord_c60520_model_bgk' });
                      modelBGKRecord.setValue({ fieldId: 'name', value: modelBGK });
                      setModelBGK = Number(modelBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true }));
                      matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_model_bgk', value: setModelBGK });
                      log.debug("MODEL ID Created: " + setModelBGK);
                    }

                    /**
                     * Getting Values
                     */

                    var data = fieldsArray();
                    for (let i = 0; i < data.length; i++) {
                      data[i].values = matrixSubItemRecord.getValue({ fieldId: data[i].actualFieldId });
                    }

                    /**
                     * Checking Whether Custom Record Variant BGK has "SAMPLE_1" OR NOT?
                     */

                    let findVariantBGK;
                    let setVariantBGK;

                    /**
                     * Creating & Setting Variant (BGK)
                     * For this we need all combinations except colors.
                     */

                    let itemVariantBGKCombinationSearch = itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, setModelBGK, data);

                    if (itemVariantBGKCombinationSearch.length <= 0) {
                      let variantAlreadySequenced = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_already_sequenced' });
                      log.debug("variantAlreadySequenced", variantAlreadySequenced);
                      if (!variantAlreadySequenced) {

                        /**
                         * Simply Set Create & Set Custom Record's ID on Item Record.
                         */

                        let variantBGKRecord = record.create({ type: 'customrecord_c60520_variant_bgk' });
                        findVariantBGK = modelBGK + "_" + (parseInt(itemVariantBGKCombinationSearch.length) + 1);
                        log.debug("First Variant: ", findVariantBGK);

                        let assemblyitemSearchObjVariantSequence = search.create({
                          type: "assemblyitem",
                          filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                          columns: [search.createColumn({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" })]
                        });
                        let searchResultCount = assemblyitemSearchObjVariantSequence.runPaged().count;
                        let assemblyitemSearchObjVariantSequenceResult = assemblyitemSearchObjVariantSequence.run().getRange({ start: 0, end: 1 });
                        log.debug("assemblyitemSearchObjVariantSequenceResult", assemblyitemSearchObjVariantSequenceResult);
                        let maxSequenceVariantNumber = assemblyitemSearchObjVariantSequenceResult[0].getValue({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" });
                        log.debug("maxSequenceVariant", maxSequenceVariant);

                        /**
                         * New Variant Will be.
                         */

                        if (searchResultCount > 0) {
                          if (!maxSequenceVariantNumber) {
                            maxSequenceVariantNumber = 1;
                          } else {
                            maxSequenceVariantNumber = parseInt(maxSequenceVariantNumber) + 1;
                          }

                          findVariantBGK = modelBGK + "_" + maxSequenceVariantNumber;
                          log.debug("Second Variant: " + findVariantBGK, "maxSequenceVariant Value Prior to Set: " + maxSequenceVariantNumber);
                          matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_variant_sequence', value: maxSequenceVariantNumber });

                        } else {
                          matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_variant_sequence', value: (parseInt(itemVariantBGKCombinationSearch.length) + 1) });
                        }

                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_already_sequenced', value: true });

                        variantBGKRecord.setValue({ fieldId: 'name', value: findVariantBGK });
                        setVariantBGK = variantBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_variant_bgk', value: Number(setVariantBGK) });
                        log.debug("VARIANT PREPARED: " + findVariantBGK, "VARINAT ID From Query: " + setVariantBGK);
                      } else {
                        findVariantBGK = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_variant_bgk" });
                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_already_sequenced', value: true });
                        log.debug("Getting findVariantBGK Value When True!", findVariantBGK);
                      }
                    } else {
                      setVariantBGK = (itemVariantBGKCombinationSearch[0].getValue({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }));
                      findVariantBGK = (itemVariantBGKCombinationSearch[0].getText({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }));
                      matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_variant_bgk', value: (setVariantBGK) });
                      log.debug("VARINAT (ID) From Query: " + setVariantBGK, "VARINAT TEXT) From Query: " + findVariantBGK);
                    }



                    /**
                     * Checking Whether Custom Record Unmodified Variant BGK has "SAMPLE_1" OR NOT?
                     */

                    let findUnmodifiedVariantBGK;
                    let setUnmodifiedVariantBGK;

                    /**
                    * Creating & Setting Unmodified Variant (BGK)
                    * For this we need all combinations except colors.
                    */

                    let itemUnmodifiedVariantBGKCombinationSearch = itemUnmodifiedVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, setModelBGK, data); //Sending Colors & Modifications As Null

                    if (itemUnmodifiedVariantBGKCombinationSearch.length <= 0) {
                      let unmodifiedVariantAlreadySequenced = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_unm_already_sequenced' });
                      log.debug("unmodifiedVariantAlreadySequenced", unmodifiedVariantAlreadySequenced);
                      if (!unmodifiedVariantAlreadySequenced) {

                        /**
                         * Simply Set Create & Set Custom Record's ID on Item Record.
                         */

                        let UnmodifiedVariantBGKRecord = record.create({ type: 'customrecord_c60520_variant_bgk' });
                        findUnmodifiedVariantBGK = modelBGK + "_" + (parseInt(itemUnmodifiedVariantBGKCombinationSearch.length) + 1);

                        log.debug("Second Unmodified Variant: ", findUnmodifiedVariantBGK);

                        let assemblyitemSearchObjUnmodifiedVariantSequence = search.create({
                          type: "assemblyitem",
                          filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                          columns: [search.createColumn({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" })]
                        });
                        var searchResultCount = assemblyitemSearchObjUnmodifiedVariantSequence.runPaged().count;
                        let assemblyitemSearchObjUnmodifiedVariantSequenceResult = assemblyitemSearchObjUnmodifiedVariantSequence.run().getRange({ start: 0, end: 1 });
                        log.debug("assemblyitemSearchObjUnmodifiedVariantSequenceResult", assemblyitemSearchObjUnmodifiedVariantSequenceResult);
                        let maxSequenceUnmodifiedVariantNumber = assemblyitemSearchObjUnmodifiedVariantSequenceResult[0].getValue({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" });
                        log.debug("maxSequenceUnmodifiedVariantNumber", maxSequenceUnmodifiedVariantNumber);

                        /**
                         * New Variant Will be.
                         */

                        if (searchResultCount > 0) {
                          if (!maxSequenceUnmodifiedVariantNumber) {
                            maxSequenceUnmodifiedVariantNumber = 1;
                          } else {
                            maxSequenceUnmodifiedVariantNumber = parseInt(maxSequenceUnmodifiedVariantNumber) + 1;
                          }

                          findUnmodifiedVariantBGK = modelBGK + "_" + maxSequenceUnmodifiedVariantNumber;
                          matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_variant_sequence', value: maxSequenceUnmodifiedVariantNumber });
                          log.debug("Second Unmodified Variant: " + findUnmodifiedVariantBGK, "maxSequenceUnmodifiedVariantNumber Value Prior to Set: " + maxSequenceUnmodifiedVariantNumber);
                        } else {
                          matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_variant_sequence', value: (parseInt(itemUnmodifiedVariantBGKCombinationSearch.length) + 1) });
                        }

                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_already_sequenced', value: true });

                        UnmodifiedVariantBGKRecord.setValue({ fieldId: 'name', value: findUnmodifiedVariantBGK });
                        setUnmodifiedVariantBGK = UnmodifiedVariantBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk', value: Number(setUnmodifiedVariantBGK) });
                        log.debug("UNMODIFIED VARIANT PREPARED: " + findUnmodifiedVariantBGK, "UNMODIFIED VARINAT ID From Query: " + setUnmodifiedVariantBGK);
                      }
                      else {
                        findUnmodifiedVariantBGK = matrixSubItemRecord.getText({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk' });
                        matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_already_sequenced', value: true });
                      }
                    } else {
                      setUnmodifiedVariantBGK = (itemUnmodifiedVariantBGKCombinationSearch[0].getValue({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Variant (BGK)" }));
                      findUnmodifiedVariantBGK = (itemUnmodifiedVariantBGKCombinationSearch[0].getText({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Variant (BGK)" }));
                      matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk', value: (setUnmodifiedVariantBGK) });
                      log.debug("UNMODIFIED VARINAT (ID) From Query: " + setUnmodifiedVariantBGK, "UNMODIFIED VARINAT (TEXT) From Query: " + findUnmodifiedVariantBGK);
                    }


                    /**
                     * Creating & Setting ITEM NAME/NUMBER, also setting MODEL (BGK)
                     * Calling Search For All Sub Matrix Items
                     */

                    /**
                     * Creating Prefix for ItemName/Number
                     */


                    let extMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                    let extSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                    let intMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_main_color" });
                    let intSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                    let extMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                    let extSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                    let intMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_main_color" });
                    let intSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                    let remainingPrefixForItemNameNumber = callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue);
                    log.debug("Item Name/Number : ", findVariantBGK + "-" + remainingPrefixForItemNameNumber);


                    matrixSubItemRecord.setValue({ fieldId: 'itemid', value: findVariantBGK + "-" + remainingPrefixForItemNameNumber });
                    matrixSubItemRecord.setValue({ fieldId: 'displayname', value: findVariantBGK + "-" + remainingPrefixForItemNameNumber });
                    log.debug("Before save;")

                    let finalSubItemId = matrixSubItemRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                    log.debug("finalSubItemId", finalSubItemId);

                  }
                }
              }
            }

            redirect.toRecord({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: finalSubItemId });
          } else {
            formObj.updateDefaultValues({ custpage_output_result: "Fatal Error Occoured while creating Sales Order." });
            context.response.writePage(formObj);
          }
        }
      } catch (e) {
        log.error("Error Inside addItem Function!", e);
        if (e.name == "DUP_ITEM_OPTION") {
          var failureForm = serverWidget.createForm({
            title: 'Failure!'
          });
          var successtext = 'Item with this combination already exists';
          var msg = failureForm.addField({
            id: 'custpage_html',
            type: 'inlinehtml',
            label: 'Process'
          });
          msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
          context.response.writePage({
            pageObject: failureForm
          });
        }
      }
    }

    function callSpecAdd(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

          var data = contextValues(context);
          var str = itemRecord.getValue({ fieldId: 'matrixitemnametemplate' });
          var specs = '';
          for (var i = 0; i < data.length; i++) {
            log.debug("data.actualFieldId: " + data[i].actualFieldId, "data.suiteletField: " + data[i].suiteletField);

            if (data[i].suiteletField == 'T' || data[i].suiteletField == 'true' || data[i].suiteletField == true) {
              str = String(str) + '{' + data[i].actualFieldId + '}';
              specs += data[i].actualFieldId + ',';
              itemRecord.setText({ fieldId: data[i].actualFieldId, text: ['-Undefined-'] });

            }

          }
          // itemRecord.setValue({ fieldId: 'matrixitemnametemplate', value: str });

          var mapScriptTask = task.create({ taskType: task.TaskType.MAP_REDUCE });
          mapScriptTask.scriptId = 'customscript_c60520_mr_add_specs';
          mapScriptTask.deploymentId = 'customdeploy_c60520_mr_add_specs';
          mapScriptTask.params = { 'custscript_parent_item_id': itemId, 'custscript_new_specs': specs };
          var scriptTaskId = mapScriptTask.submit();
          log.debug('DEBUG', 'scriptTaskId: ' + scriptTaskId);
          var saved = itemRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
          log.debug("Saved", "saved");
          if (saved) {
            var successForm = serverWidget.createForm({ title: 'Success!' });
            var successtext = 'Specs are being added, please close this page & refresh Variant Page after sometime!';
            var msg = successForm.addField({
              id: 'custpage_html',
              type: 'inlinehtml',
              label: 'Process'
            });
            msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
            context.response.writePage({
              pageObject: successForm
            });
          }

        }
      } catch (e) {
        log.error("Error Inside callSpecAdd Function!", e);
      }
    }

    function callAddOption(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

          var moreData = contextValues(context);
          log.debug("Moredata", moreData);
          for (var i = 0; i < moreData.length; i++) {
            var currentValue = moreData[i].suiteletField;
            if (currentValue && currentValue != '' && currentValue.length > 0) {
              log.debug("NAME: " + moreData[i].actualFieldId, "currentValue: " + currentValue);
              itemRecord.setValue({ fieldId: moreData[i].actualFieldId, value: currentValue.split("") });
            }
          }
          var finalSubItemId = itemRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });

          if (finalSubItemId) {
            redirect.toRecord({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: finalSubItemId });
          } else {
            formObj.updateDefaultValues({ custpage_output_result: "Fatal Error Occoured while creating Sales Order." });
            context.response.writePage(formObj);
          }
        }
      } catch (e) {
        log.error("Error Inside callAddOption Function!", [e.message, e.stack]);
      }
    }

    function getSelectedMatrixOptions(internalid) {
      try {
        data = fieldsArray();
        let searchFilters = [["type", "anyof", "Assembly"], "AND", ["internalid", "anyof", internalid]];
        let searchColumns = [search.createColumn({ name: "internalid", label: "Internal ID" })];
        var searhResults = searchAllRecord('assemblyitem', null, searchFilters, searchColumns);

        return searhResults;
      }
      catch (ErrorObj) {
        log.error('Error in getSelectedMatrixOptions', [ErrorObj.message, ErrorObj.stack])
      }
    }

    function itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, modelBGK, data) {
      log.debug("Inside itemVariantBGKCombinationCheck Function!");

      let allFilters =
        [
          ["type", "anyof", "Assembly"], "AND",
          ["matrix", "is", "F"], "AND",
          ["matrixchild", "is", "T"], "AND",
          ["internalid", "noneof", matrixSubItemRecordId]
          , "AND", ["custitem_c60520_already_sequenced", "is", 'T']

        ];

      //Pushing filters only when value for those filters is entered, else blank.
      // if (modelBGK) allFilters.push('AND', ["custitem_c60520_matrix_model_bgk", "anyof", modelBGK]);
      if (itemId) allFilters.push('AND', ["parent", "anyof", itemId]);
      for (let i = 0; i < data.length; i++) {
        //Skipping colors and mdifications since it was supposed to be sent as null
        if (data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
        //pushing filters for the rest
        if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
      }

      let allColumns =
        [
          search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
          search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
          search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
        ];
      let searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
      log.debug("searchData", searchData);
      return searchData;

    }

    function itemUnmodifiedVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, modelBGK, data) {
      log.debug("Inside itemUnmodifiedVariantBGKCombinationCheck Function!");

      let allFilters =
        [
          ["type", "anyof", "Assembly"], "AND",
          ["matrix", "is", "F"], "AND",
          ["matrixchild", "is", "T"], "AND",
          ["internalid", "noneof", matrixSubItemRecordId]
          , "AND", ["custitem_c60520_unm_already_sequenced", "is", 'T']

        ];

      //Pushing filters only when value for those filters is entered, else blank.

      // if (modelBGK) allFilters.push('AND', ["custitem_c60520_matrix_model_bgk", "anyof", modelBGK]);
      if (itemId) allFilters.push('AND', ["parent", "anyof", itemId]);
      for (let i = 0; i < data.length; i++) {
        //Skipping colors and mdifications since it was supposed to be sent as null
        if (data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
        //pushing filters for the rest
        if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
      }

      let allColumns =
        [
          search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
          search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
          search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
        ];
      let searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
      log.debug("searchData", searchData);
      return searchData;
    }

    function callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue) {
      log.debug("Inside callRemainingPrefixItemNameSearch Function!");
      let mainString = "";
      log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);
      log.debug("COLOR NAME DEBUG", "extMainColText: " + extMainColText + " | extSubColText: " + extSubColText + " | intMainColText: " + intMainColText + " | intSubColText: " + intSubColText);

      intMainColValue = Number(intMainColValue);
      intSubColValue = Number(intSubColValue);
      extMainColValue = Number(extMainColValue);
      extSubColValue = Number(extSubColValue);

      // log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);

      let intSubColTextTemp = String(intSubColText).toLowerCase();
      let intMainColTextTemp = String(intMainColText).toLowerCase();
      let extMainColTextTemp = String(extMainColText).toLowerCase();
      let extSubColTextTemp = String(extSubColText).toLowerCase();

      if ((extMainColTextTemp != '') && (extSubColTextTemp != '') && extMainColTextTemp != extSubColTextTemp) {
        mainString += extMainColText + "(" + extSubColText + ")";
      } else if (extMainColTextTemp != '') {
        mainString += extMainColText;
      } else if (extSubColTextTemp != '') {
        mainString += extSubColText;
      }

      if ((intMainColTextTemp != '') && (intSubColTextTemp != '') && intMainColTextTemp != intSubColTextTemp) {
        mainString += "/" + intMainColText + "(" + intSubColText + ")";
        flag = true;
      } else if (intMainColTextTemp != '') {
        mainString += "/" + intMainColText;
        flag = true;
      } else if (intSubColTextTemp != '') {
        mainString += "/" + intSubColText;
        flag = true;
      }
      return mainString;
    }

    function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
      try {
        var arrSearchResults = [];
        var count = 1000, min = 0, max = 1000;
        var searchObj = false;

        if (recordType == null) {
          recordType = null;
        }

        if (searchId) {
          searchObj = search.load({ id: searchId });
          if (searchFilter) {
            searchObj.addFilters(searchFilter);
          }
          if (searchColumns) {
            searchObj.addColumns(searchColumns);
          }
        }
        else {
          searchObj = search.create({ type: recordType, filters: searchFilter, columns: searchColumns })
        }

        var rs = searchObj.run();
        searchColumns.push(rs.columns);
        allColumns = rs.columns;

        while (count == 1000) {
          var resultSet = rs.getRange({ start: min, end: max });
          if (resultSet != null) {
            arrSearchResults = arrSearchResults.concat(resultSet);
            min = max;
            max += 1000;
            count = resultSet.length;
          }
        }
      }
      catch (e) {
        log.debug('Error searching for Assembly Item:- ', e.message);
      }
      return arrSearchResults;
    }

    function runSuiteQuery(queryName, queryString) {
      log.debug("Query String For : " + queryName + "->", queryString);
      let resultSet = query.runSuiteQL({ query: queryString });
      // log.debug("Query Mapped Data For : "+queryName+"->", resultSet.asMappedResults());
      if (resultSet && resultSet.results && resultSet.results.length > 0) {
        return resultSet.asMappedResults();
      } else {
        return [];
      }
    }

    return { onRequest }

  });
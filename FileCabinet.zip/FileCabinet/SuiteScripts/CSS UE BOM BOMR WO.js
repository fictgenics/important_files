/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE BOM BOMR WO.js
* DEVOPS TASK: 
* AUTHOR: Akash Sharma
* DATE CREATED: 24-April-2023
* DESCRIPTION: This script is for creating BOM<BOMR<WO.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 4-April-2023     CD/61276         Akash Sharma        Moved BOM & BOMR Creation Code after SKU Creation. 
************************************************************************************************/
define(['N/record', 'N/search', 'N/query', 'N/url', 'N/ui/serverWidget'], (record, search, query, url, serverWidget) => {
    /**
     * Defines the function definition that is executed before record is loaded.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @param {Form} scriptContext.form - Current form
     * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
     * @since 2015.2
     */
    const beforeLoad = (scriptContext) => {
        try {
            if (scriptContext.type == 'view') {
                let newRecord = scriptContext.newRecord;
                let itemLines = newRecord.getLineCount({ sublistId: 'item' });
                let form = scriptContext.form;
                var objSublist = form.getSublist({ id: 'item' });
                objSublist.getField({id: 'custcol_c60520_fr_woid'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});

                let formField = objSublist.addField({
                    id: 'custpage_workorderlink',
                    label: 'Work Order Hyperlink',
                    type: serverWidget.FieldType.TEXT
                });

                for (let i = 0; i < itemLines; i++) {
                    let woText = newRecord.getSublistText({ sublistId: 'item', fieldId: 'custcol_c60520_fr_woid', line: i });
                    let savedWOId = newRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_fr_woid', line: i });
                    if (woText && woText.length > 0) {
                        var scheme = 'https://';
                        var host = url.resolveDomain({ hostType: url.HostType.APPLICATION });
                        var recordUrl = url.resolveRecord({ recordType: 'workorder', recordId: savedWOId, isEditMode: false });
                        recordUrl = scheme + host + recordUrl;
                        let urlDisplay = `<a href = '${recordUrl}'>${woText}</a>`;
                        log.debug("urlDisplay", urlDisplay);
                        newRecord.setSublistValue({ sublistId: 'item', fieldId: 'custpage_workorderlink', line: i, value: urlDisplay });
                    }
                }
            }

        } catch (err) {
            log.error("Error in beforeload", err);
        }
    }

    /**
     * Defines the function definition that is executed before record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const beforeSubmit = (scriptContext) => {

    }

    /**
     * Defines the function definition that is executed after record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const afterSubmit = (scriptContext) => {

        if (scriptContext.type == scriptContext.UserEventType.CREATE) {
            try {
                /**
                 * If Fulfulment is Created, check lines & Create Work Order with BOM & It's Revision
                 */
                log.debug("Inside AFter Submit!");

                let frRecordId = Number(scriptContext.newRecord.id);

                /**
                 * Traverse over line & after creating set workorder after creating.
                 */

                let frRecord = record.load({ type: 'fulfillmentrequest', id: frRecordId });
                let frLineCount = frRecord.getLineCount({ sublistId: 'item' });

                for (let i = 0; i < frLineCount; i++) {
                    /**
                     * If Is work order true?
                     */

                    let isWO = frRecord.getSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_fr_is_work_order', line: i });
                    log.debug("Current Line wo value", isWO);
                    if (isWO == true || isWO == 'T' || isWO == 'true') {
                        /**
                         * This line will have a workorder, which we need to create & set the id on the current line back again.
                         */

                        let currentLineItem = Number(frRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i }));
                        let currentLineItemName = frRecord.getSublistText({ sublistId: 'item', fieldId: 'itemname', line: i });
                        let currentLineQuantity = Number(frRecord.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: i }));

                        let bomRecordId = runSuiteQuery("BOM Record ID", "select id from bom where name = '" + currentLineItemName + "'");
                        if (bomRecordId.length > 0) {
                            bomRecordId = bomRecordId[0]['id'];
                        } else {
                            bomRecordId = null;
                        }

                        let bomRevisionId = runSuiteQuery("BOM Record ID", "select id from bomrevision where name = '" + currentLineItemName + "'");
                        if (bomRevisionId.length > 0) {
                            bomRevisionId = bomRevisionId[0]['id'];
                        } else {
                            bomRevisionId = null;
                        }

                        /**
                         * Now Creating Work Order
                         */
                        let workOrderRecord = record.create({ type: record.Type.WORK_ORDER, isDynamic: true });
                        workOrderRecord.setValue({ fieldId: 'subsidiary', value: 1 });
                        workOrderRecord.setValue({ fieldId: 'assemblyitem', value: currentLineItem });
                        workOrderRecord.setValue({ fieldId: 'quantity', value: currentLineQuantity });
                        workOrderRecord.setValue({ fieldId: 'billofmaterials', value: bomRecordId });
                        workOrderRecord.setValue({ fieldId: 'billofmaterialsrevision', value: bomRevisionId });
                        workOrderRecord.setValue({ fieldId: 'orderstatus', value: 'A' }); //PLANNED

                        /**
                         * Setting Item's Line Level Data, like preferred vendor on all lines of Word Order
                         * Where Line Item is Inventory Type
                         */

                        /**
                         * Getting Item Array for all InvtPart Lines
                         */

                        let invItemArr = [];
                        let workorderLineCount = workOrderRecord.getLineCount({ sublistId: 'item' });
                        log.debug("workorderLineCount", workorderLineCount);
                        for (var y = 0; y < workorderLineCount; y++) {
                            let currentWOItemId = workOrderRecord.getSublistValue({ sublistId: 'item', fieldId: 'item', line: y });
                            let currentWOItemType = workOrderRecord.getSublistValue({ sublistId: 'item', fieldId: 'itemtype', line: y });

                            if (currentWOItemType == "InvtPart") {
                                invItemArr.push(Number(currentWOItemId));
                            }
                        }

                        log.debug("invItemArr", invItemArr);
                        if (invItemArr.length > 0) {
                            var inventoryitemSearchObj = search.create({
                                type: "inventoryitem",
                                filters:
                                    [
                                        ["type", "anyof", "InvtPart"],
                                        "AND",
                                        ["vendor", "noneof", "@NONE@"],
                                        "AND",
                                        ["internalid", "anyof", invItemArr]

                                    ],
                                columns:
                                    [
                                        search.createColumn({ name: "internalid", summary: "GROUP", label: "Internal ID" }),
                                        search.createColumn({ name: "vendor", summary: "GROUP", label: "Preferred Vendor" })
                                    ]
                            });
                            var preferredVendorResultCount = inventoryitemSearchObj.runPaged().count;
                            log.debug("inventoryitemSearchObj result count", preferredVendorResultCount);

                            var preferredVendorResult = inventoryitemSearchObj.run().getRange({ start: 0, end: 1000 });
                            log.debug("preferredVendorResult", preferredVendorResult);

                            if (preferredVendorResultCount > 0) {
                                /**
                                 * Now Since we have search data for preferred vendor, then we could traverse of each line on inv type on word order
                                 * and get & set data of preferred vendor on work order line from search output.
                                 */

                                for (var a = 0; a < workorderLineCount; a++) {
                                    workOrderRecord.selectLine({ sublistId: 'item', line: a })
                                    let currentWOItemId = workOrderRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'item' });
                                    let currentWOItemType = String(workOrderRecord.getCurrentSublistValue({ sublistId: 'item', fieldId: 'itemtype' }));
                                    log.debug("currentWOItemId : " + currentWOItemId, "currentWOItemType: " + currentWOItemType);

                                    /**
                                     * Looping on search data now.
                                     */

                                    for (var b = 0; b < preferredVendorResultCount; b++) {
                                        let preferredVendorItemId = preferredVendorResult[b].getValue({ name: "internalid", summary: "GROUP", label: "Internal ID" });
                                        let preferredVendorVendorId = preferredVendorResult[b].getValue({ name: "vendor", summary: "GROUP", label: "Preferred Vendor" });

                                        if ((Number(preferredVendorItemId) == Number(currentWOItemId)) && (currentWOItemType == 'InvtPart')) {
                                            log.debug("preferredVendorItemId : " + preferredVendorItemId, "preferredVendorVendorId: " + preferredVendorVendorId);
                                            workOrderRecord.setCurrentSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_wo_vendor', value: Number(preferredVendorVendorId) });
                                        }
                                    }
                                    workOrderRecord.commitLine({ sublistId: 'item' });
                                }
                            }
                        }
                        let woDisplayName = 'Work Order #' + workOrderRecord.getValue({ fieldId: 'tranid' });
                        let savedWOId = workOrderRecord.save();
                        log.debug("Work Order Record Created", savedWOId);

                        frRecord.setSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_fr_woid', line: i, value: savedWOId });
                        frRecord.setSublistValue({ sublistId: 'item', fieldId: 'custcol_c60520_fr_woid_link', line: i, value: "https://5676368-sb1.app.netsuite.com/app/accounting/transactions/workord.nl?id="+savedWOId });

                    }

                }

                let savedfrRecordId = frRecord.save();
                log.debug("Fulfillment Request Saved", savedfrRecordId);
            } catch (e) {
                log.error("Error Inside After Submit", [e.message, e.stack]);
            }
        }

    }

    function runSuiteQuery(queryName, queryString) {
        log.debug("Query String For : " + queryName + "->", queryString);
        var resultSet = query.runSuiteQL({ query: queryString });
        log.debug("Query Mapped Data For : " + queryName + "->", resultSet.asMappedResults());
        if (resultSet && resultSet.results && resultSet.results.length > 0) {
            return resultSet.asMappedResults();
        } else {
            return [];
        }
    }

    return { beforeLoad, beforeSubmit, afterSubmit }

});
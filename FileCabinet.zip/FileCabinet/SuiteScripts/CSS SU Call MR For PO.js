/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Call MR For PO.js
* DEVOPS TASK: DT/60531
* AUTHOR: Akash Sharma
* DATE CREATED: 23-April-2023
* DESCRIPTION: This script is for calling Map Reduce for PO generation.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/task'],(task) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            try {
                log.debug("Inside Map Reduce Function Instance Call");
                
                
                let scriptId = 'customscript_c60520_mr_create_po_from_wo';
                let deploymentId = 'customdeploy_c60520_mr_create_po_from_wo';
                let workOrderId = scriptContext.request.parameters.woid;
            
                let mrTask = task.create({taskType: task.TaskType.MAP_REDUCE, scriptId: scriptId, deploymentId: deploymentId, params:{'custscript_c60520_workorder_id': workOrderId}});
            
                let taskId = mrTask.submit();
                log.debug("MR Task id:",taskId);

                let taskStatus = task.checkStatus(taskId);
  
                if(taskStatus.status == 'FAILED') {
                    log.debug("Task failed to Submit");
                }
          
            } catch(err) {
                log.error("Error in Submitting MR:", [err.message, err.stack]);
                return false;
            }

        }

        return {onRequest}

    });

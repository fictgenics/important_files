/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED:
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/search', 'N/record'], function (search, record) {


    function afterSubmit(context) {
        try {
            if (context.type == 'create') {
                var recObj = context.newRecord;
                var poId = recObj.getValue({ fieldId: 'createdfrom' });
                var inbId = recObj.getValue({ fieldId: 'inboundshipment' });
                log.debug("poId", poId);
                log.debug("inbId", inbId);

                var irObj = record.load({
                    type: 'itemreceipt',
                    id: recObj.id,
                    isDynamic: true
                });

                var shipmentId = irObj.getValue({ fieldId: 'inboundshipment' });
                log.debug("shipmentId", shipmentId);

                
                if (poId && shipmentId) {
                    var customrecord_c59306_purchase_milestoneSearchObj = search.create({
                        type: "customrecord_c59306_purchase_milestone",
                        filters:
                            [
                                ["custrecord_c59306_purchase_order", "anyof", poId],
                                "AND",
                                ["custrecord_c59306_inbound_shipment", "anyof", shipmentId]
                            ],
                        columns:
                            [
                                search.createColumn({ name: "internalid", label: "Internal ID" })
                            ]
                    });
                    var searchResultCount = customrecord_c59306_purchase_milestoneSearchObj.runPaged().count;
                    log.debug("customrecord_c59306_purchase_milestoneSearchObj result count", searchResultCount);
                    // This search is not having more than 4 result
                    customrecord_c59306_purchase_milestoneSearchObj.run().each(function (result) {
                        var milestoneId = result.getValue({ name: "internalid", label: "Internal ID" });
                        record.submitFields({
                            type: 'customrecord_c59306_purchase_milestone',
                            id: milestoneId,
                            values: {
                                custrecord_c59306_item_receipt: recObj.id
                            },
                            options: {
                                enableSourcing: true,
                                ignoreMandatoryFields: true
                            }
                        });
                        return true;
                    });
                }
            }
        }
        catch (e) { log.error('Error', e) }
    }


    return {
        afterSubmit: afterSubmit
    };
});
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
define(['N/ui/serverWidget','N/record'],
    /**
 * @param{serverWidget} serverWidget
 */
    (serverWidget, record) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            let form = serverWidget.createForm({
                title: "Vendor Details",
                hideNavBar: false
            })
            form.addFieldGroup({
                id: "primary",
                label: "Primary Information",
            })
            form.addField({
                id: "name",
                label: "Name",
                type: serverWidget.FieldType.TEXT,
                // source: "primary",
                container: "primary"
            }).isMandatory = true
            form.addField({
                id: "phone",
                label: "Phone",
                type: serverWidget.FieldType.PHONE,
                // source: "primary",
                container: "primary" 
            }).isMandatory = true
            form.addField({
                id: "email",
                label: "Email",
                type: serverWidget.FieldType.EMAIL,
                // source: "primary",
                container: "primary" 
            }).isMandatory = true
            form.addField({
                id: "company",
                label: "Company Name",
                type: serverWidget.FieldType.TEXT,
                // source: "primary",
                container: "primary" 
            }).isMandatory = true

            form.addFieldGroup({
                id: "classification",
                label: "Classification",
            })

            form.addField({
                id: "subsidiary",
                label: "Subsidiary",
                type: serverWidget.FieldType.SELECT,
                source: "subsidiary",
                container: "classification" 
            }).isMandatory = true

            var custRec = record.create({ type: record.Type.CUSTOMER, isDynamic: true });
            var custSubrec = custRec.getCurrentSublistSubrecord({ sublistId: 'addressbook', fieldId: 'addressbookaddress' });
            var countryFieldObj = custSubrec.getField({ fieldId: 'country' });
            var countryList = countryFieldObj.getSelectOptions();
            
            var country = form.addField({
                id: "custpage_country",
                label: "Country",
                type: serverWidget.FieldType.SELECT,
                source: [],
                container: "classification" 
            });
           log.debug("country", country);
            countryList.forEach(function(option) {
                country.addSelectOption({
                    value: option.value,
                    text: option.text,
                    isSelected: false
                });
            });
            form.addField({
                id: "address",
                label: "Address",
                type: serverWidget.FieldType.TEXT,
                // source: "primary",
                container: "classification" 
            }).isMandatory = true

            form.addSubmitButton({
                label: "Submit" //can i change position of it.
            })

            form.addResetButton({
                label: "Reset"
            })

            scriptContext.response.writePage({
                pageObject: form
            })
        }

        return {onRequest}

    });
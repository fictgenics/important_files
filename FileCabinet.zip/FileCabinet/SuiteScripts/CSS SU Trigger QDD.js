/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Trigger QDD.js
* DEVOPS TASK: 
* AUTHOR: Akash Sharma
* DATE CREATED: 
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/record', 'N/task', 'N/ui/serverWidget'], (record, task, serverWidget) => {
	const onRequest = (scriptContext) => {

		if (scriptContext.request.method == 'GET') {
			try {
				// let reqParam = scriptContext.request.parameters;
				// let recordId = reqParam.qualityDataArr.split(",");
				// log.debug("recordId", recordId);

				// for (let i = 0; i < recordId.length; i++) {
				// 	let qualityDataRecord = record.load({ type: 'customrecord_qm_quality_data', id: recordId[i] });
				// 	let savedQualityDataRecord = qualityDataRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
				// 	log.debug("Index is: " + i, "savedQualityDataRecord: " + savedQualityDataRecord);
				// }

				/**
				 * Old Code above
				 */

				let reqParam = scriptContext.request.parameters;
				let recordId = reqParam.qualityDataArr;
				log.debug("recordId", recordId);
				let qualityDataRecord = record.load({ type: 'customrecord_qm_quality_data', id: recordId.split(",")[0] });
				var item = qualityDataRecord.getValue({ fieldId: 'custrecord_qm_quality_data_item' });
				log.debug("item", item);

				let createQDD = task.create({ taskType: task.TaskType.SCHEDULED_SCRIPT, scriptId: 'customscript_css_ss_create_qdd', deploymentId: 'customdeploy_css_ss_create_qdd', params: {} });
				createQDD.params = { 'custscript_qdd_item': item, 'custscript_recordid': recordId };
				let scriptTaskId = createQDD.submit();

				if(scriptTaskId){
					var successForm  = serverWidget.createForm({title: 'Success!'});
					var successtext = 'Quality Check for this is being added, please close this page & refresh Quality Tablet\'s page after sometime!';
					var msg = successForm.addField({
						id: 'custpage_html',
						type: 'inlinehtml', 
						label: 'Process'
					});
					msg.defaultValue ='<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">'+successtext +'</td></tr></table>';	
					scriptContext.response.writePage({
						pageObject: successForm
					});
				}
			}
			catch (error) {
				log.error({ title: 'Error', details: error });
			}
		}
	}
	return { onRequest }

});




/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
 *
 * FILE NAME:CS_SU_Release_Inventory.js
 * DEVOPS TASK:ENH/, BL/72172
 * AUTHOR: Shalini Srivastava
 * DATE CREATED: 4 March,2024
 * DESCRIPTION: 
 * REVISION HISTORY
 * Date          DevOps item No.    By                      Issue Fix Summary   
 *============================================================================                  
 *****************************************************************************/
define(['N/record','N/url'],(record,url) => {
	const onRequest = (context) => {
		try {
			var recordId  = context.request.parameters.recordId;
			log.debug('DEBUG','recordId: '+recordId);
			if(recordId) {
				var recObj = record.load({
					type: record.Type.SALES_ORDER,
					id: recordId,
					isDynamic: true,
			   });
			   var lineCount = recObj.getLineCount({sublistId: 'item'});
				if(lineCount>0){
					for(var iter=0; iter<lineCount; iter++){
						var quantityPicked = recObj.getSublistValue({sublistId: 'item',fieldId: 'quantitypicked',line:iter});
						var quantityPacked = recObj.getSublistValue({sublistId: 'item',fieldId: 'quantitypacked',line:iter});
						var quantityFulfilled = recObj.getSublistValue({sublistId: 'item',fieldId: 'quantityfulfilled',line:iter});
						var inventoryDetail = recObj.getSublistValue({sublistId: 'item',fieldId: 'inventorydetail',line:iter});
						log.debug('DEBUG','quantityPicked: '+quantityPicked+'==='+'quantityPacked: '+quantityPacked+'==='+'quantityFulfilled: '+quantityFulfilled+'==='+'inventoryDetail: '+inventoryDetail);
						if(!isNotNull(quantityPicked) && !isNotNull(quantityPacked) && !isNotNull(quantityFulfilled) && isNotNull(inventoryDetail)){
							log.debug('enter');
							record.delete({
								type: record.Type.INVENTORY_DETAIL,
								id: inventoryDetail
							})
						}
					}
				}
			}
		} catch(err) {
			log.error("Error in Submitting MR:", [err.message, err.stack]);
			return false;
		}
	}
	function isNotNull(aVal)
	{
		if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
			return true;
		else
			return false;
	}
	return {onRequest}
});
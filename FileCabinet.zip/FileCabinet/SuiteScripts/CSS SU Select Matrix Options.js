/**
* @NApiVersion 2.1
* @NScriptType Suitelet
*/

/*******************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Create Item.js
* DEVOPS TASK: 
* AUTHOR: Akash Sharma
* DATE CREATED: 29-May-2023
* DESCRIPTION: Suitelet to Create Matrix SubItem
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/

define(['N/ui/serverWidget', 'N/format', 'N/search', 'N/record', 'N/url', 'N/redirect', './Matrix Items.lib.js'],

  (serverWidget, format, search, record, url, redirect, mat) => {
    /*
    * Form Label
    * Pagination Page Size
    */
    const FORM_LABEL = "";

    /**
    * Defines the Suitelet script trigger point.
    * @param {Object} scriptContext
    * @param {ServerRequest} scriptContext.request - Incoming request
    * @param {ServerResponse} scriptContext.response - Suitelet response
    * @since 2015.2
    */
    const onRequest = (scriptContext) => {

      if (scriptContext.request.method == 'GET') {
        renderPageOnGet(scriptContext);
      } else {
        renderPageOnPost(scriptContext);
      }
    }

    function buildSourceList(selectedValues, selectedText, fieldVal) {
      // Create an array of objects containing both value and text
      var combinedArray = selectedValues.map((value, index) => ({ value, text: selectedText[index] }));

      // Sort the array of objects based on the 'value' property
      combinedArray.sort((a, b) => a.value - b.value);

      // Extract the sorted values and texts back into separate arrays
      sortedValues = combinedArray.map(item => item.value);
      sortedText = combinedArray.map(item => item.text);

      // log.debug("sortedValues", sortedValues);
      // log.debug("sortedText", sortedText);

      for (var x = 0; x < selectedValues.length; x++) {
        fieldVal.addSelectOption({
          value: selectedValues[x],
          text: selectedText[x]
        });
      }
      fieldVal.isMandatory = true;
    }

    function buildSourceListDefault(selectedValues, selectedText, fieldVal, selections) {
      // Create an array of objects containing both value and text
      var combinedArray = selectedValues.map((value, index) => ({ value, text: selectedText[index] }));

      // Sort the array of objects based on the 'value' property
      combinedArray.sort((a, b) => a.value - b.value);

      // Extract the sorted values and texts back into separate arrays
      sortedValues = combinedArray.map(item => item.value);
      sortedText = combinedArray.map(item => item.text);

      // log.debug("sortedValues", sortedValues);
      // log.debug("sortedText", sortedText);

      for (var x = 0; x < selectedValues.length; x++) {
        fieldVal.addSelectOption({
          value: selectedValues[x],
          text: selectedText[x]
        });
      }

      fieldVal.defaultValue = selections;
      fieldVal.isMandatory = true;
    }
    /**
    * Creating Suitelet
    * 
    * @param {scriptContext} context 
    */
    function renderPageOnGet(context) {

      try {

        /*
        * Getting Parameters from the URL of the Suitelet
        */
        let parameters = context.request.parameters;
        let matrixItemRecordId = parameters.mrecid || "";
        let recordFromSuitelet = parameters.mrecsl || "";
        let itemAddCall = parameters.itemadd || "";
        let optionAddCall = parameters.optionadd || "";
        let mrspecadd = parameters.mrspecadd || "";
        let duplicateAdd = parameters.dupadd || "";
        let subRecordId = parameters.msrecid || "";

        // log.debug("parameters -->", parameters);

        // log.debug("PARAMETERS on GET:", parameters + "| matrixItemRecordId:" + matrixItemRecordId + "| recordFromSuitelet:" + recordFromSuitelet);

        /*
        * Creating Suitelet Form
        */
        let form;
        let matrixOptions = getSelectedMatrixOptions(matrixItemRecordId);
        var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: matrixItemRecordId });
        var itemSubRecord;

        var data = fieldsArray();
        var formData = contextValues(context);

        if (itemAddCall == 'true' || itemAddCall == true) {
          form = serverWidget.createForm({ title: "Create SubMatrix Item" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            requestType.defaultValue = 'T';


            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }


            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              // log.debug("Is it working fine? ", fieldVar);
              var fieldText = itemRecord.getText({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                var valueSplit = fieldVar;
                var textSplit = fieldText;
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: [] }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                buildSourceList(valueSplit, textSplit, myField);
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Create Item');
          context.response.writePage(form);
        } else if (duplicateAdd == 'true' || duplicateAdd == true) {
          itemSubRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: subRecordId });

          form = serverWidget.createForm({ title: "Duplicate SubMatrix Item" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            requestType.defaultValue = 'T';

            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              var fieldText = itemRecord.getText({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                let smy = itemSubRecord.getValue({ fieldId: field.actualFieldId });
                var valueSplit = fieldVar;
                var textSplit = fieldText;
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: [] }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                buildSourceListDefault(valueSplit, textSplit, myField, smy);
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Create Item');
          context.response.writePage(form);
        } else if (optionAddCall == 'true' || optionAddCall == true) {
          form = serverWidget.createForm({ title: "Matrix Item Option Selector" });
          if (matrixOptions.length > 0) {
            let requestType = form.addField({ id: 'custpage_request_type', type: serverWidget.FieldType.CHECKBOX, label: 'Request Type' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })

            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            data.forEach(field => {
              var fieldVar = itemRecord.getValue({ fieldId: field.actualFieldId });
              if (fieldVar && fieldVar != '') {
                log.debug("fieldVar type: " + typeof fieldVar, "fieldVar value: " + fieldVar);
                let myField = form.addField({ id: 'custpage_' + String(field.variable).toLowerCase(), type: serverWidget.FieldType.MULTISELECT, label: String(field.label), source: field.sourceList }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
                myField.defaultValue = (String(fieldVar)).split(",");

              }
            });
          }
          // form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Add Options');
          context.response.writePage(form);
        } else if (mrspecadd == 'true' || mrspecadd == true) {
          form = serverWidget.createForm({ title: "Add New Spec" });
          // let ready = form.addField({ id: 'custpage_ready', type: serverWidget.FieldType.CHECKBOX, label: 'Ready' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY })
          // ready.isMandatory = true;

          let addingSpec = form.addField({ id: 'custpage_spec_add', type: serverWidget.FieldType.CHECKBOX, label: 'Spec Add' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN })
          if (matrixOptions.length > 0) {
            addingSpec.defaultValue = 'T';


            let intId = matrixOptions[0].getValue({ name: "internalid", label: "Internal ID" });
            if (intId) {
              let intIdField = form.addField({ id: 'custpage_intid', type: serverWidget.FieldType.TEXT, label: 'Internal ID' }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.HIDDEN });
              intIdField.defaultValue = intId;
            }

            formData.forEach(fields => {
              var fieldVar = itemRecord.getValue({ fieldId: fields.actualFieldId });
              if (fieldVar == '' && fields.actualFieldId != 'custitem_c60520_matrix_ext_main_color' && fields.actualFieldId != 'custitem_c60520_matrix_ext_sub_color' && fields.actualFieldId != 'custitem_c60520_matrix_int_main_color' && fields.actualFieldId != 'custitem_c60520_matrix_int_sub_color') {
                // log.debug("DEBUG", "String(fields.formField): " + String(fields.formField).toLowerCase() + " || String(fields.label): " + String(fields.label) + " || String(fields.sourceList): " + String(fields.sourceList));
                form.addField({ id: String(fields.formField).toLowerCase(), type: serverWidget.FieldType.CHECKBOX, label: String(fields.label), source: String(fields.sourceList) }).updateDisplayType({ displayType: serverWidget.FieldDisplayType.ENTRY });
              }
            });
          }
          form.clientScriptModulePath = './CSS CS Submtarix Item.js';
          form.addSubmitButton('Add Selected Specs');
          context.response.writePage(form);
        }
      } catch (e) {
        log.error("ERROR", e);
        context.response.write("Something went wrong");
      }
    }

    function renderPageOnPost(context) {

      /*
      * Getting Date from Pro-rate Date field to create Payment record
      */
      // log.debug("POST PARAMS", context.request.parameters);

      let allParameters = context.request.parameters;
      let itemId = allParameters.custpage_intid;
      let specAdd = allParameters.custpage_spec_add;
      if (specAdd == 'T' || specAdd == 'true' || specAdd == true) {
        log.debug("allParameters",allParameters);
        callSpecAdd(itemId, context);
      } else {
        let requestType = allParameters.custpage_request_type;

        if (requestType == 'T' || requestType == 'true' || requestType == true) {
          callAddItem(itemId, context);
        } else {
          callAddOption(itemId, context);
        }
      }



    }

    function callAddItem(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });
          var createRecord = record.create({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM });
          createRecord.setValue({ fieldId: 'matrixtype', value: 'CHILD' });
          createRecord.setValue({ fieldId: 'parent', value: Number(itemId) });
          createRecord.setValue({ fieldId: 'itemid', value: 'Random Name' });
          createRecord.setValue({ fieldId: 'taxschedule', value: 1 });

          var data = contextValues(context);

          for (var i = 0; i < data.length; i++) {
            // data[i].values = itemRecord.getValue({ fieldId: data[i].actualFieldId });

            var currentValue = data[i].suiteletField;
            if (currentValue) {
              log.debug("data[i].fieldId: " + data[i].fieldId, "currentValue.toString() : " + currentValue.toString());
              createRecord.setValue({ fieldId: data[i].fieldId, value: currentValue.toString() });
            }
          }

          var finalSubItemId = createRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
          log.debug("finalSubItemId", finalSubItemId);

          if (finalSubItemId) {
            for (var i = 0; i < data.length; i++) {
              var checkVal = itemRecord.getValue({ fieldId: data[i].actualFieldId });
              if (checkVal != data[i].values && data[i].values.length > 0) {
                itemRecord.setValue({ fieldId: data[i].actualFieldId, value: data[i].values });
                log.debug("Fields being set", data[i].actualFieldId + " " + data[i].values);
              }
            }
            redirect.toRecord({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: finalSubItemId });
          } else {
            formObj.updateDefaultValues({ custpage_output_result: "Fatal Error Occoured while creating Sales Order." });
            context.response.writePage(formObj);
          }
        }
      } catch (e) {
        log.error("Error Inside addItem Function!", e);
        if (e.name == "DUP_ITEM_OPTION") {
          var failureForm = serverWidget.createForm({
            title: 'Failure!'
          });
          var successtext = 'Item with this combination already exists';
          var msg = failureForm.addField({
            id: 'custpage_html',
            type: 'inlinehtml',
            label: 'Process'
          });
          msg.defaultValue = '<table><tr><td style="text-align:center;font-family:Arial;font-weight:Bold; font-size:14px;" colspan="2">' + successtext + '</td></tr></table>';
          context.response.writePage({
            pageObject: failureForm
          });
        }
      }
    }

    function callSpecAdd(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

          var data = contextValues(context);
          var str = itemRecord.getValue({ fieldId: 'matrixitemnametemplate' });
          for (var i = 0; i < data.length; i++) {
            log.debug("data.actualFieldId: "+data[i].actualFieldId, "data.suiteletField: "+data[i].suiteletField);

            if (data[i].suiteletField == 'T' || data[i].suiteletField == 'true' || data[i].suiteletField == true) {
              str = String(str) + '{' + data[i].actualFieldId + '}';
            }

          }
          itemRecord.setValue({ fieldId: 'matrixitemnametemplate', value: str });
          itemRecord.setValue({ fieldId: 'custitem_c60520_matrix_drive_train', value: 3 });
          itemRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
          log.debug("Saved", "saved");
        }
      } catch (e) {
        log.error("Error Inside addItem Function!", e);
      }
    }

    function callAddOption(itemId, context) {
      try {
        if (itemId) {
          var itemRecord = record.load({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: itemId });

          var data = fieldsArray();
          var moreData = contextValues(context);
          log.debug("Moredata", moreData);
          for (var i = 0; i < data.length; i++) {
            var currentValue = moreData[i].suiteletField;
            if (currentValue && currentValue != '') {
              log.debug("NAME: " + data[i].actualFieldId, "currentValue: " + currentValue);
              itemRecord.setValue({ fieldId: data[i].actualFieldId, value: currentValue.split("") });
            }
          }
          var finalSubItemId = itemRecord.save({ enableSourcing: false, ignoreMandatoryFields: true });
          // log.debug("finalSubItemId", finalSubItemId);

          if (finalSubItemId) {
            redirect.toRecord({ type: record.Type.SERIALIZED_ASSEMBLY_ITEM, id: finalSubItemId });
          } else {
            formObj.updateDefaultValues({ custpage_output_result: "Fatal Error Occoured while creating Sales Order." });
            context.response.writePage(formObj);
          }
        }
      } catch (e) {
        log.error("Error Inside addItem Function!", [e.message, e.stack]);
      }
    }

    function getSelectedMatrixOptions(internalid) {
      try {
        // log.debug("Parameters Value Inside Searh Function-->", internalid);
        data = fieldsArray();
        let searchFilters = [["type", "anyof", "Assembly"], "AND", ["internalid", "anyof", internalid]];
        let searchColumns = [search.createColumn({ name: "internalid", label: "Internal ID" })];
        var searhResults = searchAllRecord('assemblyitem', null, searchFilters, searchColumns);
        // log.debug('searhResults', searhResults);

        return searhResults;
      }
      catch (ErrorObj) {
        log.error('Error in getSelectedMatrixOptions', [ErrorObj.message, ErrorObj.stack])
      }
    }

    function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
      try {
        var arrSearchResults = [];
        var count = 1000, min = 0, max = 1000;
        var searchObj = false;

        if (recordType == null) {
          recordType = null;
        }

        if (searchId) {
          searchObj = search.load({ id: searchId });
          if (searchFilter) {
            searchObj.addFilters(searchFilter);
          }
          if (searchColumns) {
            searchObj.addColumns(searchColumns);
          }
        }
        else {
          searchObj = search.create({ type: recordType, filters: searchFilter, columns: searchColumns })
        }

        var rs = searchObj.run();
        searchColumns.push(rs.columns);
        allColumns = rs.columns;

        while (count == 1000) {
          var resultSet = rs.getRange({ start: min, end: max });
          if (resultSet != null) {
            arrSearchResults = arrSearchResults.concat(resultSet);
            min = max;
            max += 1000;
            count = resultSet.length;
          }
        }
      }
      catch (e) {
        log.debug('Error searching for Customer:- ', e.message);
      }
      return arrSearchResults;
    }

    return { onRequest }

  });
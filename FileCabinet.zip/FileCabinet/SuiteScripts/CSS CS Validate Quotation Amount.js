/**
* @NApiVersion 2.x
* @NScriptType ClientScript
* @NModuleScope SameAccount
*/

/*******************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Validate Quotation Amount.js
* DEVOPS TASK: BL/59546
* AUTHOR: Akash Sharma
* DATE CREATED: 9-March-2023
* DESCRIPTION: FOR stopping user to save Quotation  when 
* Maximum Open Order balance > (unbilled amount  on customer + quotation total) 
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/

define(['N/search'],function(search) {
  
  /**
  * Function to be executed after page is initialized.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
  *
  * @since 2015.2
  */
  function pageInit(scriptContext) {
    log.debug("Inside page init function");    
  }
  
  
  /**
  * Onclick save
  */
  function saveRecord(scriptContext){
    var currentRecord = scriptContext.currentRecord;
    var customerId = Number(currentRecord.getValue({fieldId: 'entity'}));
        if (customerId) {
            var fieldLookup = search.lookupFields({
                type: search.Type.CUSTOMER,
                id: customerId,
                columns: ['unbilledorders','custentity_c57685_max_open_order_bal']
            });

            var unbilledAmount = fieldLookup.unbilledorders;
            log.debug("unbilledAmount", unbilledAmount);

            var maxOpenOrderBal = fieldLookup.custentity_c57685_max_open_order_bal;
            log.debug("maxOpenOrderBal", maxOpenOrderBal);

            var quotationTotal = currentRecord.getValue({fieldId: 'total'});
            log.debug("quotationTotal", quotationTotal);

            if (quotationTotal && maxOpenOrderBal && ((Number(unbilledAmount) + Number(maxOpenOrderBal)) < Number(quotationTotal))) {
                alert("Quotation Amount exceeded the sum of Unbilled Amount & Maximum Open Order Balance!");
                return false;
            }
        }
    return true;
  }  
  
  return {
    pageInit: pageInit,
    saveRecord: saveRecord
  };
  
});

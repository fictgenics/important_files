/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE WO Release.js
* DEVOPS TASK: DT/60528
* AUTHOR: Akash Sharma
* DATE CREATED: 24-April-2023
* DESCRIPTION: This script is for calling MR which will mark all the workorder's orderstatus as release when FR is Marked In Progress From Line Level.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/task'],(task) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {

        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {

            if(scriptContext.type == scriptContext.UserEventType.EDIT){
                /**
                 * If Fulfulment is "Marked in Progress", then Call MR Script.
                 */
                log.debug("Inside AFter Submit!");

                var newRecord = scriptContext.newRecord;
                var oldRecord = scriptContext.oldRecord;
                
                var newStatus = newRecord.getValue({fieldId: 'transtatus'});
                var oldStatus = oldRecord.getValue({fieldId: 'transtatus'});
                log.debug("newStatus",newStatus);
                log.debug("oldStatus",oldStatus);
                // Only run the code if the status has been changed
                if (newStatus != oldStatus) {            
                    log.debug("Status Changed!");

                    // Check if the new status is "In Progress"
                    if (newStatus == 'B') { log.debug("if (newStatus == 'In Progress')");
                        // Call MR Script after traversing  every line of FR

                        let frLineCount = newRecord.getLineCount({sublistId: 'item'});
                        let workOrderArr = [];
                        if(frLineCount > 0){
                            for(let i = 0; i < frLineCount; i++){
                                let workOrderId = newRecord.getSublistValue({sublistId: 'item', fieldId: 'custcol_c60520_fr_woid', line: i});
                                if(workOrderId){
                                    workOrderArr.push(workOrderId);
                                }
                            }

                        }

                        log.debug("workOrderArr", workOrderArr);
                        //Now Call MR
                        if(workOrderArr.length > 0){
                            let workOrderString = workOrderArr.join(",");
                            log.debug("Inside MR Call");
                            let updateEmpTask=task.create({
                                taskType:task.TaskType.MAP_REDUCE,
                                scriptId:'customscript_c60520_mr_wo_release',
                                deploymentId:'customdeploy_c60520_mr_wo_release',
                                params:{
                                    'custscript_c60520_woid_string':workOrderString
                                }
                            });
                            updateEmpTask.submit();
                        }
                    }
                }
            }            

        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });

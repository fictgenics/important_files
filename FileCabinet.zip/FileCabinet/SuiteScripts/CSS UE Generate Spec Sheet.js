/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
define(['N/search'],(search) => {
    const beforeLoad = (scriptContext) => {
        try{
            scriptContext.form.clientScriptModulePath = "./CSS CS Generate Spec Sheet.js"; 
            let newRec = scriptContext.newRecord;
            let newRecid = newRec.id
            if (scriptContext.type === scriptContext.UserEventType.VIEW) {
                scriptContext.form.addButton({id : "custpage_gen_spec_sheet",label : "Generate Spec Sheet",functionName : 'generateSpecSheet(' + newRecid + ')'});
                                                   
            }
        }catch(e){
            log.error("Error inside before load", [e.message,e.stack]);
        }
    }
    return {beforeLoad}
});
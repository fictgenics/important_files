/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Work Order Approval.js
* DEVOPS TASK: DT/60530
* AUTHOR: Akash Sharma
* DATE CREATED: 23-April-2023
* DESCRIPTION: This script is for adding button to Work Order for Approval Process in view mode.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/runtime', 'N/record'],function(runtime, record){
    const beforeLoad = (scriptContext) => {
        try{
            if (scriptContext.type === scriptContext.UserEventType.VIEW) {

                /**
                 * Only Show on Released Status
                 */

                let newRec = scriptContext.newRecord;
                let currentUserId = Number(runtime.getCurrentUser().id);

                let workOrderRecord = record.load({type: 'workorder', id: Number(newRec.id)})
                let orderStatus = workOrderRecord.getValue({fieldId: 'status'});
                let approvalStatus = workOrderRecord.getValue({fieldId: 'custbody_c60520_wo_app_status'});
                let approverIdSetted = workOrderRecord.getValue({fieldId: 'custbody_c60520_wo_approver'});
                scriptContext.form.clientScriptModulePath = "./CSS CS Work Order Approval.js"; 

                log.debug("DEBUG START", "currentUserId: "+currentUserId+" | orderStatus: "+orderStatus+" | approvalStatus: "+approvalStatus+" | approverIdSetted: "+approverIdSetted);
                if(orderStatus == 'Released'){
                    if(!approvalStatus){
                        log.debug("When approvalStatus is empty!");
                        /**
                         * If Line's List Price is less then quoted price.
                         * Also Checking whether vendor, date & quoted price exist or not?
                         */

                        let flag = false;
                        let issueValue = 100;
                        let sublistLineCount = workOrderRecord.getLineCount({sublistId: 'item'});


                        for(let i = 0; i < sublistLineCount; i++) {
                            if(flag){
                                break;
                            }

                            let itemType = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'itemtype',line: i});
                            if(itemType == 'InvtPart'){
                                let listPrice = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_list_price',line: i});
                                let quotedPrice = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_quoted_price',line: i});
                                let vendorId = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_vendor',line: i});
                                let workDate = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_work_date',line: i});
                                
                                if(!listPrice || !quotedPrice){
                                    flag = true;
                                    issueValue = 0;
                                }else if(!vendorId || !quotedPrice || !workDate){ 
                                    flag = true;
                                    if(!vendorId){
                                        issueValue = 5;
                                    }else if(!workDate){
                                        issueValue = 6;
                                    }else if(!quotedPrice){
                                        issueValue = 7;
                                    }
                                }else if(Number(listPrice) < Number(quotedPrice)) { 
                                    flag = true;
                                    issueValue = 1;
                                    break;
                                }                        
                            }            
                        }
                        log.debug("Flag Value", flag);

                        if(flag){ //Some Details are not found
                            /***
                             * If true, then we need to set approver to "EMPLOYEE" & "Status = Pending Approval"
                             * Also throw an alert that approver is must as some details are not following criteria.
                             */

                            scriptContext.form.addButton({id : "custpage_approve_button",label : "Approve",functionName : 'directApproveWorkorder(' + newRec.id + ',' + false + ',' + issueValue + ')'});

                        }else{ //Every check passed, all okay
                            /**
                             * Prices are in normal range, and everything is okay,
                             * Then we need to do the following.
                             * Set Approval Status = Approved
                             * Create PO For it's Line.
                             * 
                             */

                            scriptContext.form.addButton({id : "custpage_approve_button",label : "Approve",functionName : 'directApproveWorkorder(' + newRec.id + ',' + true + ',' + issueValue + ')'});
                        }
                    }else if(approvalStatus && Number(approvalStatus) == 1){
                        log.debug("When approvalStatus is pending approval!");
                        /**
                         * Check Person Loggged in & setted approval exist
                         * If approver is entered & if approver himself is logged in, then approve directly,
                         * Else approver is not present then do below.
                         */

                        

                        if(approverIdSetted && (Number(approverIdSetted) == currentUserId)){
                            
                            /**
                             * Button will be visible, but need to validate, whether every data is inputted or not?
                             */

                            /**
                             * If Line's List Price is less then quoted price. --- This will not be checked, because that's why we have approver if amount exceeds.
                             * Also Checking whether vendor, date & quoted price exist or not?  Because this is must.
                             */

                            let flag = false;
                            let issueValue = 100;
                            let sublistLineCount = workOrderRecord.getLineCount({sublistId: 'item'});
                            log.debug("sublistLineCount",sublistLineCount);


                            for(let i = 0; i < sublistLineCount; i++) {
                                if(flag){
                                    break;
                                }

                                let itemType = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'itemtype',line: i});
                                if(itemType == 'InvtPart'){
                                    let listPrice = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_list_price',line: i});
                                    let quotedPrice = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_quoted_price',line: i});
                                    let vendorId = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_vendor',line: i});
                                    let workDate = workOrderRecord.getSublistValue({sublistId: 'item',fieldId: 'custcol_c60520_wo_work_date',line: i});

                                    log.debug("DEBUG LINE DATA in PA Before Checking: ", "quotedPrice: "+quotedPrice+"| listPrice: "+listPrice+" | vendorId: "+vendorId+" | workDate: "+workDate);
                                    if(!listPrice || !quotedPrice){
                                        flag = true;
                                        issueValue = 0;
                                    }else if(!vendorId || !quotedPrice || !workDate){ 
                                        flag = true;
                                        if(!vendorId){
                                            issueValue = 5;
                                        }else if(!workDate){
                                            issueValue = 6;
                                        }else if(!quotedPrice){
                                            issueValue = 7;
                                        }
                                    }else if(Number(listPrice) < Number(quotedPrice)) { 
                                        flag = true;
                                        issueValue = 1;
                                    }  
                                    log.debug("DEBUG LINE DATA in PA After Checking: ", "issueValue: "+issueValue+" | flag: "+flag);                      
                                }            
                            }
                            
                            scriptContext.form.addButton({id : "custpage_approve_button",label : "Approve",functionName : 'directApproveWorkorder(' + newRec.id + ',' + false + ',' + issueValue + ')'});
                        
                        }
                    }
                }               
            }
        }catch(e){
            log.error("Error inside before load", [e.message,e.stack]);
        }
    }
    return {beforeLoad}
});
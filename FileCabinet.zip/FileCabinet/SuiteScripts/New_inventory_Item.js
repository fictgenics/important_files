/**
@NApiVersion 2.0
@NScriptType ClientScript
@NModuleScope Public
*/

define(['N/record', 'N/runtime', 'N/error'], function (record, runtime, error) {


    function hideCost(context) {
        try {
            log.debug('hideCost()', 'Start Script');
           
			var currentRecord = context.currentRecord;
            var userObj = runtime.getCurrentUser();
         
          	var userDepartment = userObj.department;
          	var userRole=userObj.role
            console.log(userRole);
            if (userDepartment==8) {
              	currentRecord.getField({
  					fieldId: 'cost'
				}).isDisplay = false;
               
            }
            log.debug('hideCost()', 'End Script');
            return true;
        } catch (e) {
            log.error('hideCost() :: Error', 'errorMessage=' + e.message);
            return false;
        }
    }

    return {
        pageInit: hideCost
    };
});
/**
    * @NApiVersion 2.x
    * @NScriptType UserEventScript
    * @NModuleScope SameAccount
*/
/**
    * Script Name          : CSS UE POST DELIVERY PHASE  
    * Author               : Naim
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Discription          : This script link the invoice to it's ralative phases.
    * Version              : 2.0
*/
define(['N/search', 'N/record'],

    function (search, record) {

        /**
            * Function definition to be triggered before record is loaded.
            *
            * @param {Object} scriptContext
            * @param {Record} scriptContext.newRecord - New record
            * @param {string} scriptContext.type - Trigger type
            * @param {Form} scriptContext.form - Current form
            * @Since 2015.2
        */

        function afterSubmit(context) {
            try {
                var recObj = context.newRecord;
                var approvalStatus = recObj.getValue({ fieldId: 'approvalstatus' });
                if (approvalStatus == 2) {
                    var billObj = record.load({
                        type: 'vendorbill',
                        id: recObj.id,
                        isDynamic: true
                    });

                    var lineCnt = billObj.getLineCount({ sublistId: 'inboundshipments' });
                    log.debug("lineCnt", lineCnt);

                    if (lineCnt > 0) {
						var appliedAmt = billObj.getValue({ fieldId: 'custbody_c59306_applied_amount' });
                        var inboundId = billObj.getSublistValue({ sublistId: 'inboundshipments', fieldId: 'id', line: 0 });
                        log.debug("inboundId", inboundId);

                        if (!appliedAmt && inboundId) {
                            var remainAmt = billObj.getValue({ fieldId: 'total' });
                            log.debug("remainAmt", remainAmt);

                            var vendorprepaymentSearchObj = search.create({
                                type: "vendorprepayment",
                                filters:
                                    [
                                        ["type", "anyof", "VPrep"],
                                        "AND",
                                        ["custbody_c59306__purchase_milestone.custrecord_c59306_inbound_shipment", "anyof", inboundId],
                                        "AND",
                                        ["mainline", "is", "T"]
                                    ],
                                columns:
                                    [
                                        search.createColumn({ name: "internalid", label: "internalid" }),
                                        search.createColumn({ name: "tranid", label: "Document Number" })
                                    ]
                            });
                            var searchResultCount = vendorprepaymentSearchObj.runPaged().count;
                            log.debug("vendorprepaymentSearchObj result count", searchResultCount);
                            // No chance of huge results was coming
							var appliedPayment = false;
                            vendorprepaymentSearchObj.run().each(function (result) {
                                var prePaymentId = result.getValue({ name: "internalid", label: "internalid" });
                                var paymentAppObj = record.transform({ fromType: 'vendorprepayment', fromId: prePaymentId, toType: 'vendorprepaymentapplication', isDynamic: true });
								
								var paymentTotal = paymentAppObj.getValue({ fieldId: 'total' });
                                log.debug("paymentTotal", paymentTotal);

                                var lineCount = paymentAppObj.getLineCount({ sublistId: 'bill' });
                                log.debug("lineCount", lineCount);

                                for (var z = 0; z < lineCount; z++) {
                                    var selectLine = paymentAppObj.selectLine({ sublistId: 'bill', line: z });
                                    var billId = selectLine.getCurrentSublistValue({ sublistId: 'bill', fieldId: 'doc' });
                                    
                                    if (billId == recObj.id) {
                                        if (parseFloat(paymentTotal) > parseFloat(remainAmt)) {
                                            selectLine.setCurrentSublistValue({ sublistId: 'bill', fieldId: 'apply', value: true });
                                            selectLine.setCurrentSublistValue({ sublistId: 'bill', fieldId: 'amount', value: remainAmt });
                                            selectLine.commitLine({ sublistId: 'bill' });
                                            remainAmt = 0;
                                            break;
                                        }
                                        else {
                                            selectLine.setCurrentSublistValue({ sublistId: 'bill', fieldId: 'apply', value: true });
                                            selectLine.commitLine({ sublistId: 'bill' });
                                            remainAmt = remainAmt - paymentTotal;
                                            break;
                                        }
                                    }
                                }
                                log.debug("remainAmt", remainAmt);
								var paymentAppId = paymentAppObj.save({ ignoreMandatoryFields: true });
                                log.debug('paymentAppId', paymentAppId);
								if(paymentAppId){
									appliedPayment = true;
								}
                                return true;
                            });
							
							if(appliedPayment && recObj.id){
								record.submitFields({
                                    type: 'vendorbill',
                                    id: recObj.id,
                                    values: {
                                        custbody_c59306_applied_amount: true
                                    },
                                    options: {
                                        enableSourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });
							}
                        }
                    }

                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }

        return {
            afterSubmit: afterSubmit
        };

    });	
/**
* @NApiVersion 2.x
* @NScriptType ClientScript
* @NModuleScope SameAccount
*/

/*******************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Showing Amounts Runtime.js
* DEVOPS TASK: BL/59545
* AUTHOR: Akash Sharma
* DATE CREATED: 10-March-2023
* DESCRIPTION: FOR showing amounts like applied & available on vendor load on runtime.
* REVISION HISTORY
* Date            DevOps          By          Description
* ===============================================================================
* 12-April-2023  DD/59548    Akash Sharma    On PO side, we need validation to ensure the 
*                                            "Apply now" amount is not more than the available 
*                                            prepayment balances.
*17-April-2023   DD/59548    Akash Sharma    Added validation for open milestone's line-level's
*                                            sum should be less then maximum prepayment amount. 
********************************************************************************/

define(['N/query','N/search'],function(query, search) {
  
  /**
  * Function to be executed after page is initialized.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
  *
  * @since 2015.2
  */
  function pageInit(scriptContext) {
    // console.log("Inside page init function");    
    var currentRecord = scriptContext.currentRecord;
    var vendorId = currentRecord.getValue({fieldId: 'id'});
    // console.log("vendorId", vendorId);
    if(vendorId){
      var purchaseMilestoneApplicationQuery = "SELECT SUM(custrecord_c59306_purc_milestone_app_to) as purchmilestonesum FROM customrecord_c59306_purchase_miles_app AS pa ";
        purchaseMilestoneApplicationQuery += "JOIN customrecord_c59306_purchase_milestone AS pm ON pa.custrecord_c59306_purchase_pay_milestone= pm.id ";
        purchaseMilestoneApplicationQuery += "LEFT JOIN transaction AS t ON pm.id = t.custbody_c59306__purchase_milestone AND t.recordtype = 'vendorprepayment' ";
        purchaseMilestoneApplicationQuery += "WHERE pa.custrecord_c59306_purchase_vendor = '"+vendorId+"' AND pa.isinactive = 'F' AND BUILTIN.DF(t.status) <> 'Vendor Prepayment : Fully Applied'";
        log.debug("purchaseMilestoneApplicationQuery", purchaseMilestoneApplicationQuery);

      var purchaseMilestoneApplicationOutput = runSuiteQuery(purchaseMilestoneApplicationQuery);
     
      var fieldLookup = search.lookupFields({
        type: search.Type.VENDOR,
        id: vendorId,
        columns: ['prepaymentbalance']
      });

      var prepaymentBalance = fieldLookup.prepaymentbalance;
      if(!prepaymentBalance) prepaymentBalance = 0;

      // console.log("prepaymentBalance", prepaymentBalance);
      
      if(purchaseMilestoneApplicationOutput.length > 0){
        
        var appliedAmount = Number(purchaseMilestoneApplicationOutput[0]['purchmilestonesum']);
        var availableAmount = prepaymentBalance - appliedAmount;

        // console.log("appliedAmount-->", appliedAmount);
        // console.log("availableAmount-->", availableAmount);

        currentRecord.setValue({fieldId: 'custentity_c59306_applied_amount', value: appliedAmount});
        currentRecord.setValue({fieldId: 'custentity_c59306_available_amount', value: availableAmount});
      }else{
        currentRecord.setValue({fieldId: 'custentity_c59306_applied_amount', value: 0});
        currentRecord.setValue({fieldId: 'custentity_c59306_available_amount', value: availableAmount});
      }
      
    }
    
  }

  // function validateLine(scriptContext) { debugger;
  //   // console.log("Inside validateLine");
  //   var currentRecordObj = scriptContext.currentRecord;
  //   var sublistName = scriptContext.sublistId;
  //   var fieldName = 'custpage_applied_now';
  //   var lineCount = currentRecordObj.getLineCount({sublistId: sublistName});
  //   var totalAmount = 0;
  //   var availableAmount = currentRecordObj.getValue({fieldId: 'custentity_c59306_available_amount'});
  //   var maxPrepaymentAmount = currentRecordObj.getValue({fieldId: 'custentity_c59306_maximum_prepayment'});
  //   if(!maxPrepaymentAmount) maxPrepaymentAmount = 0;
  //   else maxPrepaymentAmount = Number(maxPrepaymentAmount);

  //   if(sublistName == 'custpage_open_milestone_list'){ 
	 //  var milestoneId =  currentRecordObj.getCurrentSublistValue({sublistId: sublistName, fieldId: 'custpage_milestone_id'});  
	 //  var lineNumber = currentRecordObj.findSublistLineWithValue({sublistId: sublistName,fieldId: 'custpage_milestone_id',value: milestoneId});

  //     for (var i = 0; i < lineCount; i++) {
		// if(lineNumber != i){  
		//   var markPayment = currentRecordObj.getSublistValue({sublistId: sublistName, fieldId: 'custpage_mark_payment', line: i});  
  //         var appliedLineAmount = currentRecordObj.getSublistValue({sublistId: sublistName, fieldId: fieldName, line: i});
		// }
		// else{
		//   var markPayment = currentRecordObj.getCurrentSublistValue({sublistId: sublistName, fieldId: 'custpage_mark_payment'});  
  //         var appliedLineAmount = currentRecordObj.getCurrentSublistValue({sublistId: sublistName, fieldId: fieldName});	
		// }
  //       if(markPayment && appliedLineAmount){
  //         totalAmount += Number(appliedLineAmount);
  //         if((totalAmount > availableAmount) || (totalAmount > maxPrepaymentAmount)){
  //           alert("Sum of applied amount on line-level is more then body level Applied Amount or Max Prepayment Amount.");
  //           currentRecordObj.setCurrentSublistValue({sublistId: sublistName, fieldId: fieldName, line: i, value: ""});
  //           return false;
  //         }
  //       }        
  //     }
  //   }      
  //   return true;
  // }
   

  function runSuiteQuery(queryString) {
    // console.log("Query", queryString);
    var resultSet = query.runSuiteQL({query: queryString});
    // console.log("Query wise Data", resultSet.asMappedResults());
    if(resultSet && resultSet.results && resultSet.results.length > 0) {
        return resultSet.asMappedResults();
    } else {
        return [];
    }
  }
  
  return {
    pageInit: pageInit
    // validateLine: validateLine
  };
  
});
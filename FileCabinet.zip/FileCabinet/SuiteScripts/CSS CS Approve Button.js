/*******************************************************************************
*  * Copyright (c) 2024 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: 
* DEVOPS TASK: BACKLOG 71371
* AUTHOR: Anushka Banerjee
* DATE CREATED: 6-3-2024
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
/**
 *@NApiVersion 2.1
 *@NScriptType ClientScript
 */
define(['N/currentRecord', 'N/record'], function (currentRecord, record) {

    function pageInit(context) {

    }

    function accept() {
        try {
            var quoteID = currentRecord.get().id;
            var recType = currentRecord.get().type;
            log.debug("recType", recType);
            if (recType == 'salesorder') {
                record.submitFields({
                    type: 'salesorder',
                    id: quoteID,
                    values: { 'custbody_c60520_wo_app_status': 2, 'orderstatus': 'B'}
                });
            }
            else {
                record.submitFields({
                    type: 'estimate',
                    id: quoteID,
                    values: { 'custbody_c60520_wo_app_status': 2 }
                });
            }
            window.location.reload(true);
        } catch (err) {
            log.error("Error in accpt button", err);
        }
    }

    return {
        pageInit: pageInit,
        accept: accept
    }
});
/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH 57685,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/
define(['N/url', 'N/https', 'N/record'],

    function (url, https, record) {
        var addOnsCnt = false;

        function pageInit(context) {

        }

        function addons(recId) {
            //alert(recId);
            if (!addOnsCnt) {
                addOnsCnt = true;
                var suiteletUrl = url.resolveScript({ scriptId: 'customscript_css_sl_addons', deploymentId: 'customdeploy_css_sl_addons', returnExternalUrl: false });
                suiteletUrl += '&soId=' + recId;
                var response = https.get({ url: suiteletUrl });

                if (JSON.parse(response.body) == 'Success') {
                    record.submitFields({
                        type: 'salesorder',
                        id: recId,
                        values: {
                            custbody_c60520_addons_processing: true
                        },
                        options: {
                            ignoreMandatoryFields: true
                        }
                    });

                    location.reload();
                }
                else {
                    alert('Something went wrong.');
                }
            }
            else {
                alert('AddOns is in Processing.');
            }
        }

        return {
            pageInit: pageInit,
            addons: addons
        }

    }
);
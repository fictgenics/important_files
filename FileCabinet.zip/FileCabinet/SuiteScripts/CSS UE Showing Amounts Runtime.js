/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*******************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Showing Amounts Runtime.js
* DEVOPS TASK: BL/59545
* AUTHOR: Akash Sharma
* DATE CREATED: 10-March-2023
* DESCRIPTION: FOR showing amounts like applied & available on vendor load on runtime.
* REVISION HISTORY
* Date          DevOps          By
* ===============================================================================
*
********************************************************************************/
define(['N/record', 'N/ui/serverWidget', 'N/search', 'N/task', 'N/query'], function (record, serverWidget, search, task, query) {

	function beforeLoad(context) {
		try {
			var custForm = context.form;
			var recObj = context.newRecord;

			if (context.type == 'view') {
				var appliedField = custForm.getField({id: 'custentity_c59306_applied_amount'});
				appliedField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
				
				var availableField = custForm.getField({id: 'custentity_c59306_available_amount'});
				availableField.updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
	 
				var field1 = custForm.addField({id: 'custpage_applied_amt',type: serverWidget.FieldType.CURRENCY,label: 'APPLIED AMOUNT'});
				var field2 = custForm.addField({id: 'custpage_available_amt',type: serverWidget.FieldType.CURRENCY,label: 'AVAILABLE AMOUNT'});

				custForm.insertField({field: field1, nextfield: 'prepaymentbalance'});
				custForm.insertField({field: field2, nextfield: 'prepaymentbalance'});
				
				var vendorLookup = search.lookupFields({
                    type: 'vendor',
                    id: recObj.id,
                    columns: ['prepaymentbalance']
                });
                var prepaymentBalance = vendorLookup.prepaymentbalance;
				
				if(recObj.id){
					var purchaseMilestoneApplicationQuery = "SELECT SUM(custrecord_c59306_purc_milestone_app_to) as purchmilestonesum FROM customrecord_c59306_purchase_miles_app AS pa ";
					purchaseMilestoneApplicationQuery += "JOIN customrecord_c59306_purchase_milestone AS pm ON pa.custrecord_c59306_purchase_pay_milestone= pm.id ";
					purchaseMilestoneApplicationQuery += "LEFT JOIN transaction AS t ON pm.id = t.custbody_c59306__purchase_milestone AND t.recordtype = 'vendorprepayment' ";
					purchaseMilestoneApplicationQuery += "WHERE pa.custrecord_c59306_purchase_vendor = '"+recObj.id+"' AND pa.isinactive = 'F' AND BUILTIN.DF(t.status) <> 'Vendor Prepayment : Fully Applied'";
					log.debug("purchaseMilestoneApplicationQuery", purchaseMilestoneApplicationQuery);
			
					var purchaseMilestoneApplicationOutput = runSuiteQuery(purchaseMilestoneApplicationQuery);

					if(purchaseMilestoneApplicationOutput.length > 0){          
						var appliedAmount = Number(purchaseMilestoneApplicationOutput[0]['purchmilestonesum']);
						var availableAmount = prepaymentBalance - appliedAmount;
			  
						recObj.setValue({fieldId: 'custpage_applied_amt', value: appliedAmount, ignoreFieldChange: true});
						recObj.setValue({fieldId: 'custpage_available_amt', value: availableAmount, ignoreFieldChange: true});
					  }else{
						recObj.setValue({fieldId: 'custpage_available_amt', value: availableAmount, ignoreFieldChange: true});
						recObj.setValue({fieldId: 'custpage_applied_amt', value: 0, ignoreFieldChange: true});
					}
				}
			}
		}
		catch (e) { log.error('Error', e) }
	}

	function runSuiteQuery(queryString) {
		// console.log("Query", queryString);
		var resultSet = query.runSuiteQL({query: queryString});
		// console.log("Query wise Data", resultSet.asMappedResults());
		if(resultSet && resultSet.results && resultSet.results.length > 0) {
			return resultSet.asMappedResults();
		} else {
			return [];
		}
	  }




	return {
		beforeLoad: beforeLoad
	};
});
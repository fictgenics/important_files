/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS MR WO Release.js
* DEVOPS TASK: DT/60528
* AUTHOR: Akash Sharma
* DATE CREATED: 24-April-2023
* DESCRIPTION: This script is for marking all the workorder's orderstatus as release when FR is Marked In Progress.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/record','N/search', 'N/format', 'N/runtime'], (record, search, format, runtime) => {
    /**
     * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
     * @param {Object} inputContext
     * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {Object} inputContext.ObjectRef - Object that references the input data
     * @typedef {Object} ObjectRef
     * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
     * @property {string} ObjectRef.type - Type of the record instance that contains the input data
     * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
     * @since 2015.2
     */

    const getInputData = (inputContext) => {
        try{
            let workOrderIdString = runtime.getCurrentScript().getParameter({name:'custscript_c60520_woid_string'});
            log.debug("before workOrderIdString",workOrderIdString);
            workOrderIdString = workOrderIdString.split(",");
            log.debug("after workOrderIdString",workOrderIdString);

            /**
             * Converting Array to Object to Pass to Map Function.
             */

            var mainObj = workOrderIdString.reduce(function(acc, cur, i) {
                acc[i] = cur;
                return acc;
            }, {});

            log.debug("Obj to Map is -->", mainObj);

            if(workOrderIdString.length > 0)
            return mainObj;
            
        }catch(e){
            log.error("Error Inside GetInputData Function!", [e.message, e.stack]);
        }      
    }

    const map = (mapContext) => {

        try{
            let workOrderId = JSON.parse(mapContext.value);

            workOrderId = Number(workOrderId);
            log.debug("workOrderId", workOrderId);

            let savedWOId = record.submitFields({
                type: 'workorder',
                id: workOrderId,
                values: {
                    orderstatus: 'B'
                },
                options: {
                    enableSourcing: false,
                    ignoreMandatoryFields : true
                }
                
            });

            log.debug("savedWOId", savedWOId);
            
        }catch(e){
            log.error("Error Inside ReduceContext: ", [e.message, e.stack]);
        }
    }


    /**
     * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
     * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
     * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
     * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
     *     script
     * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
     * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
     *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
     * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
     * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
     * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
     *     script
     * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
     * @param {Object} summaryContext.inputSummary - Statistics about the input stage
     * @param {Object} summaryContext.mapSummary - Statistics about the map stage
     * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
     * @since 2015.2
     */
    const summarize = (summaryContext) => {

        try{

            log.debug("Inside Summary");
        }catch(e){
            log.error("Error Inside SummaryContext: ", [e.message, e.stack]);
        }

    }

    return {getInputData, map, summarize}

});

/**
@NApiVersion 2.0
@NScriptType ClientScript
*/
define(['N/search','N/log'], function (search, log) {
    var itemArray = [];
    var codesource = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

    function initScript(context) {
        buildItemArray();
    }

    function buildItemArray() {
        searchItems();
        itemArray = runSearch(itemArray);
        log.debug('itemarray',itemArray);
        deleteSearch();
    }

    function searchItems(context) {
        var itemSearch = search.create({
            type: search.Type.INVENTORY_ITEM,
            title: 'Inventory_Item_Search',
            id: 'customsearch_inventory_item_search_s',
            columns: ['internalid', 'itemid'],
            filters: ['isinactive', 'is', 'F']
        });
        itemSearch.save();
    }

    function runSearch(itemArray) {
        var mySearch = search.load({
            id: 'customsearch_inventory_item_search_s'
        });
        mySearch.run().each(function (result) {
            var item = {};
            item.itemID = result.getValue({
                name: 'itemid'
            });
            item.internalID = result.getValue({
                name: 'internalid'
            });
            itemArray.push(item);
            return true;
        });
        return itemArray;
    }

    function deleteSearch() {
        search.delete({
            id: 'customsearch_inventory_item_search_s'
        });
    }

    function getIndex(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    function fieldChanged(context) {
        var currentRecord = context.currentRecord;
        var fieldId = context.fieldId;
        var digit1 = '';
        var digit2 = '';
        var digit3 = '';
        var code = '';
        if (fieldId === 'custitem_car_year') {

            var j = 0;
            do {
                digit1 = codesource.charAt(getIndex(0, 35));
                digit2 = codesource.charAt(getIndex(0, 35));
                digit3 = codesource.charAt(getIndex(0, 35));
                code = digit1 + digit2 + digit3;
                var flag = 0;
                for (j = 0; j < itemArray.length; j++) {
                    if (code == itemArray[j].itemID) {
                        flag = 1;
                        break;
                    }
                }
            } while (flag == 1)
            currentRecord.setValue({
                fieldId: 'itemid',
                value: code,
            });
        }
    }
    return {
        pageInit: initScript,
        fieldChanged: fieldChanged
    };
});
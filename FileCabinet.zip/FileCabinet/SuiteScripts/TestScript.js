 /**
 * @NApiVersion 2.0
 * @NModuleScope Public
 * @NScriptType ClientScript
 */
define([], function () {
 function showMessage(context){
 	   	var message=context.currentRecord.getValue({"fieldId":"custevent1"});
   		alert("Use The Other Save Button Please !!");
   		var title=context.currentRecord.getValue({"fieldId":"title"});
   		var dept=context.currentRecord.getText({"fieldId":"custevent1"});
   		//var department=dept.options[dept.selectedIndex].text;
   	console.log(dept+"\n"+title);
    }
	return{
      saveRecord:showMessage
    };
});
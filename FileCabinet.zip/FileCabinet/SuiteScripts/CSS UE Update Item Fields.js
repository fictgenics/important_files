/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Update Item Fields.js
* DEVOPS TASK: DT/60521
* AUTHOR: Akash Sharma
* DATE CREATED: 21-April-2023
* DESCRIPTION: This script is to update matrix item's fields's name.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define(['N/record', 'N/search', 'N/query', './Matrix Items.lib.js'], (record, search, query, mat) => {
    /**
     * Defines the function definition that is executed before record is loaded.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @param {Form} scriptContext.form - Current form
     * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
     * @since 2015.2
     */
    const beforeLoad = (scriptContext) => {
        try {
            let newItemRecord = scriptContext.newRecord;

            /**
             * Header Level Data
             */

            let itemId = Number(newItemRecord.id);
            let subItem = newItemRecord.getText({ fieldId: 'parent' }); //Variant
            let subItemId = newItemRecord.getValue({ fieldId: 'internalid' });

            /**
             * Only Run If parent has no value
             */

            if (!subItem) {

                /**
                 * Search to Find Maximum Sequence
                 */

                let assemblyitemSearchObjVariant = search.create({
                    type: "assemblyitem",
                    filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                    columns: [search.createColumn({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" })]
                });
                let assemblyitemSearchObjVariantResult = assemblyitemSearchObjVariant.run().getRange({ start: 0, end: 1 });
                let maxSequenceVariant = assemblyitemSearchObjVariantResult[0].getValue({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" });
                log.debug("maxSequenceVariant", maxSequenceVariant);

                let assemblyitemSearchObjUnmodifiedVariant = search.create({
                    type: "assemblyitem",
                    filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                    columns: [search.createColumn({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" })]
                });
                let assemblyitemSearchObjUnmodifiedVariantResult = assemblyitemSearchObjUnmodifiedVariant.run().getRange({ start: 0, end: 1 });
                let maxSequenceUnmodifiedVariant = assemblyitemSearchObjUnmodifiedVariantResult[0].getValue({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" });
                log.debug("maxSequenceUnmodifiedVariant", maxSequenceUnmodifiedVariant);

                // log.debug("Item is Parent!");

                let itemIdText = newItemRecord.getText({ fieldId: 'itemid' }); //Item Name/Number

                /**
                 * Getting Line Count & Loading Each Matrix Sub Item!
                 */

                let matrixSublistLineCount = newItemRecord.getLineCount({ sublistId: 'matrixmach' });
                if (matrixSublistLineCount > 0) {

                    /**
                     * Looping Over Matrix Sub Item Sublist
                     */

                    for (let iter = 0; iter < matrixSublistLineCount; iter++) {

                        /**
                         * Matrix SubTab Data
                         */

                        let matrixSubItemRecordId = Number(newItemRecord.getSublistValue({ sublistId: 'matrixmach', fieldId: 'mtrxid', line: iter }));
                        log.debug("matrixSubItemRecordId: " + matrixSubItemRecordId, "iter: " + iter);
                        let matrixSubItemRecord = record.load({ type: 'serializedassemblyitem', id: matrixSubItemRecordId });

                        let steering = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_steering_list' }); //Steerling List 
                        let engineCapacity = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_engine_capacity' }); //Engine Capacity List 
                        let fuel = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_matrix_fuel' }); //Fuel List 
                        // log.debug("steering",steering);
                        // log.debug("engineCapacity",engineCapacity);
                        // log.debug("fuel",fuel);

                        /**
                         * Creating MODEL (BGK) 
                         */

                        let steeringAbv;
                        if (steering.length > 0) {
                            steeringAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_steering_list', id: Number(steering), columns: ['abbreviation'] })).abbreviation;
                        } else {
                            steeringAbv = "";
                        }

                        let engineCapacityAbv;
                        if (engineCapacity.length > 0) {
                            engineCapacityAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_eng_cap_list', id: Number(engineCapacity), columns: ['abbreviation'] })).abbreviation;
                        } else {
                            engineCapacityAbv = "";
                        }

                        let fuelAbv;
                        if (fuel.length > 0) {
                            fuelAbv = (search.lookupFields({ type: 'customlist_c60520_matrix_fuel_list', id: Number(fuel), columns: ['abbreviation'] })).abbreviation;
                        } else {
                            fuelAbv = "";
                        }

                        let modelBGK = steeringAbv + itemIdText + engineCapacityAbv + fuelAbv;
                        log.debug("MODEL Name :", modelBGK);

                        /**
                         * If this name doesn't exit then create else set value of MODEL (BGK) Record
                         */

                        let setModelBGK;

                        let findModelBGK = runSuiteQuery("findModelBGK", "SELECT id FROM customrecord_c60520_model_bgk WHERE name = '" + modelBGK + "'");
                        if (findModelBGK.length > 0) {
                            setModelBGK = Number(findModelBGK[0]['id']);
                            matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_model_bgk', value: setModelBGK });
                            log.debug("MODEL ID From Query: " + setModelBGK);
                        } else {
                            let modelBGKRecord = record.create({ type: 'customrecord_c60520_model_bgk' });
                            modelBGKRecord.setValue({ fieldId: 'name', value: modelBGK });
                            setModelBGK = Number(modelBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true }));
                            matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_model_bgk', value: setModelBGK });
                            log.debug("MODEL ID Created: " + setModelBGK);
                        }

                        /**
                         * Getting Values
                         */

                        var data = fieldsArray();
                        for (let i = 0; i < data.length; i++) {
                            data[i].values = matrixSubItemRecord.getValue({ fieldId: data[i].actualFieldId });
                        }

                        /**
                         * Checking Whether Custom Record Variant BGK has "SAMPLE_1" OR NOT?
                         */

                        let findVariantBGK;
                        let setVariantBGK;

                        /**
                         * Creating & Setting Variant (BGK)
                         * For this we need all combinations except colors.
                         */

                        let itemVariantBGKCombinationSearch = itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, setModelBGK, data);

                        if (itemVariantBGKCombinationSearch.length <= 0) {
                            let variantAlreadySequenced = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_already_sequenced' });
                            log.debug("variantAlreadySequenced", variantAlreadySequenced);
                            if (!variantAlreadySequenced) {

                                /**
                                 * Simply Set Create & Set Custom Record's ID on Item Record.
                                 */

                                let variantBGKRecord = record.create({ type: 'customrecord_c60520_variant_bgk' });
                                findVariantBGK = modelBGK + "_" + (parseInt(itemVariantBGKCombinationSearch.length) + 1);
                                log.debug("First Variant: ", findVariantBGK);

                                let assemblyitemSearchObjVariantSequence = search.create({
                                    type: "assemblyitem",
                                    filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                                    columns: [search.createColumn({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" })]
                                });
                                let searchResultCount = assemblyitemSearchObjVariantSequence.runPaged().count;
                                let assemblyitemSearchObjVariantSequenceResult = assemblyitemSearchObjVariantSequence.run().getRange({ start: 0, end: 1 });
                                log.debug("assemblyitemSearchObjVariantSequenceResult", assemblyitemSearchObjVariantSequenceResult);
                                let maxSequenceVariantNumber = assemblyitemSearchObjVariantSequenceResult[0].getValue({ name: "custitem_c60520_variant_sequence", summary: "MAX", label: "Variant Sequence" });
                                log.debug("maxSequenceVariant", maxSequenceVariant);

                                /**
                                 * New Variant Will be.
                                 */

                                if (searchResultCount > 0) {
                                    if (!maxSequenceVariantNumber) {
                                        maxSequenceVariantNumber = 1;
                                    } else {
                                        maxSequenceVariantNumber = parseInt(maxSequenceVariantNumber) + 1;
                                    }

                                    findVariantBGK = modelBGK + "_" + maxSequenceVariantNumber;
                                    log.debug("Second Variant: " + findVariantBGK, "maxSequenceVariant Value Prior to Set: " + maxSequenceVariantNumber);
                                    matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_variant_sequence', value: maxSequenceVariantNumber });

                                } else {
                                    matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_variant_sequence', value: (parseInt(itemVariantBGKCombinationSearch.length) + 1) });
                                }

                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_already_sequenced', value: true });

                                variantBGKRecord.setValue({ fieldId: 'name', value: findVariantBGK });
                                setVariantBGK = variantBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_variant_bgk', value: Number(setVariantBGK) });
                                log.debug("VARIANT PREPARED: " + findVariantBGK, "VARINAT ID From Query: " + setVariantBGK);
                            } else {
                                findVariantBGK = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_variant_bgk" });
                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_already_sequenced', value: true });
                                log.debug("Getting findVariantBGK Value When True!", findVariantBGK);
                            }
                        } else {
                            setVariantBGK = (itemVariantBGKCombinationSearch[0].getValue({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }));
                            findVariantBGK = (itemVariantBGKCombinationSearch[0].getText({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }));
                            matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_variant_bgk', value: (setVariantBGK) });
                            log.debug("VARINAT (ID) From Query: " + setVariantBGK, "VARINAT TEXT) From Query: " + findVariantBGK);
                        }



                        /**
                         * Checking Whether Custom Record Unmodified Variant BGK has "SAMPLE_1" OR NOT?
                         */

                        let findUnmodifiedVariantBGK;
                        let setUnmodifiedVariantBGK;

                        /**
                        * Creating & Setting Unmodified Variant (BGK)
                        * For this we need all combinations except colors.
                        */

                        let itemUnmodifiedVariantBGKCombinationSearch = itemUnmodifiedVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, setModelBGK, data); //Sending Colors & Modifications As Null

                        if (itemUnmodifiedVariantBGKCombinationSearch.length <= 0) {
                            let unmodifiedVariantAlreadySequenced = matrixSubItemRecord.getValue({ fieldId: 'custitem_c60520_unm_already_sequenced' });
                            log.debug("unmodifiedVariantAlreadySequenced", unmodifiedVariantAlreadySequenced);
                            if (!unmodifiedVariantAlreadySequenced) {

                                /**
                                 * Simply Set Create & Set Custom Record's ID on Item Record.
                                 */

                                let UnmodifiedVariantBGKRecord = record.create({ type: 'customrecord_c60520_variant_bgk' });
                                findUnmodifiedVariantBGK = modelBGK + "_" + (parseInt(itemUnmodifiedVariantBGKCombinationSearch.length) + 1);

                                log.debug("Second Unmodified Variant: ", findUnmodifiedVariantBGK);

                                let assemblyitemSearchObjUnmodifiedVariantSequence = search.create({
                                    type: "assemblyitem",
                                    filters: [["type", "anyof", "Assembly"], "AND", ["matrix", "is", "F"], "AND", ["matrixchild", "is", "T"], "AND", ["parent", "anyof", itemId]],
                                    columns: [search.createColumn({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" })]
                                });
                                var searchResultCount = assemblyitemSearchObjUnmodifiedVariantSequence.runPaged().count;
                                let assemblyitemSearchObjUnmodifiedVariantSequenceResult = assemblyitemSearchObjUnmodifiedVariantSequence.run().getRange({ start: 0, end: 1 });
                                log.debug("assemblyitemSearchObjUnmodifiedVariantSequenceResult", assemblyitemSearchObjUnmodifiedVariantSequenceResult);
                                let maxSequenceUnmodifiedVariantNumber = assemblyitemSearchObjUnmodifiedVariantSequenceResult[0].getValue({ name: "custitem_c60520_unm_variant_sequence", summary: "MAX", label: "Unmodified Variant Sequence" });
                                log.debug("maxSequenceUnmodifiedVariantNumber", maxSequenceUnmodifiedVariantNumber);

                                /**
                                 * New Variant Will be.
                                 */

                                if (searchResultCount > 0) {
                                    if (!maxSequenceUnmodifiedVariantNumber) {
                                        maxSequenceUnmodifiedVariantNumber = 1;
                                    } else {
                                        maxSequenceUnmodifiedVariantNumber = parseInt(maxSequenceUnmodifiedVariantNumber) + 1;
                                    }

                                    findUnmodifiedVariantBGK = modelBGK + "_" + maxSequenceUnmodifiedVariantNumber;
                                    matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_variant_sequence', value: maxSequenceUnmodifiedVariantNumber });
                                    log.debug("Second Unmodified Variant: " + findUnmodifiedVariantBGK, "maxSequenceUnmodifiedVariantNumber Value Prior to Set: " + maxSequenceUnmodifiedVariantNumber);
                                } else {
                                    matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_variant_sequence', value: (parseInt(itemUnmodifiedVariantBGKCombinationSearch.length) + 1) });
                                }

                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_already_sequenced', value: true });

                                UnmodifiedVariantBGKRecord.setValue({ fieldId: 'name', value: findUnmodifiedVariantBGK });
                                setUnmodifiedVariantBGK = UnmodifiedVariantBGKRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk', value: Number(setUnmodifiedVariantBGK) });
                                log.debug("UNMODIFIED VARIANT PREPARED: " + findUnmodifiedVariantBGK, "UNMODIFIED VARINAT ID From Query: " + setUnmodifiedVariantBGK);
                            }
                            else {
                                findUnmodifiedVariantBGK = matrixSubItemRecord.getText({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk' });
                                matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_unm_already_sequenced', value: true });
                            }
                        } else {
                            setUnmodifiedVariantBGK = (itemUnmodifiedVariantBGKCombinationSearch[0].getValue({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Variant (BGK)" }));
                            findUnmodifiedVariantBGK = (itemUnmodifiedVariantBGKCombinationSearch[0].getText({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Variant (BGK)" }));
                            matrixSubItemRecord.setValue({ fieldId: 'custitem_c60520_matrix_unm_variant_bgk', value: (setUnmodifiedVariantBGK) });
                            log.debug("UNMODIFIED VARINAT (ID) From Query: " + setUnmodifiedVariantBGK, "UNMODIFIED VARINAT (TEXT) From Query: " + findUnmodifiedVariantBGK);
                        }


                        /**
                         * Creating & Setting ITEM NAME/NUMBER, also setting MODEL (BGK)
                         * Calling Search For All Sub Matrix Items
                         */

                        /**
                         * Creating Prefix for ItemName/Number
                         */


                        let extMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                        let extSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                        let intMainColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_main_color" });
                        let intSubColValue = matrixSubItemRecord.getValue({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                        let extMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_main_color" });
                        let extSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_ext_sub_color" });
                        let intMainColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_main_color" });
                        let intSubColText = matrixSubItemRecord.getText({ fieldId: "custitem_c60520_matrix_int_sub_color" });

                        let remainingPrefixForItemNameNumber = callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue);
                        log.debug("Item Name/Number : ", findVariantBGK + "-" + remainingPrefixForItemNameNumber);


                        matrixSubItemRecord.setValue({ fieldId: 'itemid', value: findVariantBGK + "-" + remainingPrefixForItemNameNumber });
                        matrixSubItemRecord.setValue({ fieldId: 'displayname', value: findVariantBGK + "-" + remainingPrefixForItemNameNumber });
                        log.debug("Before save;")

                        let finalSubItemId = matrixSubItemRecord.save({ enableSourcing: true, ignoreMandatoryFields: true });
                        log.debug("finalSubItemId", finalSubItemId);

                    }
                }
            }
        } catch (e) {
            log.error("Error Inside before Load", [e.stack, e.message]);
        }
    }

    /**
     * Defines the function definition that is executed before record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const beforeSubmit = (scriptContext) => {

    }

    /**
     * Defines the function definition that is executed after record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const afterSubmit = (scriptContext) => {

    }

    function itemVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, modelBGK, data) {
        log.debug("Inside itemVariantBGKCombinationCheck Function!");

        let allFilters =
            [
                ["type", "anyof", "Assembly"], "AND",
                ["matrix", "is", "F"], "AND",
                ["matrixchild", "is", "T"], "AND",
                ["internalid", "noneof", matrixSubItemRecordId]
                ,"AND",["custitem_c60520_already_sequenced","is",'T'] 

            ];

        //Pushing filters only when value for those filters is entered, else blank.
        // if (modelBGK) allFilters.push('AND', ["custitem_c60520_matrix_model_bgk", "anyof", modelBGK]);
        if (itemId) allFilters.push('AND', ["parent", "anyof", itemId]);
        for (let i = 0; i < data.length; i++) {
            //Skipping colors and mdifications since it was supposed to be sent as null
            if (data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
            //pushing filters for the rest
            if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
        }

        let allColumns =
            [
                search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
                search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
                search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
            ];
        let searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
        log.debug("searchData", searchData);
        return searchData;

    }

    function itemUnmodifiedVariantBGKCombinationCheck(matrixSubItemRecordId, itemId, modelBGK, data) {
        log.debug("Inside itemUnmodifiedVariantBGKCombinationCheck Function!");

        let allFilters =
            [
                ["type", "anyof", "Assembly"], "AND",
                ["matrix", "is", "F"], "AND",
                ["matrixchild", "is", "T"], "AND",
                ["internalid", "noneof", matrixSubItemRecordId]
                , "AND",["custitem_c60520_unm_already_sequenced","is",'T'] 

            ];

        //Pushing filters only when value for those filters is entered, else blank.

        // if (modelBGK) allFilters.push('AND', ["custitem_c60520_matrix_model_bgk", "anyof", modelBGK]);
        if (itemId) allFilters.push('AND', ["parent", "anyof", itemId]);
        for (let i = 0; i < data.length; i++) {
            //Skipping colors and mdifications since it was supposed to be sent as null
            if (data[i].label == 'Exterior Main Color' || data[i].label == 'Exterior Sub Color' || data[i].label == 'Interior Main Color' || data[i].label == 'Interior Sub Color') continue;
            //pushing filters for the rest
            if (data[i].values && data[i].values > 0) allFilters.push('AND', [data[i].actualFieldId, "anyof", data[i].values]);
        }

        let allColumns =
            [
                search.createColumn({ name: "internalid", sort: search.Sort.ASC, label: "Internal ID" }),
                search.createColumn({ name: "custitem_c60520_matrix_variant_bgk", label: "Variant (BGK)" }),
                search.createColumn({ name: "custitem_c60520_matrix_unm_variant_bgk", label: "Unmodified Variant (BGK)" })
            ];
        let searchData = searchAllRecord('assemblyitem', null, allFilters, allColumns);
        log.debug("searchData", searchData);
        return searchData;
    }

    function callRemainingPrefixItemNameSearch(extMainColText, extSubColText, intMainColText, intSubColText, extMainColValue, extSubColValue, intMainColValue, intSubColValue) {
        log.debug("Inside callRemainingPrefixItemNameSearch Function!");
        let mainString = "";
        log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);
        log.debug("COLOR NAME DEBUG", "extMainColText: " + extMainColText + " | extSubColText: " + extSubColText + " | intMainColText: " + intMainColText + " | intSubColText: " + intSubColText);

        intMainColValue = Number(intMainColValue);
        intSubColValue = Number(intSubColValue);
        extMainColValue = Number(extMainColValue);
        extSubColValue = Number(extSubColValue);

        // log.debug("COLOR ID DEBUG", "extMainColValue: " + extMainColValue + " | extSubColValue: " + extSubColValue + " | intMainColValue: " + intMainColValue + " | intSubColValue: " + intSubColValue);

        intSubColTextTemp = String(intSubColText).toLowerCase();
        intMainColTextTemp = String(intMainColText).toLowerCase();
        extMainColTextTemp = String(extMainColText).toLowerCase();
        extSubColTextTemp = String(extSubColText).toLowerCase();
        
        if ((extMainColTextTemp != '') && (extSubColTextTemp != '') && extMainColTextTemp != extSubColTextTemp) {
            mainString += extMainColText + "(" + extSubColText + ")";
        } else if (extMainColTextTemp != '') {
            mainString += extMainColText;
        } else if (extSubColTextTemp != '') {
            mainString += extSubColText;
        }

        if ((intMainColTextTemp != '') && (intSubColTextTemp != '') && intMainColTextTemp != intSubColTextTemp) {
            mainString += "/" + intMainColText + "(" + intSubColText + ")";
            flag = true;
        } else if (intMainColTextTemp != '') {
            mainString += "/" + intMainColText;
            flag = true;
        } else if (intSubColTextTemp != '') {
            mainString += "/" + intSubColText;
            flag = true;
        }
        return mainString;
    }

    function searchAllRecord(recordType, searchId, searchFilter, searchColumns) {
        try {
            var arrSearchResults = [];
            var count = 1000, min = 0, max = 1000;
            var searchObj = false;

            if (recordType == null) {
                recordType = null;
            }

            if (searchId) {
                searchObj = search.load({ id: searchId });
                if (searchFilter) {
                    searchObj.addFilters(searchFilter);
                }
                if (searchColumns) {
                    searchObj.addColumns(searchColumns);
                }
            }
            else {
                searchObj = search.create({ type: recordType, filters: searchFilter, columns: searchColumns })
            }

            var rs = searchObj.run();
            searchColumns.push(rs.columns);
            allColumns = rs.columns;

            while (count == 1000) {
                var resultSet = rs.getRange({ start: min, end: max });
                if (resultSet != null) {
                    arrSearchResults = arrSearchResults.concat(resultSet);
                    min = max;
                    max += 1000;
                    count = resultSet.length;
                }
            }
        }
        catch (e) {
            log.debug('Error searching for Assembly Item:- ', e.message);
        }
        return arrSearchResults;
    }

    function runSuiteQuery(queryName, queryString) {
        log.debug("Query String For : " + queryName + "->", queryString);
        let resultSet = query.runSuiteQL({ query: queryString });
        // log.debug("Query Mapped Data For : "+queryName+"->", resultSet.asMappedResults());
        if (resultSet && resultSet.results && resultSet.results.length > 0) {
            return resultSet.asMappedResults();
        } else {
            return [];
        }
    }

    return { beforeLoad, beforeSubmit, afterSubmit }

});
function addMultipleCurrencies_ven(type) 
{
    if (type == 'create') 
	{
        nlapiSetLineItemValue('currency', 'currency', 1, 1);
        nlapiSetLineItemValue('currency', 'currency', 2, 2);
        nlapiSetLineItemValue('currency', 'currency', 3, 6);
		nlapiSetLineItemValue('currency', 'currency', 4, 8);
		nlapiSetLineItemValue('currency', 'currency', 5, 4);
    }
}
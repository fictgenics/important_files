/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Payment Allocation PDF.js
* DEVOPS TASK: BL/59158
* AUTHOR: Akash Sharma
* DATE CREATED: 14-March-2023
* DESCRIPTION: This script is for adding button to print pdf in view mode.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 
************************************************************************************************/
define([],() => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try{
                log.debug("INSIDE USEREVENT SCRIPT!");
                let newRec = scriptContext.newRecord;

                if (scriptContext.type === scriptContext.UserEventType.VIEW) {
                    var form = scriptContext.form;                                          
                    form.addButton({
                        id : "custpage_open_pdf_button",
                        label : "Open PDF",
                        functionName : 'openPDF(' + newRec.id + ')'
                    });

                    scriptContext.form.clientScriptModulePath = "./CSS CS Payment Allocation PDF.js";                    
                  }
            }catch(e){
                log.error("Error inside before load", [e.message,e.stack]);
            }
        }

        return {beforeLoad}

    });
/**
    * @NApiVersion 2.x
    * @NScriptType UserEventScript
    * @NModuleScope SameAccount
*/
/**
    * Script Name          : CSS UE WORK ORDER PHASE  
    * Author               : Naim
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Discription          : This script link the relative work order phase and split the work order phase based on certain conditions.
    * Version              : 2.0
*/
define(['N/search', 'N/record', 'N/error', 'N/query'],

    function (search, record, error, query) {

        /**
            * Function definition to be triggered before record is loaded.
            *
            * @param {Object} scriptContext
            * @param {Record} scriptContext.newRecord - New record
            * @param {string} scriptContext.type - Trigger type
            * @param {Form} scriptContext.form - Current form
            * @Since 2015.2
        */

        function beforeSubmit(context) {
            try {
                var currentRecord = context.newRecord;
                if (context.type == context.UserEventType.CREATE) {
                    var createdFromVal = currentRecord.getText({ fieldId: 'createdfrom' });
                    log.debug("createdFromVal", createdFromVal);
                    var queryRemainAmt = 0;
                    if (createdFromVal.indexOf('Sales Order') > -1) {
                        var createdFrom = currentRecord.getValue({ fieldId: 'createdfrom' });
                        var queryString = "SELECT t.id,tl.createdfrom,qt.type ,pm.id AS pmid,pm.custrecord_c58005_milestone_remain_amt AS remainAmt FROM transaction AS t ";
                        queryString += "JOIN transactionline AS tl ON t.id = tl.transaction ";
                        queryString += "JOIN transaction as qt ON tl.createdfrom = qt.id ";
                        queryString += "JOIN customrecord_c58005_payment_milestone AS pm ON qt.id = pm.custrecord_c58005_quotation ";
                        queryString += "WHERE t.id = '" + createdFrom + "' AND tl.mainline = 'T' AND qt.type = 'Estimate' AND pm.custrecord_c58005_milestone_type = '2' AND pm.custrecord_c58005_fulfillment_request IS NULL";

                        //log.debug("queryString", queryString);
                        var queryResult = query.runSuiteQL({ query: queryString });
                        var resultValues = queryResult.asMappedResults();
                        log.debug("resultValues", resultValues);
                        if (resultValues.length > 0) {
                            var milestoneId = resultValues[0].pmid;
                            queryRemainAmt = resultValues[0].remainAmt;
                            currentRecord.setValue('custbody_c57685_payment_milestone', milestoneId);
                        }
                    }
                }
            }
            catch (e) {
                log.error('Error', e);
            }

            var tranStatus = currentRecord.getValue({ fieldId: 'transtatus' });
            log.debug("tranStatus", tranStatus);
            if (tranStatus == 'B') {
                if (parseFloat(queryRemainAmt) > 0) {
                    throw 'Work order phase payment is not completed.';
                }
                else {
                    var milestoneId = currentRecord.getValue({ fieldId: 'custbody_c57685_payment_milestone' });
                    if (milestoneId) {
                        var milestoneLookup = search.lookupFields({
                            type: 'customrecord_c58005_payment_milestone',
                            id: milestoneId,
                            columns: ['custrecord_c58005_milestone_remain_amt']
                        });

                        var remainAmount = milestoneLookup.custrecord_c58005_milestone_remain_amt;
                        if (parseFloat(remainAmount) > 0) {
                            throw 'Work order phase payment is not completed.';
                        }
                    }
                }
            }

        }

        function afterSubmit(context) {
            try {
                if (context.type == context.UserEventType.CREATE) {
                    var recObject = context.newRecord;
					var recObj = record.load({ type: 'fulfillmentrequest', id: recObject.id, isDynamic: true });
                    var milestoneId = recObj.getValue({ fieldId: 'custbody_c57685_payment_milestone' });
                    if (milestoneId) {
                        var lineCnt = recObj.getLineCount({ sublistId: 'item' });
						//log.debug("lineCnt", lineCnt);

                        var totalAmt = 0
                        var copyTotal = 0;
						var totalQty = 0;
                        for (var x = 0; x < lineCnt; x++) {
                           var quantity = recObj.getSublistValue({ sublistId: 'item', fieldId: 'quantity', line: x });
                           var itemPrice = recObj.getSublistValue({ sublistId: 'item', fieldId: 'itemunitprice', line: x });
                           var lineAmt = quantity * itemPrice;
                           totalAmt = parseFloat(totalAmt) + parseFloat(lineAmt);
						   totalQty = parseFloat(totalQty) + parseFloat(quantity);
                        }

                        var payObj = record.load({ type: 'customrecord_c58005_payment_milestone', id: milestoneId, isDynamic: true });
                        var milestoneAmount = payObj.getValue({ fieldId: 'custrecord_c58005_milestone_amount' });
                        var milestonePerct = payObj.getValue({ fieldId: 'custrecord_c58005_milestone' });
                        var quoteId = payObj.getValue({ fieldId: 'custrecord_c58005_quotation' });
						var milestoneQty = payObj.getValue({ fieldId: 'custrecord_c58005_quantity' });
                        log.debug("milestoneQty", milestoneQty);

                        copyTotal = totalAmt;
                        totalAmt = totalAmt * milestonePerct / 100;
                        log.debug("totalAmt", totalAmt);
						log.debug("totalQty", totalQty);


                        if (parseFloat(milestoneQty) > parseFloat(totalQty)) {
                            var existApplied = 0;
                            var forwardApplied = 0;
                            var appliedAmt = payObj.getValue({ fieldId: 'custrecord_c58005_milestone_applied_amt' });
                            if (appliedAmt && appliedAmt != 0) {
                                if (parseFloat(totalAmt) > parseFloat(appliedAmt)) {
                                    existApplied = appliedAmt;
                                }
                                else {
                                    existApplied = totalAmt;
                                    forwardApplied = appliedAmt - totalAmt;
                                }
                            }

                            var remainingAmt = totalAmt - existApplied;

                            payObj.setValue({ fieldId: 'custrecord_c58005_milestone_amount', value: totalAmt, ignoreFieldChange: true });
                            payObj.setValue({ fieldId: 'custrecord_c58005_milestone_applied_amt', value: existApplied, ignoreFieldChange: true });
                            payObj.setValue({ fieldId: 'custrecord_c58005_milestone_remain_amt', value: remainingAmt, ignoreFieldChange: true });
							payObj.setValue({ fieldId: 'custrecord_c58005_quantity', value: totalQty, ignoreFieldChange: true });
                            payObj.setValue({ fieldId: 'custrecord_c58005_fulfillment_request', value: recObj.id, ignoreFieldChange: true });
                            payObj.save({ ignoreMandatoryFields: true });

                            // New split record create for work order phase
                            var objRecord = record.copy({
                                type: 'customrecord_c58005_payment_milestone',
                                id: milestoneId,
                                isDynamic: true
                            });

                            var newAmount = milestoneAmount - totalAmt;
                            var milestoneName = payObj.getValue({ fieldId: 'name' });
                            var nameArray = milestoneName.split('_');
                            if (nameArray.length > 2) {
                                var LastCnt = nameArray[nameArray.length - 1];
                                var newCnt = Number(LastCnt) + 1;
                                milestoneName = nameArray[0] + '_' + nameArray[1] + '_' + newCnt;
                            }
                            else {
                                milestoneName = milestoneName + '_1';
                            }

                            var newRemainAmt = newAmount - forwardApplied;
							var newQty = milestoneQty - totalQty;  
							
                            objRecord.setValue({ fieldId: 'name', value: milestoneName, ignoreFieldChange: true });
                            objRecord.setValue({ fieldId: 'custrecord_c58005_milestone_amount', value: newAmount, ignoreFieldChange: true });
                            objRecord.setValue({ fieldId: 'custrecord_c58005_milestone_applied_amt', value: forwardApplied, ignoreFieldChange: true });
                            objRecord.setValue({ fieldId: 'custrecord_c58005_milestone_remain_amt', value: newRemainAmt, ignoreFieldChange: true });
							objRecord.setValue({ fieldId: 'custrecord_c58005_quantity', value: newQty, ignoreFieldChange: true });
                            objRecord.setValue({ fieldId: 'custrecord_c58005_fulfillment_request', value: '', ignoreFieldChange: true });
                            var newRecId = objRecord.save({ ignoreMandatoryFields: true });
                            log.debug("newRecId", newRecId);

                            var customrecord_c58005_payment_milestoneSearchObj = search.create({
                                type: "customrecord_c58005_payment_milestone",
                                filters:
                                    [
                                        ["custrecord_c58005_quotation", "anyof", quoteId],
                                        "AND",
                                        ["custrecord_c58005_milestone_type", "anyof", "1", "3", "4"],
                                        "AND",
                                        ["custrecord_c58005_fulfillment_request", "anyof", "@NONE@"]
                                    ],
                                columns:
                                    [
                                        search.createColumn({ name: "internalid", label: "Internal ID" }),
                                        search.createColumn({ name: "custrecord_c58005_milestone_amount", label: "custrecord_c58005_milestone_amount" }),
                                        search.createColumn({ name: "custrecord_c58005_milestone", label: "custrecord_c58005_milestone" }),
                                        search.createColumn({ name: "name", label: "name" }),
                                        search.createColumn({ name: "custrecord_c58005_milestone_type", label: "custrecord_c58005_milestone_type" }),
                                        search.createColumn({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" }),
										search.createColumn({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" })
                                    ]
                            });
                            var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                            log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

                            //This loop always contains only 3 data
                            customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                                var milestoneIds = result.getValue({ name: "internalid", label: "Internal ID" });
                                var milestoneAmt = result.getValue({ name: "custrecord_c58005_milestone_amount", label: "custrecord_c58005_milestone_amount" });
                                var milestonePercent = result.getValue({ name: "custrecord_c58005_milestone", label: "custrecord_c58005_milestone" });
                                var extractPercent = milestonePercent.substring(0, milestonePercent.length - 1);
                                var milestoneNaming = result.getValue({ name: "name", label: "name" });
                                var milestoneType = result.getValue({ name: "custrecord_c58005_milestone_type", label: "custrecord_c58005_milestone_type" });
                                var appliedTO = result.getValue({ name: "custrecord_c58005_milestone_applied_amt", label: "custrecord_c58005_milestone_applied_amt" });
								var milestoneQuantity = result.getValue({ name: "custrecord_c58005_quantity", label: "custrecord_c58005_quantity" });
								
                                log.debug("milestoneIds", milestoneIds);
                                log.debug("milestoneAmt", milestoneAmt);
                                log.debug("extractPercent", extractPercent);
                                log.debug("milestoneNaming", milestoneNaming);
                                log.debug("milestoneType", milestoneType);
                                log.debug("copyTotal", copyTotal);
                                log.debug("appliedTO", appliedTO);
								log.debug("milestoneQuantity", milestoneQuantity);

                                var finalTotal = copyTotal * extractPercent / 100;
                                log.debug("finalTotal", finalTotal);

                                var copyExistApplied = 0;
                                var copyForwardApplied = 0;
                                if (appliedTO && appliedTO != 0) {
                                    if (parseFloat(finalTotal) > parseFloat(appliedTO)) {
                                        copyExistApplied = appliedTO;
                                    }
                                    else {
                                        copyExistApplied = finalTotal;
                                        copyForwardApplied = appliedTO - finalTotal;
                                    }
                                }

                                var copyRemainingAmt = finalTotal - copyExistApplied;

                                record.submitFields({
                                    type: 'customrecord_c58005_payment_milestone',
                                    id: milestoneIds,
                                    values: {
                                        custrecord_c58005_milestone_amount: finalTotal,
                                        custrecord_c58005_milestone_applied_amt: copyExistApplied,
                                        custrecord_c58005_milestone_remain_amt: copyRemainingAmt,
										custrecord_c58005_quantity: totalQty,
                                        custrecord_c58005_fulfillment_request: recObj.id
                                    },
                                    options: {
                                        enableSourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });

                                // New split record created for delivery phase and post delivery
                                var objRec = record.copy({
                                    type: 'customrecord_c58005_payment_milestone',
                                    id: milestoneIds,
                                    isDynamic: true
                                });

                                var newAmt = milestoneAmt - finalTotal;
                                var nameArray = milestoneNaming.split('_');
                                if (nameArray.length > 2) {
                                    var LastCnt = nameArray[nameArray.length - 1];
                                    var newCnt = Number(LastCnt) + 1;
                                    milestoneNaming = nameArray[0] + '_' + nameArray[1] + '_' + newCnt;
                                }
                                else {
                                    milestoneNaming = milestoneNaming + '_1';
                                }

                                var copyNewRemainAmt = newAmt - copyForwardApplied;
                                objRec.setValue({ fieldId: 'name', value: milestoneNaming, ignoreFieldChange: true });
                                objRec.setValue({ fieldId: 'custrecord_c58005_milestone_amount', value: newAmt, ignoreFieldChange: true });
                                objRec.setValue({ fieldId: 'custrecord_c58005_milestone_applied_amt', value: copyForwardApplied, ignoreFieldChange: true });
                                objRec.setValue({ fieldId: 'custrecord_c58005_milestone_remain_amt', value: copyNewRemainAmt, ignoreFieldChange: true });
								objRec.setValue({ fieldId: 'custrecord_c58005_quantity', value: newQty, ignoreFieldChange: true });
                                objRec.setValue({ fieldId: 'custrecord_c58005_fulfillment_request', value: '', ignoreFieldChange: true });
                                var newRecId = objRec.save({ ignoreMandatoryFields: true });
                                log.debug("newRecId", newRecId);

                                return true;
                            });
                        }
                        else {
                            payObj.setValue({ fieldId: 'custrecord_c58005_fulfillment_request', value: recObj.id, ignoreFieldChange: true });
                            payObj.save({ ignoreMandatoryFields: true });

                            var customrecord_c58005_payment_milestoneSearchObj = search.create({
                                type: "customrecord_c58005_payment_milestone",
                                filters:
                                    [
                                        ["custrecord_c58005_quotation", "anyof", quoteId],
                                        "AND",
                                        ["custrecord_c58005_milestone_type", "anyof", "1", "3", "4"],
                                        "AND",
                                        ["custrecord_c58005_fulfillment_request", "anyof", "@NONE@"]
                                    ],
                                columns:
                                    [
                                        search.createColumn({ name: "internalid", label: "Internal ID" })
                                    ]
                            });
                            var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                            log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);

                            //This loop always contains only 3 data
                            customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                                var milestoneIds = result.getValue({ name: "internalid", label: "Internal ID" });
                                record.submitFields({
                                    type: 'customrecord_c58005_payment_milestone',
                                    id: milestoneIds,
                                    values: {
                                        custrecord_c58005_fulfillment_request: recObj.id
                                    },
                                    options: {
                                        enableSourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });
                                return true;
                            });
                        }
                    }
                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }

        return {
            beforeSubmit: beforeSubmit,
            afterSubmit: afterSubmit
        };

    });	
/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/*****************************************************************************
 *  * Copyright (c) 2023 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: 
* DEVOPS TASK: ----
* AUTHOR: Akash Sharma
* DATE MODIFIED: 
* DESCRIPTION:                       
*****************************************************************************/
define(['N/record', 'N/redirect'], (record, redirect) => {
    /**
     * Defines the function definition that is executed before record is loaded.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @param {Form} scriptContext.form - Current form
     * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
     * @since 2015.2
     */
    const beforeLoad = (scriptContext) => {
    }

    /**
     * Defines the function definition that is executed before record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const beforeSubmit = (scriptContext) => {


    }

    /**
     * Defines the function definition that is executed after record is submitted.
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
     * @since 2015.2
     */
    const afterSubmit = (scriptContext) => {
        try {
            if (scriptContext.type === scriptContext.UserEventType.EDIT) {
                var qualityDataArr = [];
                log.debug("STARTED");
                var qualitySpecsArr = [];
                var itemReceipt = scriptContext.newRecord;
                var irLineCount = itemReceipt.getLineCount({ sublistId: 'item' });
                var location = itemReceipt.getValue({ fieldId: 'location' });
                var createdFrom = itemReceipt.getValue({ fieldId: 'createdfrom' });
                log.debug("DEBUG", "irLineCount: " + irLineCount + " || location: " + location + " || createdFrom: " + createdFrom);

                var actualQualityLine = itemReceipt.getValue({fieldId: 'custbody_actual_quality_line'});

                for (var i = actualQualityLine; i < irLineCount; i++) {
                    var currentItem = itemReceipt.getSublistValue({ sublistId: 'item', fieldId: 'item', line: i });
                    var currentItemName = itemReceipt.getSublistText({ sublistId: 'item', fieldId: 'itemname', line: i });
                    log.debug("DEBUG", "currentItem: " + currentItem + " || currentItemName: " + currentItemName);

                    var qualitySpecContext = record.create({ type: 'customrecord_qm_quality_item_spec' });

                    qualitySpecContext.setValue({ fieldId: 'custrecord_qm_item_spec_item', value: currentItem });
                    qualitySpecContext.setValue({ fieldId: 'custrecord_qm_item_spec_location', value: location });
                    qualitySpecContext.setValue({ fieldId: 'custrecord_qm_item_spec_context', value: 1 });
                    // qualitySpecContext.setValue({fieldId: 'custrecord_qm_item_spec_action', value: 8});
                    qualitySpecContext.setValue({ fieldId: 'custrecord_qm_item_spec_default', value: true });
                    // qualitySpecContext.setValue({fieldId: 'customform', value: 106});

                    var qualitySpecification = record.create({ type: 'customrecord_qm_quality_specification' });
                    qualitySpecification.setValue({ fieldId: 'name', value: "Purchase Receipt Inspection for Item ID: (" + currentItem + ")" });
                    qualitySpecification.setValue({ fieldId: 'custrecord_qm_spec_description', value: "Test done on date :" + new Date() });
                    var savedQualitySpecification = qualitySpecification.save();
                    log.debug("savedQualitySpecification", savedQualitySpecification);

                    if (savedQualitySpecification) {
                        qualitySpecContext.setValue({ fieldId: 'custrecord_qm_item_spec', value: savedQualitySpecification });
                        var savedQualitySpecContext = qualitySpecContext.save();
                        log.debug("savedQualitySpecContext", savedQualitySpecContext);


                        for (var j = 1; j <= 4; j++) {
                            var qualitySpecificationInspection = record.create({ type: 'customrecord_qm_applied_inspections' });
                            qualitySpecificationInspection.setValue({ fieldId: 'custrecord_qm_applied_insp_specification', value: savedQualitySpecification });
                            qualitySpecificationInspection.setValue({ fieldId: 'custrecord_qm_applied_insp_inspection', value: 1 });
                            qualitySpecificationInspection.setValue({ fieldId: 'custrecord_qm_applied_insp_seq', value: j });
                            qualitySpecificationInspection.setValue({ fieldId: 'custrecord_qm_applied_insp_method', value: 1 });
                            qualitySpecificationInspection.setValue({ fieldId: 'custrecord_qm_action_type_qsi', value: j });
                            var savedQualitySpecificationInspection = qualitySpecificationInspection.save();
                            log.debug("savedQualitySpecificationInspection", savedQualitySpecificationInspection);

                            qualitySpecsArr.push(savedQualitySpecificationInspection);
                        }
                    }
                    log.debug("qualitySpecsArr", qualitySpecsArr);

                    var qualityInspectionQueue = record.create({ type: 'customrecord_qm_queue' });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_spec', value: savedQualitySpecification });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_item', value: currentItem });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_transaction', value: createdFrom });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_status', value: 1 });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_location', value: location });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_queue_transaction_inv', value: itemReceipt.id });
                    qualityInspectionQueue.setValue({ fieldId: 'custrecord_qm_setting_record', value: qualitySpecsArr });
                    var savedQualityInspectionQueue = qualityInspectionQueue.save();
                    log.debug("savedQualityInspectionQueue", savedQualityInspectionQueue);


                    for (var j = 1; j <= 4; j++) {
                        var qualityData = record.create({ type: 'customrecord_qm_quality_data' });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_queue', value: savedQualityInspectionQueue });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_target', value: savedQualitySpecification });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_inspection', value: 1 });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_transaction', value: itemReceipt.id });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_datetime', value: new Date() });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_item', value: currentItem });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_status', value: 1 });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_parent', value: createdFrom });
                        qualityData.setValue({ fieldId: 'custrecord_qm_quality_data_sequence', value: j });
                        qualityData.setValue({ fieldId: 'custrecord_qm_action_type', value: j });
                        var savedQualityData = qualityData.save();
                        log.debug("savedQualityData", savedQualityData);
                        qualityDataArr.push(savedQualityData);

                    }
                    break;
                }
                log.debug("ENDED!");

                if (qualityDataArr.length > 0) {
                    var qualityDataString = qualityDataArr.join(",");
                    log.debug("qualityDataString", qualityDataString);

                    redirect.toSuitelet({
                        scriptId: 'customscript_css_su_trigger_qdd',
                        deploymentId: 'customdeploy_css_su_trigger_qdd',
                        isExternal: false,
                        parameters: {
                            qualityDataArr: qualityDataString
                        }
                    });
                }

                log.debug("CALLED SUITELET!");
            }
        } catch (e) {
            log.error("Error Inside before Submit", e.message);
        }
    }

    return { beforeLoad, beforeSubmit, afterSubmit }

});

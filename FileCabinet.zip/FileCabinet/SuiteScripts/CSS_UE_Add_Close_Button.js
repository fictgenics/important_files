/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME:CSS_UE_Add_Close_Button.js
* DEVOPS TASK: ENH/, BL/72172
* AUTHOR: Shalini Srivastava
* DATE CREATED: 4 March,2024
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
define(['N/record', 'N/url', 'N/ui/serverWidget'], (record, url, serverWidget) => {
    const beforeLoad = (context) => {
        try {
            if (context.type ==  context.UserEventType.VIEW) {
                var recordOrder = context.newRecord;
                var recId   = recordOrder.id;
                var status = recordOrder.getValue({
                    fieldId:'orderstatus'
                }); 
				context.form.removeButton('closeremaining');
				context.form.removeButton('createdeposit');
                if(status != 'F' || status != 'G'){
                    var lineCount = recordOrder.getLineCount({sublistId: 'item'});
                    if(lineCount>0){
                        for(var iter=0; iter<lineCount; iter++){
                            var quantityPicked = recordOrder.getSublistValue({sublistId: 'item',fieldId: 'quantitypicked',line:iter});
                            var quantityPacked = recordOrder.getSublistValue({sublistId: 'item',fieldId: 'quantitypacked',line:iter});
                            var quantityFulfilled = recordOrder.getSublistValue({sublistId: 'item',fieldId: 'quantityfulfilled',line:iter});
                            var inventoryDetail = recordOrder.getSublistValue({sublistId: 'item',fieldId: 'inventorydetail',line:iter});
                           // log.debug('DEBUG','quantityPicked: '+quantityPicked+'==='+'quantityPacked: '+quantityPacked+'==='+'quantityFulfilled: '+quantityFulfilled);
                           if(!isNotNull(quantityPicked) && !isNotNull(quantityPacked) && !isNotNull(quantityFulfilled) && isNotNull(inventoryDetail)){
                                
								context.form.addButton({
                                    id: 'custpage_close',
                                    label: 'Close',
                                    functionName: 'releaseInventory('+recId+');'
                                });
                                context.form.clientScriptModulePath = "./CSS_CS_Release_Inventory.js";
                                break;
                            }
                        }
                    }
                }
            }

        } catch (err) {
            log.error("Error in beforeload", err);
        }
    }
    function isNotNull(aVal)
	{
		if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
			return true;
		else
			return false;
	}
    return { beforeLoad }
});
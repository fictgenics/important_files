/**
 *@NApiVersion 2.x
 *@NScriptType UserEventScript 
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH 57685,DT/57686
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: This script is used to add 'Approve' button and also send email if user approve the Quotation.
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
define(['N/record', 'N/search', 'N/log','N/render', 'N/file','N/email','N/ui/serverWidget'],function(record,search,log,render, file,email,serverWidget){
	
	function beforeLoad(context){
		var form = context.form;
		var expClose = form.getField({
			id: 'expectedclosedate'
		});
		expClose.updateDisplayType({
			displayType : serverWidget.FieldDisplayType.DISABLED
		});
				
				
		if(context.type == 'view'){
			var recordOrder = context.newRecord;
			var status = recordOrder.getValue({
				 fieldId:'entitystatus'
			 });
			// if(status == 17){
				// context.form.addButton({
				// 	id: 'custpage_approve',
				// 	label: 'Approve',
				// 	functionName: 'onApproveButton'
				// });
				context.form.clientScriptModulePath = "./CSS_CS_Show_Alert_For_Same_Bin.js";
			//}
		}
	}
	function beforeSubmit(context)
	{
		try {
			if(context.type != 'create'){
				return;
			}
			 var recordOrder = context.newRecord;
			 var tranDate = recordOrder.getValue({
				 fieldId:'trandate'
			 });
			 var count = recordOrder.getLineCount({
				sublistId: 'item'
			 });
			
			 if(count > 0) {
				 var inventorySet = recordOrder.getSublistValue({
					 sublistId: 'item',
					 fieldId: 'inventorydetailset',
					 line: 0
				 });
				 log.debug('DEBUG','inventorySet: '+inventorySet);
				 var expdate;
				 var addDate;
				 if(inventorySet == 'T'){
					 addDate = 2;
					 expdate = getNextDay(tranDate,addDate);
				 }
				 else{
					 addDate = 7;
					 expdate = getNextDay(tranDate,addDate);
				 }
				 log.debug('DEBUG','expdate: '+expdate);
				 recordOrder.setValue({
					 fieldId:'expectedclosedate',
					 value:expdate
				 });
			 }
		} catch(e) {
			log.error('ERROR','Exception: ' + e.toString());
		}
	}
	function afterSubmit(context)
	{
		try {
			
			var currentRecord 	= context.newRecord;
			var quotationId		= currentRecord.id;
			log.debug('DEBUG','quotationId: '+quotationId);
			
			var emailSent = currentRecord.getValue({
				fieldId:'custbody_email_sent'
			});
			var tranId = currentRecord.getValue({
				fieldId:'tranid'
			});
			var status = currentRecord.getValue({
				fieldId:'entitystatus'
			});
			log.debug('DEBUG','emailSent: '+emailSent+'==='+'status: '+status);
			if(emailSent == false && status == 18){
			
				var customer = currentRecord.getValue({
					fieldId:'entity'
				}); 
				var customerLookUp = search.lookupFields({
					type: 'customer',
					id: customer,
					columns: ['email']
				});
				var custEmail = customerLookUp.email;
				
				var body = "<p style='margin-bottom: .0001pt;'>Hello,</p>\
				<br><br><p>Your Quotation has been approved.</p>\
				<br><br><p style='line-height: 5px;'>Thank you,</p>"
				log.debug('DEBUG','custEmail: '+custEmail);
				
				if(custEmail){
					var sender = 37680;
					var transactionFile = render.transaction({
						entityId: quotationId,
						printMode: render.PrintMode.PDF,
						inCustLocale: true
					});
					email.send({
						author: sender,
						recipients: custEmail,
						subject: 'Quotation is approved',
						body:body,
						attachments: [transactionFile],
						relatedRecords: {transactionId:parseInt(quotationId)}
					});
					record.submitFields({
						type: 'estimate',
						id: quotationId,
						values: {
							'custbody_email_sent': true
						}
					});	
				}
			}
		} catch(e) {
			log.error('ERROR','Exception:' + e.toString());
		}
					
	}
	function getNextDay(d,date){
		var newDate = new Date(d.setDate(d.getDate() + parseInt(date)))
		return newDate;
	}	
	return{
		beforeLoad:beforeLoad,
		afterSubmit:afterSubmit,
		beforeSubmit:beforeSubmit
	};
});

function isNotNull(aVal)
{
	if(aVal && aVal != 'undefined' && aVal != null && aVal != '')
	return true;
	else
	return false;
}
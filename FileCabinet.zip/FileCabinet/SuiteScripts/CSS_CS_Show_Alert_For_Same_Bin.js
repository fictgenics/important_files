/**
 * @NApiVersion 2.0
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH 57685,DT/
* AUTHOR: Shalini Srivastava
* DATE CREATED: 1/Feb/2022
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/ 
 define(['N/currentRecord','N/search','N/record'],
 
	function(currentRecord,search,record) { 
		
		function pageInit(context) {
			
		}
		function onVerifyLimitButton(){
			var rec = currentRecord.get();
			var creditLimit = rec.id;
			rec.getValue({
				fieldId: 'creditlimit'
			});
			if(creditLimit>0){
				var resp = confirm('Do you want to convert?');
				
				if(!resp)
				{
					window.location.reload();
					return false;
				}
			}
			return true;

		}		
		 return {
			pageInit:pageInit,
			onVerifyLimitButton:onVerifyLimitButton
		}
		
	
		function getNumber(id) {
			var ret;
			ret = parseFloat(id);
			if(isNaN(ret)) {
				ret = 0;
			}
			return ret;
		}
		
		function isNotNull(aString) {
			
			if(aString && aString !== 'undefined' && aString !== null && aString !== '' && aString !== 'null')
				return true;
			else
				return false;
		}
		
		
	}
 );
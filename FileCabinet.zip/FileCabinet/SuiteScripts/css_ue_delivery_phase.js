/**
    * @NApiVersion 2.x
    * @NScriptType UserEventScript
    * @NModuleScope SameAccount
*/
/**
    * Script Name          : CSS UE WORK ORDER PHASE  
    * Author               : Naim
    * Start Date           : Feb 2023
    * Last Modified Date   : 
    * Discription          : This script link the relative work order phase and split the work order phase based on certain conditions.
    * Version              : 2.0
*/
define(['N/search', 'N/error', 'N/record'],

    function (search, error, record) {

        /**
            * Function definition to be triggered before record is loaded.
            *
            * @param {Object} scriptContext
            * @param {Record} scriptContext.newRecord - New record
            * @param {string} scriptContext.type - Trigger type
            * @param {Form} scriptContext.form - Current form
            * @Since 2015.2
        */

        function beforeLoad(context) {

            var currentRecord = context.newRecord;
            if (context.type == context.UserEventType.CREATE) {
			    var recObj = context.newRecord;
				var lineCnt = recObj.getLineCount({ sublistId: 'item' });
                log.debug('lineCnt', lineCnt);
				var inventoryNotSet= false;
				for (var x = 0; x < lineCnt; x++) {
					var inventorySet = recObj.getSublistValue({ sublistId: 'item', fieldId: 'inventorydetailset', line: x });
					var inventoryReq = recObj.getSublistValue({ sublistId: 'item', fieldId: 'inventorydetailreq', line: x });
					log.debug('DEBUG', 'inventorySet: '+inventorySet+'==='+'inventoryReq: '+inventoryReq);
					if(inventorySet == 'F' && inventoryReq == 'T'){inventoryNotSet= true;}
				}
				if(inventoryNotSet){
					throw "Please set inventory details on sales order record.";
				}
                var requestedBy = currentRecord.getText({ fieldId: 'requestedby' });
                log.debug("requestedBy", requestedBy);

                if (requestedBy.indexOf('Fulfillment Request') > -1) {
                    var requestedByValue = currentRecord.getValue({ fieldId: 'requestedby' });
                    var customrecord_c58005_payment_milestoneSearchObj = search.create({
                        type: "customrecord_c58005_payment_milestone",
                        filters:
                            [
                                ["custrecord_c58005_milestone_type", "anyof", "3"],
                                "AND",
                                ["custrecord_c58005_fulfillment_request", "anyof", requestedByValue],
                                "AND",
                                ["custrecord_c58005_milestone_remain_amt", "equalto", "0.00"]
                            ],
                        columns:
                            [
                                search.createColumn({ name: "internalid", label: "Internal ID" }),
                                search.createColumn({ name: "custrecord_c58005_milestone_remain_amt", label: "Milestone Remaining Amount" })
                            ]
                    });
                    var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                    log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
                    if (searchResultCount == 0) {
                        throw "Delivery Payment is not completed."
                    }

                }

                var customerId = Number(currentRecord.getValue({ fieldId: 'entity' }));
                if (customerId) {

                    var fieldLookup = search.lookupFields({
                        type: search.Type.CUSTOMER,
                        id: customerId,
                        columns: ['balance']
                    });

                    var balance = fieldLookup.balance;
                    log.debug("balance", balance);

                    if (balance && (Number(balance) > 0)) {
                        //throw "Balance Amount of current customer is greater than 0.0!"
                    }
                }
            }
        }


        function afterSubmit(context) {
            try {
                var recObj = context.newRecord;
                if (context.type == context.UserEventType.CREATE) {
                    var requestedByValue = recObj.getValue({ fieldId: 'requestedby' });
                    log.debug("requestedByValue", requestedByValue);

                    if (requestedByValue) {
                        var customrecord_c58005_payment_milestoneSearchObj = search.create({
                            type: "customrecord_c58005_payment_milestone",
                            filters:
                                [
                                    ["custrecord_c58005_fulfillment_request", "anyof", requestedByValue]
                                ],
                            columns:
                                [
                                    search.createColumn({ name: "internalid", label: "Internal ID" })
                                ]
                        });

                        var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                        log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
                        // This loop not having more than 4 results
                        customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                            var milestoneId = result.getValue({ name: "internalid", label: "Internal ID" });
                            record.submitFields({
                                type: 'customrecord_c58005_payment_milestone',
                                id: milestoneId,
                                values: {
                                    custrecord_c58005_item_fulfillment: recObj.id
                                },
                                options: {
                                    enableSourcing: true,
                                    ignoreMandatoryFields: true
                                }
                            });
                            return true;
                        });
                    }
                }

                var shipStatus = recObj.getValue({ fieldId: 'shipstatus' });
                var invoice = recObj.getValue({ fieldId: 'custbody_c57685_invoice' });
                log.debug("shipStatus", shipStatus);
                log.debug("invoice", invoice);
                if (!invoice && shipStatus == 'C') {
                    var createdFromText = recObj.getText({ fieldId: 'createdfrom' });
                    log.debug("createdFromText", createdFromText);
                    if (createdFromText.indexOf('Sales Order') > -1) {
                        var soId = recObj.getValue({ fieldId: 'createdfrom' });
                        var invoiceObj = record.transform({ fromType: 'salesorder', fromId: soId, toType: 'invoice', isDynamic: true });
                        invoiceObj.setValue({ fieldId: 'custbody_c57685_item_fulfillment', value: recObj.id, ignoreFieldChange: false });
                        invoiceObj.setValue({ fieldId: 'approvalstatus', value: 2, ignoreFieldChange: false });
                        var lineCnt = invoiceObj.getLineCount({ sublistId: 'item' });
                        log.debug('lineCnt', lineCnt);

                        var j = 0;
                        for (var x = 0; x < lineCnt; x++) {
                            var orderLine = invoiceObj.getSublistValue({ sublistId: 'item', fieldId: 'orderline', line: j });
                            log.debug('orderLine', orderLine);
                            var lineNumber = recObj.findSublistLineWithValue({ sublistId: 'item', fieldId: 'orderline', value: orderLine });
                            log.debug('lineNumber', lineNumber);
                            if (lineNumber > -1) {
                                j++;
                            }
                            else {
                                invoiceObj.removeLine({ sublistId: 'item', line: j });
                            }
                        }

                        var finalCnt = invoiceObj.getLineCount({ sublistId: 'item' });
                        log.debug('finalCnt', finalCnt);
                        if (finalCnt > 0) {
                            var invoiceId = invoiceObj.save({ ignoreMandatoryFields: true });
                            log.debug('invoiceId', invoiceId);

                            if (invoiceId) {
                                record.submitFields({
                                    type: 'itemfulfillment',
                                    id: recObj.id,
                                    values: {
                                        custbody_c57685_invoice: invoiceId
                                    },
                                    options: {
                                        enableSourcing: true,
                                        ignoreMandatoryFields: true
                                    }
                                });

                                var customrecord_c58005_payment_milestoneSearchObj = search.create({
                                    type: "customrecord_c58005_payment_milestone",
                                    filters:
                                        [
                                            ["custrecord_c58005_item_fulfillment", "anyof", recObj.id]
                                        ],
                                    columns:
                                        [
                                            search.createColumn({ name: "internalid", label: "Internal ID" })
                                        ]
                                });

                                var searchResultCount = customrecord_c58005_payment_milestoneSearchObj.runPaged().count;
                                log.debug("customrecord_c58005_payment_milestoneSearchObj result count", searchResultCount);
                                // This loop not having more than 4 results
                                customrecord_c58005_payment_milestoneSearchObj.run().each(function (result) {
                                    var milestoneId = result.getValue({ name: "internalid", label: "Internal ID" });
                                    record.submitFields({
                                        type: 'customrecord_c58005_payment_milestone',
                                        id: milestoneId,
                                        values: {
                                            custrecord_c58005_invoice: invoiceId
                                        },
                                        options: {
                                            enableSourcing: true,
                                            ignoreMandatoryFields: true
                                        }
                                    });
                                    return true;
                                });

                                var paymentObj = record.transform({ fromType: 'invoice', fromId: invoiceId, toType: 'customerpayment', isDynamic: true });
                                var remainAmt = paymentObj.getValue({ fieldId: 'payment' });
                                log.debug('remainAmt', remainAmt);

                                var lineCount = paymentObj.getLineCount({ sublistId: 'deposit' });
                                log.debug('lineCount', lineCount);

                                for (var z = 0; z < lineCount; z++) {
                                    var lineNum = paymentObj.selectLine({ sublistId: 'deposit', line: z });
                                    var lineRemain = lineNum.getCurrentSublistValue({ sublistId: 'deposit', fieldId: 'remaining' });
                                    //log.debug('lineRemain', lineRemain);

                                    if (parseFloat(lineRemain) > parseFloat(remainAmt)) {
                                        lineNum.setCurrentSublistValue({ sublistId: 'deposit', fieldId: 'apply', value: true });
                                        lineNum.setCurrentSublistValue({ sublistId: 'deposit', fieldId: 'amount', value: remainAmt });
                                        lineNum.commitLine({ sublistId: 'deposit' });
                                        remainAmt = 0;
                                    }
                                    else {
                                        lineNum.setCurrentSublistValue({ sublistId: 'deposit', fieldId: 'apply', value: true });
                                        lineNum.commitLine({ sublistId: 'deposit' });
                                        remainAmt = remainAmt - lineRemain;

                                    }
                                    //log.debug('remainAmt', remainAmt);
                                    if (parseFloat(remainAmt) <= 0) { //log.debug('z', z);
                                        break;
                                    }
                                }

                                var paymentId = paymentObj.save({ ignoreMandatoryFields: true });
                                log.debug('paymentId', paymentId);
                            }
                        }
                    }

                }
            }
            catch (e) {
                log.error('Error', e);
            }
        }

        return {
            beforeLoad: beforeLoad,
            afterSubmit: afterSubmit
        };

    });	
/**
 * @NApiVersion 2.0
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */
/*****************************************************************************
 *  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Crowe LLP. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: 
* DEVOPS TASK: ENH ,DT/
* AUTHOR: 
* DATE CREATED: 
* DESCRIPTION: 
* REVISION HISTORY
* Date          DevOps item No.    By                      Issue Fix Summary   
*============================================================================                  
*****************************************************************************/

define(['N/ui/serverWidget', 'N/search', 'N/record'],

    function (serverWidget, search, record) {

        function capitalizationForm(context) {

            try {
                var request = context.request;
                var response = context.response;
                var custId = request.parameters.custscript_customer;


                log.debug('DEBUG', 'custId: ' + custId);
                custId = parseInt(custId);
                // if(request.method == 'GET'){ 

                var serachObj = search.create({
                    type: "customrecord_c58005_payment_milestone",
                    filters:
                        [
                            ["custrecord_c58005_customer.creditlimit", "greaterthan", "0.00"],
                            "AND",
                            ["custrecord_c58005_customer", "anyof", custId],
                            "AND",
                            ["custrecord_c58005_milestone_type", "anyof", "1"], "AND", ["custrecord_c58005_quotation.status", "anyof", "Estimate:A"],
                            "AND",
                            ["custrecord_c58005_quotation.mainline", "is", "T"]
                        ],
                    columns:
                        [
                            search.createColumn({ name: "internalid", label: "internalid" }),
                            search.createColumn({ name: "custrecord_c58005_quotation", label: "custrecord_c58005_quotation" })
                        ]
                });
                var searchResult = serachObj.run().getRange(0, 1000);

                if (searchResult != null && searchResult != 0) {
                    log.debug('DEBUG', 'searchResult: ' + searchResult.length);
                    for (var aa = 0; aa < searchResult.length; aa++) {
                        var quotation = searchResult[aa].getValue({ name: 'custrecord_c58005_quotation' });
						var quotationPayment = searchResult[aa].getValue({ name: 'internalid' });

                        if (quotation) {
                            var estimateRec = record.transform({
                                fromType: record.Type.ESTIMATE,
                                fromId: quotation,
                                toType: record.Type.SALES_ORDER,
                                isDynamic: true,
                            });
                            var soId = estimateRec.save({
                                ignoreMandatoryFields: true
                            });
                            log.debug('DEBUG', 'soId: ' + soId);

                            if (soId) {
                                var customrecord_c58005_dep_paymt_milestoneSearchObj = search.create({
                                    type: "customrecord_c58005_dep_paymt_milestone",
                                    filters:
                                        [
                                            ["custrecord_c58005_quote_milestone", "anyof", quotationPayment]
                                        ],
                                    columns:
                                        [
                                            search.createColumn({ name: "internalid", label: "Internal ID" })
                                        ]
                                });
                                var searchResultCount = customrecord_c58005_dep_paymt_milestoneSearchObj.runPaged().count;
                                log.debug('searchResultCount', searchResultCount);
                                if (searchResultCount > 0) {
									var searchResultObj = customrecord_c58005_dep_paymt_milestoneSearchObj.run().getRange(0, 1);
									var recId  = searchResultObj[0].getValue({ name: "internalid", label: "Internal ID" }); 
                                    record.submitFields({
                                        type: 'customrecord_c58005_dep_paymt_milestone',
                                        id: recId,
                                        values: {
                                            'custrecord_c58005_dep_salesorder': soId
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
                // }
            } catch (e) {
                log.error('ERROR', 'Exception in capitalization Page: Exception: ' + e.toString());
            }
        }

        return {
            onRequest: capitalizationForm
        };
    }
);
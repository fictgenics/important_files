function createForm(request,response){
    try {
        if(request.getMethod()=="GET"){
            var form = nlapiCreateForm("Vistor Form");
            form.addField("custpage_name","text","Visitor Name");
            form.addField("custpage_phone_number","text","Phone Number");
            form.addField("custpage_purpose","select","Purpose Of Vist","customlist_purpose");
            form.addSubmitButton("Submit");
            response.writePage(form);
        }else{
            if(request.getMethod()=="POST"){
                var visitor_purpose = request.getParameter("custpage_purpose");
                
                var visitor_name = request.getParameter("custpage_name");
                var visitor_number = request.getParameter("custpage_phone_number");
                var recObj = nlapiCreateRecord("customrecord_visitor_log");   
                recObj.setFieldValue("custrecord_purpose_visit",visitor_purpose);
                recObj.setFieldValue("custrecord_visitor_name",visitor_name);
                recObj.setFieldValue("custrecord_phone_number",visitor_number);
                var getpurpose=recObj.getFieldText('custrecord_purpose_visit');
                nlapiSubmitRecord(recObj);
                
                // // Send Email
                 var getEmail = email_id[visitor_purpose];
                // nlapiLogExecution("DEBUG","getEmail : ",getEmail);
                 var subject = "Vistor Notification";
                 var body = "Hi \n "+ visitor_name + " came for Vist " + getpurpose;

                 nlapiSendEmail(-5,getEmail, subject, body);
                
                // //end Send Email
                
                var form = nlapiCreateForm("Thanks");
                var html = "<h2>Thank you for Visit!</h2>";
                form.addField("custpage_label","inlinehtml","").setDefaultValue(html);
                response.writePage(form);
            }
        }
    } catch (error) {
        nlapiLogExecution("DEBUG","Error in script : ",error);
    }

}
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
/************************************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Invoice PDF Suitlet.js
* DEVOPS TASK: DD/48530
* AUTHOR: Akash Sharma
* DATE CREATED: 29-April-2022
* DESCRIPTION: This script is to generate pdf.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 31-08-2022    BL/52718            Akash Sharma        Adding Template for "Is Collection Sales."
* 09-09-2022    DT/53107            Akash Sharma        Adding Email Generate Button.
* 04-10-2022    DT/53107            Akash Sharma        Adding Suitelet For Email PDF Generate.
************************************************************************************************/
define(['N/record','N/render','N/task'],
    
    (record,render,task) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            try{
                if (scriptContext.request.method === 'GET') {
                    var invoiceId = parseInt(scriptContext.request.parameters.invoice_id);
                    var invoiceTempId = (scriptContext.request.parameters.template_id);
                    var invoiceName;
                    var invoiceTranId = scriptContext.request.parameters.inv_tranid;
    
                    if (!invoiceId) {
                        log.error("No Invoice ID passed to SuiteLet")
                        return false;
                    }         
                    log.debug("invoiceId",invoiceId);     
                    log.debug("invoiceTempId",invoiceTempId);
                    
                    if(invoiceTempId == 'CUSTTMPL_103_7376030_SB1_247')
                    invoiceName = 'Shipping Address';
                    else if(invoiceTempId == 'CUSTTMPL_102_7376030_SB1_378')
                    invoiceName = 'Agent Subscription Order Invoice';
                    else if(invoiceTempId == 'CUSTTMPL_104_7376030_SB1_237')
                    invoiceName = 'Agent Subscription Order Invoice';
                    else if(invoiceTempId == 'CUSTTMPL_105_7376030_SB1_532')
                    invoiceName = 'Direct Subscription Order';

                    /**Is Collected Sales */
                   
                    else if(invoiceTempId == 'CUSTTMPL_108_7376030_SB1_962')
                    invoiceName = 'Direct Subscription Order';


                    /**
                     * Commented Code for Non - Sales Agent PDF Email Generate.
                     */
                    // var flag = 0;
                    
                    // if(invoiceTempId == 'CUSTTMPL_111_7376030_SB1_812'){
                    //     invoiceName = 'Not Agent Sale';
                    //     flag = 1;
                    // }else if(invoiceTempId == 'CUSTTMPL_110_7376030_SB1_525'){
                    //     /**
                    //      * Send Data to MR
                    //      */
                    //     var mapReduceScript = task.create({
                    //         taskType: task.TaskType.MAP_REDUCE
                    //     });
                    //     mapReduceScript.scriptId = 'customscript_as_ftr_mr';
                    //     mapReduceScript.deploymentId = 'customdeploy_mr_dpl';
                    //     mapReduceScript.params = {
                    //         'custscript_invoice_id' : invoiceId,
                    //         'custscript_template_id' : invoiceTempId
                    //     };
                    //     invoiceName = 'Agent Sale';
                    //     flag = 2;
                    // }
    
                    var rendererPdf = render.create();                
                    var pdfTemplate = invoiceTempId;                
                    rendererPdf.setTemplateByScriptId(pdfTemplate);
                    rendererPdf.addRecord({ templateName: 'record', record: record.load({ type: 'invoice', id: invoiceId }) });
    
                    //For Downloading
                    // scriptContext.response.writeFile(rendererAgentPdf.renderAsPdf());
                    var renderingPDF = rendererPdf.renderAsPdf();
                    renderingPDF.name = "Invoice" + invoiceTranId + " - " + invoiceName + ".pdf";
                    log.debug("invoiceName -->", invoiceName);
                    // renderingPDF.folder = 471;
                    // var renderedPDFId = renderingPDF.save();
                    

                    // var fileObj = file.load({
                    //     id: renderedPDFId
                    // });

                    scriptContext.response.writeFile({file: renderingPDF, isInline: true});
                    // scriptContext.response.writeFile(rendererAgentPdf.renderAsPdf());
                    return;                                     
                }
            }catch(e){
                log.error("Error inside onrequest",[e.message,e.stack]);
            }
            
        }

        return {onRequest}

    });

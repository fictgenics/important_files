/**
 * @NApiVersion 2.1
 * @NScriptType MapReduceScript
 */

/**************************************************************************************************************************************
*  * Copyright (c) 2022 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of Crowe LLP. ("Confidential Information"). You shall not  disclose such
* Confidential Information and shall use it only in accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: CSS MR Bundled PDF Generate.js 
* FILE ID: customscript_c53106_mr_bundled_pdf_gnrte
* DEVOPS TASK: DT/53107
* FUNCTIONAL: N/A
* DEVELOPER: Akash Sharma
* DEPLOYED ON: N/A
* DATE CREATED: 10-Oct-2022
* DESCRIPTION: This script is for generating pdf formatted mail to send to customer.
* REVISION HISTORY
* Date          DevOps item No.    Developed By      Designed By               Description
* =======================================================================================================================================
*
*****************************************************************************************************************************************/

 define(['N/runtime', 'N/record', 'N/render','N/query','N/error'],
    
 (runtime, record, render, query, error) => {

     /**
      * Defines the function that is executed at the beginning of the map/reduce process and generates the input data.
      * @param {Object} inputContext
      * @param {boolean} inputContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {Object} inputContext.ObjectRef - Object that references the input data
      * @typedef {Object} ObjectRef
      * @property {string|number} ObjectRef.id - Internal ID of the record instance that contains the input data
      * @property {string} ObjectRef.type - Type of the record instance that contains the input data
      * @returns {Array|Object|Search|ObjectRef|File|Query} The input data to use in the map/reduce process
      * @since 2015.2
      */

     const getInputData = (inputContext) => {

         /*
          * Getting data from the parameter
          */
         let currentScript = runtime.getCurrentScript();
         let data = currentScript.getParameter({name: "custscript_data_to_process"});
        //  log.debug("Data received from SL:", data);
         if(!data) {
             return;
         }
         data = JSON.parse(data);

         let toBeProcessedData = data['builtData'] || [];
        //  log.debug("toBeProcessedData", toBeProcessedData);
         return toBeProcessedData;

     }

     /**
      * Defines the function that is executed when the map entry point is triggered. This entry point is triggered automatically
      * when the associated getInputData stage is complete. This function is applied to each key-value pair in the provided
      * context.
      * @param {Object} mapContext - Data collection containing the key-value pairs to process in the map stage. This parameter
      *     is provided automatically based on the results of the getInputData stage.
      * @param {Iterator} mapContext.errors - Serialized errors that were thrown during previous attempts to execute the map
      *     function on the current key-value pair
      * @param {number} mapContext.executionNo - Number of times the map function has been executed on the current key-value
      *     pair
      * @param {boolean} mapContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {string} mapContext.key - Key to be processed during the map stage
      * @param {string} mapContext.value - Value to be processed during the map stage
      * @since 2015.2
      */

     const map = (mapContext) => {

         /*
          * Getting data from the parameter
          */
         let currentScript = runtime.getCurrentScript();
         let data = currentScript.getParameter({name: "custscript_data_to_process"});
         if(!data) {
             return;
         }
         data = JSON.parse(data);

        /*
        * Getting input data
        */
        let toCreate = JSON.parse(mapContext.value).data;
        // log.debug("toCreate in Map:", toCreate);

        /**
         * Finding Distinct Customer List
         */
        let customerArr = [];
        if(toCreate.length > 0){
            for(let looper = 0; looper < toCreate.length; looper++){
                if(customerArr.indexOf(toCreate[looper][0].nameVal) == -1){
                    customerArr.push(toCreate[looper][0].nameVal)
                }                
            }
            // log.debug("customerArr",customerArr);
        }

        

        /**
         * Creating Object of Lines to Be Printed From Current Invoice
         */

        let lineObject = {};
        lineObject['lines'] = [];
        if(customerArr.length > 0){
            for(let p = 0; p < customerArr.length; p++){
                let subObj = {};
                subObj['linenum'] = [];
                subObj['invoiceid'] = [];
                subObj['invoicenumber'] = [];
                subObj['customername'] = [];
                for(let q = 0; q < toCreate.length; q++){
                    if((toCreate[q][0].nameVal) == customerArr[p]){
                        subObj['linenum'].push(Number(toCreate[q][0].lineIDVal));
                        if(subObj['invoiceid'].indexOf(Number(toCreate[q][0].invoiceIDVal)) == -1){
                            subObj['invoiceid'].push(Number(toCreate[q][0].invoiceIDVal));
                            subObj['invoicenumber'].push(toCreate[q][0].invoiceNumberVal);
                            subObj['customername'].push(toCreate[q][0].nameVal);
                        }                       
                    } 
                }
                lineObject['lines'].push(subObj);
            }
            log.debug("lineObject", lineObject); 
        }

        

        /**
         * Check if Folder For this Invoice Exist or not?
         * If not then create.
         */

        /**
         * Folder Name to be checked or created.
         */

        let folderName = new Date().toLocaleDateString() + "_" + toCreate[0][0]['invoiceNumberVal'];
        let folderIDValue;
        log.debug("folderName to Set/Check", folderName);

        let folderSearchQuery = runSuiteQuery("SELECT name, id FROM mediaitemfolder");

        let flag = false;
        for(let iter = 0; iter < folderSearchQuery.length; iter++){
            if(folderSearchQuery[iter]['name'] == folderName){
                flag = true;
                folderIDValue = folderSearchQuery[iter]['id'];
                log.debug("Folder Name Matched");
            }
        }

        log.debug("lineObject.lines.length ", lineObject.lines.length);
        if(lineObject.lines.length > 0){
            try{
                if(flag == true){
                    log.debug("Saving File When Name Matched");
                    for(let x = 0; x < lineObject.lines.length; x++){
                        let fileName = lineObject.lines[x]['customername'] + "_" + lineObject.lines[x]['invoicenumber'];
                        log.debug("fileName to Set ", fileName);
                        let rendererPdf = render.create();                
                        let pdfTemplate = 'CUSTTMPL_111_7376030_SB1_812';                
                        rendererPdf.setTemplateByScriptId(pdfTemplate);
                        rendererPdf.addRecord({ templateName: 'record', record: record.load({ type: 'invoice', id: lineObject.lines[x]['invoiceid']}) });
                        rendererPdf.addCustomDataSource({format: render.DataSource.OBJECT, alias: "lineArray", data: lineObject.lines[x]});

                        //For Downloading
                        let renderingPDF = rendererPdf.renderAsPdf();
                        renderingPDF.name = fileName + ".pdf";
                        renderingPDF.folder = folderIDValue;
                        let renderedPDFId = renderingPDF.save();
                    }                  
                }else{
                    log.debug("Saving File When Name Not Matched");
                    var folderRec = record.create({
                        type: record.Type.FOLDER,
                        isDynamic: true
                    });
                    
                    folderRec.setValue({
                        fieldId: 'name',
                        value: folderName
                    });
    
                    folderRec.setValue({
                        fieldId: 'parent',
                        value: 475
                    })
                
                    var folderId = folderRec.save({
                        enableSourcing: true,
                        ignoreMandatoryFields: true
                    });
    
                    for(let y = 0; y < lineObject.lines.length; y++){
                        let fileName = lineObject.lines[y]['customername'] + "_" + lineObject.lines[y]['invoicenumber'];
                        log.debug("fileName to Set ", fileName);
                        let rendererPdf = render.create();                
                        let pdfTemplate = 'CUSTTMPL_111_7376030_SB1_812';                
                        rendererPdf.setTemplateByScriptId(pdfTemplate);
                        rendererPdf.addRecord({ templateName: 'record', record: record.load({ type: 'invoice', id: lineObject.lines[y]['invoiceid']}) });
                        rendererPdf.addCustomDataSource({format: render.DataSource.OBJECT, alias: "lineArray", data: lineObject.lines[y]});

                        //For Downloading
                        let renderingPDF = rendererPdf.renderAsPdf();
                        renderingPDF.name = fileName + ".pdf";
                        renderingPDF.folder = folderId;
                        let renderedPDFId = renderingPDF.save();
                    }          
                } 
            } catch (e) {
                throw error.create({name: 'PDF_STATEMENT_ERROR', message: 'Error occured during generation of statement PDF'});
            } 
        }             
     }

     /**
      * Defines the function that is executed when the reduce entry point is triggered. This entry point is triggered
      * automatically when the associated map stage is complete. This function is applied to each group in the provided context.
      * @param {Object} reduceContext - Data collection containing the groups to process in the reduce stage. This parameter is
      *     provided automatically based on the results of the map stage.
      * @param {Iterator} reduceContext.errors - Serialized errors that were thrown during previous attempts to execute the
      *     reduce function on the current group
      * @param {number} reduceContext.executionNo - Number of times the reduce function has been executed on the current group
      * @param {boolean} reduceContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {string} reduceContext.key - Key to be processed during the reduce stage
      * @param {List<String>} reduceContext.values - All values associated with a unique key that was passed to the reduce stage
      *     for processing
      * @since 2015.2
      */
     const reduce = (reduceContext) => {

     }


     /**
      * Defines the function that is executed when the summarize entry point is triggered. This entry point is triggered
      * automatically when the associated reduce stage is complete. This function is applied to the entire result set.
      * @param {Object} summaryContext - Statistics about the execution of a map/reduce script
      * @param {number} summaryContext.concurrency - Maximum concurrency number when executing parallel tasks for the map/reduce
      *     script
      * @param {Date} summaryContext.dateCreated - The date and time when the map/reduce script began running
      * @param {boolean} summaryContext.isRestarted - Indicates whether the current invocation of this function is the first
      *     invocation (if true, the current invocation is not the first invocation and this function has been restarted)
      * @param {Iterator} summaryContext.output - Serialized keys and values that were saved as output during the reduce stage
      * @param {number} summaryContext.seconds - Total seconds elapsed when running the map/reduce script
      * @param {number} summaryContext.usage - Total number of governance usage units consumed when running the map/reduce
      *     script
      * @param {number} summaryContext.yields - Total number of yields when running the map/reduce script
      * @param {Object} summaryContext.inputSummary - Statistics about the input stage
      * @param {Object} summaryContext.mapSummary - Statistics about the map stage
      * @param {Object} summaryContext.reduceSummary - Statistics about the reduce stage
      * @since 2015.2
      */
     const summarize = (summaryContext) => {

         log.debug("Status", "In Summarize");
     }

     
    /**
    * Run SQL Query
    *
    * @param {String} queryString - Query String passed
    * @returns {Array} Result fetched from the given queryString
    */

    function runSuiteQuery(queryString) {
        log.debug("Query", queryString);
        var resultSet = query.runSuiteQL({
        query: queryString
        });
        if(resultSet && resultSet.results && resultSet.results.length > 0) {
        return resultSet.asMappedResults();
        } else {
        return [];
        }
    }
  

     return {getInputData, map, reduce, summarize}

 });

/**
* @NApiVersion 2.1
* @NScriptType Suitelet
*/

/**************************************************************************************************************************************
*  * Copyright (c) 2022 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of Crowe LLP. ("Confidential Information"). You shall not  disclose such
* Confidential Information and shall use it only in accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: CSS SU Generate Email.js 
* FILE ID: customscript_c53106_su_generate_email
* DEVOPS TASK: 
* FUNCTIONAL: N/A
* DEVELOPER: Akash Sharma
* DEPLOYED ON: N/A
* DATE CREATED: 04-Oct-2022
* DESCRIPTION: This script is for generating pdf formatted mail to send to customer.
* REVISION HISTORY
* Date          DevOps item No.    Developed By      Designed By               Description
* =======================================================================================================================================
*
*****************************************************************************************************************************************/

define(['N/ui/serverWidget', './SU_Sublist_Pagination.lib.js', 'N/format', 'N/search', 'N/task', 'N/url', 'N/redirect'],

(serverWidget, paginationModule, format, search, task, url, redirect) => {
    
  const MR_SCRIPT_ID = "customscript_c53106_mr_bundled_pdf_gnrte";

  /*
  * Form Label
  * Pagination Page Size
  */
  const FORM_LABEL = "Generate Email";
  const PAGINATION_PAGE_SIZE = 15;

  /*
  * Suitelet Script and Deployment ID
  */
  const INVOICE_SL_ID = "customscript_c53106_su_generate_email";
  const INVOICE_SL_DEPID = "customdeploy_c53106_su_generate_email";
    
  
  /**
  * Defines the Suitelet script trigger point.
  * @param {Object} scriptContext
  * @param {ServerRequest} scriptContext.request - Incoming request
  * @param {ServerResponse} scriptContext.response - Suitelet response
  * @since 2015.2
  */
  const onRequest = (scriptContext) => {
    
    /*
    * Request Type
    */
    if(scriptContext.request.method == 'GET'){
      
      renderPageOnGet(scriptContext);
      
    }else{
      
      renderPageOnPost(scriptContext);
      
    }
    
  }
  
  /**
  * Creating Suitelet
  * 
  * @param {scriptContext} context 
  */
  function renderPageOnGet(context){
    
    try{
      
      /*
      * Getting Parameters from the URL of the Suitelet
      */
      let parameters = context.request.parameters;
      let fromDate = parameters.custparams_fromdate || "";
      let toDate = parameters.custparams_todate || "";
      log.debug("parameters -->", parameters);      

      /*
      * For Pagination
      */
      let pageId = parseInt(parameters.page);
      log.debug("pageId at main log -->", pageId);
      let scriptId = parameters.script;
      let deploymentId = parameters.deploy;
      
      /*
      * Creating Suitelet Form
      */
      let form = serverWidget.createForm({title: FORM_LABEL});
      form.clientScriptModulePath = './CSS CS Generate Email.js';
      
      /*
      * Creating header fields
      * Setting default in these fields if exists
      */
      let fromDateField = form.addField({id: 'custpage_from_date', label: 'From Date', type: serverWidget.FieldType.DATE});
      if(fromDate){
          fromDateField.defaultValue = format.parse({value: fromDate, type: format.Type.DATE});
      }

      let toDateField = form.addField({id: 'custpage_to_date', label: 'To Date', type: serverWidget.FieldType.DATE});
      if(toDate){
          toDateField.defaultValue = format.parse({value: toDate, type: format.Type.DATE});
      }
      
      // if(subscriptionType){
      //   log.debug("subscriptionType", subscriptionType);
      //   subscriptionType.defaultValue = subscriptionType.split(',');
      // }
            
      /*
      * Creating Subtab for the Sublist
      * Adding fields to the Sublist
      */
      
      form.addSubtab({id : 'custpage_item_list', label : 'Item List'});
      let itemSublist = form.addSublist({id : 'custpage_item_list_sublist', type : serverWidget.SublistType.LIST, label : 'Inventory Number List', tab: 'custpage_item_list'});
      itemSublist.addField({id: 'custpage_item_sublist_add', label: 'Check', type: serverWidget.FieldType.CHECKBOX});
      let subscriptionType = itemSublist.addField({id: 'custpage_item_sublist_subscription_type',type: serverWidget.FieldType.TEXT,label: 'Subscription Type'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let lineID = itemSublist.addField({id: 'custpage_item_sublist_line_id',type: serverWidget.FieldType.TEXT,label: 'Line ID'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let itemType = itemSublist.addField({id: 'custpage_item_sublist_item_type',type: serverWidget.FieldType.TEXT,label: 'Item'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let diplayName = itemSublist.addField({id: 'custpage_item_sublist_display_name',type: serverWidget.FieldType.TEXT,label: 'Display Name'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let invoiceNumber = itemSublist.addField({id: 'custpage_item_sublist_invoice_number',type: serverWidget.FieldType.TEXT,label: 'Invoice Number'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let invoiceID = itemSublist.addField({id: 'custpage_item_sublist_invoice_id',type: serverWidget.FieldType.TEXT,label: 'Invoice ID'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let abbJournalName = itemSublist.addField({id: 'custpage_item_sublist_abb_journal_name',type: serverWidget.FieldType.TEXT,label: 'Abbreviated Journal Name'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberIdentityNum = itemSublist.addField({id: 'custpage_item_sublist_subscriber_identity_num',type: serverWidget.FieldType.TEXT,label: 'Subscriber Identification Number'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberEmail = itemSublist.addField({id: 'custpage_item_sublist_subscriber_email',type: serverWidget.FieldType.TEXT,label: 'Subscriber Email'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberName = itemSublist.addField({id: 'custpage_item_sublist_subscriber_name',type: serverWidget.FieldType.TEXT,label: 'Subscriber Name'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberAddress1 = itemSublist.addField({id: 'custpage_item_sublist_subscriber_address1',type: serverWidget.FieldType.TEXT,label: 'Subscriber Address1'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberAddress2 = itemSublist.addField({id: 'custpage_item_sublist_subscriber_address2',type: serverWidget.FieldType.TEXT,label: 'Subscriber Address2'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberAddress3 = itemSublist.addField({id: 'custpage_item_sublist_subscriber_address3',type: serverWidget.FieldType.TEXT,label: 'Subscriber Address3'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberAddress4 = itemSublist.addField({id: 'custpage_item_sublist_subscriber_address4',type: serverWidget.FieldType.TEXT,label: 'Subscriber Address4'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberAddress5 = itemSublist.addField({id: 'custpage_item_sublist_subscriber_address5',type: serverWidget.FieldType.TEXT,label: 'Subscriber Address5'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberPostCode = itemSublist.addField({id: 'custpage_item_sublist_subscriber_post_code',type: serverWidget.FieldType.TEXT,label: 'Subscriber Post Code'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let subscriberCountry = itemSublist.addField({id: 'custpage_item_sublist_subscriber_country',type: serverWidget.FieldType.TEXT,label: 'Subscriber Country'}).updateDisplayType({displayType: serverWidget.FieldDisplayType.INLINE});
      let longtextField = form.addField({id: 'custpage_long_text', label: 'Paginated Final Data', type: serverWidget.FieldType.LONGTEXT}).updateDisplayType({displayType: serverWidget.FieldDisplayType.HIDDEN});
   
      
      /*
      * Retreiving Data
      * Applying Pagination
      * Setting Data on Sublist
      */
      if(parameters){
        
        /**Adding Default Values */
        if(parameters.custparams_fromdate && parameters.custparams_todate)
        form.updateDefaultValues({custpage_from_date:parameters.custparams_fromdate,custpage_to_date:parameters.custparams_todate});
        
        /*
        * Getting Query as per the filters on the Suitelet - But getting search for now!
        */
        let itemListSearch = getSearchOutput(parameters,PAGINATION_PAGE_SIZE);
        
        /*
        * Pagination
        */ 
        
        let pageCount = paginationModule.getTotalPageCount(itemListSearch, PAGINATION_PAGE_SIZE);
        log.debug("pageCount:", pageCount)
        
        let itemListData = [];
        if(pageCount > 0) {
          pageId = paginationModule.getPageId(pageId);
          paginationModule.setScriptIds(scriptId, deploymentId);
          paginationModule.addPaginationDropdown(form, PAGINATION_PAGE_SIZE, pageCount, pageId, 'custpage_item_list');
          log.debug("Status", "itemListSearch: "+itemListSearch+" | pageId: "+pageId);
          itemListData = paginationModule.fetchPageResult(itemListSearch, pageId);
          log.debug("fetchedResult for pageId:" + pageId, itemListData);
        }
        
        if(itemListData && itemListData.length > 0){
          
          for(let i = 0; i < itemListData.length; i++){              
            /*
            * Setting values in Sublist
            */  
             
            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscription_type', line: i, value: itemListData[i].getValue({name: "formulatext1",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer.category} ELSE {customermain.category} END",
              label: "Subscription Type"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_line_id', line: i, value: itemListData[i].getValue({name: "line",summary: "GROUP",label: "Line ID"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_item_type', line: i, value: itemListData[i].getText({name: "item",summary: "GROUP",label: "Item"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_display_name', line: i, value: itemListData[i].getValue({name: "displayname",join: "item",summary: "GROUP",label: "Display Name"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_invoice_number', line: i, value: itemListData[i].getValue({name: "invoicenum",summary: "GROUP",label: "Invoice Number"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_invoice_id', line: i, value: itemListData[i].getValue({name: "internalid",summary: "GROUP",label: "Invoice ID"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_abb_journal_name', line: i, value: itemListData[i].getText({name: "class",summary: "GROUP",label: "AbbreviatedJournalName"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_identity_num', line: i, value: itemListData[i].getValue({name: "formulatext2",
              summary: "GROUP",formula: "{number}|| '\' ||Concat({internalid},{linesequencenumber})",
              label: "SubscriberIdentifier"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_email', line: i, value: itemListData[i].getValue({name: "formulatext3",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_email} ELSE {customer.email} END",
              label: "SubscriberEmail"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_name', line: i, value: itemListData[i].getValue({name: "formulatext4",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer} ELSE {name} END",
              label: "SubscriberName"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_address1', line: i, value: itemListData[i].getValue({name: "formulatext5",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address1} ELSE {customer.address1} END",
              label: "SubscriberAddress1"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_address2', line: i, value: itemListData[i].getValue({name: "formulatext6",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address2} ELSE {customer.address2} END",
              label: "SubscriberAddress2"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_address3', line: i, value: itemListData[i].getValue({name: "formulatext7",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address3} ELSE {customer.address3} END",
              label: "SubscriberAddress3"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_address4', line: i, value: itemListData[i].getValue({name: "formulatext8",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address4} ELSE {billingaddress.custrecord_c44424_address4} END",
              label: "SubscriberAddress4"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_address5', line: i, value: itemListData[i].getValue({name: "formulatext9",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address5} ELSE {billingaddress.custrecord_c44424_address5} END",
              label: "SubscriberAddress5"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_post_code', line: i, value: itemListData[i].getValue({name: "formulatext10",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_zip} ELSE {customer.zipcode} END",
              label: "SubscriberPostCode"}) || ''});

            itemSublist.setSublistValue({id: 'custpage_item_sublist_subscriber_country', line: i, value: itemListData[i].getValue({name: "formulatext11",summary: "GROUP",
              formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer.countrycode} ELSE {customer.countrycode} END",
              label: "SubscriberCountry "}) || ''});
          }
          
        }
        
      }
      
      /*
      * Adding Buttons
      * Writing form to Suitelet
      */
      form.addButton({id: 'custbutton_apply_filter', label: 'Apply Filter', functionName: 'fetchItemList()'});
      form.addSubmitButton('Generate Email');
      
      context.response.writePage(form);
      
    } catch(e) {
      log.error("ERROR", e);
      context.response.write("Something went wrong");
    }
    
    
  }
  
  /**
  * Creating PDF 
  * 
  * @param {scriptContext} context 
  */
   function renderPageOnPost(context){

    /*
     * Getting Parameters in POST
     */
    log.debug("POST PARAMS", context.request.parameters);
    var date = context.request.parameters.custpage_prp_prorate;

    /*
     * Getting selected line data from long text field
     */
    let FINAL_LINE_DATA = context.request.parameters.custpage_long_text;
    if(FINAL_LINE_DATA) {
        FINAL_LINE_DATA = JSON.parse(FINAL_LINE_DATA)
    }
    log.debug("FINAL_LINE_DATA", FINAL_LINE_DATA);

    try{
      let builtData = [];
      let invoiceIdArr = [];

        /*
        * Getting Unique Invoice IDs from the FINAL_LINE_DATA
        */
        if(FINAL_LINE_DATA && Object.keys(FINAL_LINE_DATA).length > 0){
            for(let line in FINAL_LINE_DATA){                    
              let LINE_DATA = FINAL_LINE_DATA[line];              
              let invoiceIDVal = LINE_DATA['sublist_invoice_id'];
              let indexOfElement = invoiceIdArr.indexOf(invoiceIDVal);
              if(indexOfElement == -1){
                invoiceIdArr.push(invoiceIDVal);
              }
            } 
            log.debug("Invoice ID Array", invoiceIdArr);
          }

          if(FINAL_LINE_DATA && Object.keys(FINAL_LINE_DATA).length > 0){      
            
            for(let lineNum in invoiceIdArr){
              let lineValue = invoiceIdArr[lineNum];
              let outerObj = {};
              outerObj['data'] = [];
              for(let line in FINAL_LINE_DATA){
                let innerArr = [];                     
                /*
                 * Getting line data from the FINAL_LINE_DATA
                 */
                let LINE_DATA = FINAL_LINE_DATA[line];              
                let lineIDVal = LINE_DATA['sublist_line_id'];
                let invoiceIDVal = LINE_DATA['sublist_invoice_id'];
                let nameVal = LINE_DATA['sublist_subscriber_name'];
                let invoiceNumberVal = LINE_DATA['sublist_invoice_number'];

                if(lineValue == invoiceIDVal){
                  innerArr.push({
                      'lineIDVal': lineIDVal,
                      'invoiceIDVal': invoiceIDVal,
                      'invoiceNumberVal': invoiceNumberVal,
                      'nameVal': nameVal
                  });
                  outerObj['data'].push(innerArr);  
                }                              
              }
              builtData.push(outerObj);
            }
            log.debug("builtData to MR:", builtData);          
          }

          // if(FINAL_LINE_DATA && Object.keys(FINAL_LINE_DATA).length > 0){        
          //   /*
          //    * Sending Data TO MR Script for PDF Creation.
          //    */
          //   builtData = [];
          //   let invoiceIdArr = [];
          //   for(let line in FINAL_LINE_DATA){
                    
          //     /*
          //      * Getting line data from the FINAL_LINE_DATA
          //      */
          //     let LINE_DATA = FINAL_LINE_DATA[line];              
          //     let subscriptionTypeVal = LINE_DATA['sublist_subscription_type'];
          //     let lineIDVal = LINE_DATA['sublist_line_id'];
          //     let displayNameVal = LINE_DATA['sublist_display_name'];
          //     let invoiceNumberVal = LINE_DATA['sublist_invoice_number'];
          //     let invoiceIDVal = LINE_DATA['sublist_invoice_id'];
          //     let journalNameVal = LINE_DATA['sublist_abb_journal_name'];
          //     let identityNumVal = LINE_DATA['sublist_subscriber_identity_num'];
          //     let emailVal = LINE_DATA['sublist_subscriber_email'];
          //     let nameVal = LINE_DATA['sublist_subscriber_name'];
          //     let address1Val = LINE_DATA['sublist_subscriber_address1'];
          //     let address2Val = LINE_DATA['sublist_subscriber_address2'];
          //     let address3Val = LINE_DATA['sublist_subscriber_address3'];
          //     let address4Val = LINE_DATA['sublist_subscriber_address4'];
          //     let address5Val = LINE_DATA['sublist_subscriber_address5'];
          //     let postCodeVal = LINE_DATA['sublist_subscriber_post_code'];
          //     let countryVal = LINE_DATA['sublist_subscriber_country'];

          //     let indexOfElement = invoiceIdArr.indexOf(invoiceIDVal);
          //     if(indexOfElement == -1){
          //       invoiceIdArr.push(invoiceIDVal);
          //     }

          //     /*
          //      * Adding line data to the array to be paased into Mapreduce script for pdf file creation
          //      */
          //     builtData.push({
          //       fieldvalues: {
          //           'subscriptionTypeVal': subscriptionTypeVal,
          //           'lineIDVal': lineIDVal,
          //           'displayNameVal': displayNameVal,
          //           'invoiceNumberVal': invoiceNumberVal,
          //           'invoiceIDVal': invoiceIDVal,
          //           // 'journalNameVal': journalNameVal,
          //           // 'identityNumVal': identityNumVal,
          //           // 'emailVal': emailVal,
          //           'nameVal': nameVal,
          //           // 'address1Val': address1Val,
          //           // 'address2Val': address2Val,
          //           // 'address3Val': address3Val,
          //           // 'address4Val': address4Val,
          //           // 'address5Val': address5Val,
          //           // 'postCodeVal': postCodeVal,
          //           // 'countryVal': countryVal
          //       }
          //     });
          //   } 
          // }
          // log.debug("builtData to MR:", builtData);

          log.debug("builtData length:", builtData.length);
          //   /*
          //    * Sending data to Mapreduce script
          //    */
            if(builtData.length > 0) {
                log.debug("Inside IF when '(builtData.length > 0)'");
                var toBeSendToMR = {'custscript_data_to_process': {builtData: builtData}};
                let submissionStatus = callMapReduceIntance(MR_SCRIPT_ID, null, toBeSendToMR);
                if(submissionStatus) {
                    log.debug("Status", "PDF created Successfully using MR script");
                } else {
                    log.emergency("Status", "PDF creation Un-Successful via MR script");    //Send Email to concerned persons.
                }
                
            }
    } catch(e) {
        log.error("Error", e);
    }

    /*
     * Redirecting to same Suitelet
     */
    let SL_URL = url.resolveScript({
    scriptId: INVOICE_SL_ID,
    deploymentId: INVOICE_SL_DEPID
    });
let scriptHtml = "<script>window.open('"+SL_URL+"', '_self')</script>";
context.response.write(scriptHtml);

}
  
  /**
  * Return Search to get Prorated Employee Payment data
  * 
  * @param {Object} parameter - To pass filters as parameters
  * @param {String} PAGINATION_PAGE_SIZE - To divide the output in segments
  * @returns {String} paged Output
  */
  
  function getSearchOutput(parameters,PAGINATION_PAGE_SIZE){
    try {
      log.debug("Parameters Value Inside Searh Function-->",parameters);
      let searchFilters=
      [
        ["type","anyof","CustInvc"], "AND", 
        ["mainline","is","F"], "AND", 
        ["customform","anyof","100"], "AND", 
        ["taxline","is","F"], "AND", 
        ["shipping","is","F"], "AND", 
        ["cogs","is","F"], "AND", 
        ["linesequencenumber","isnotempty",""], "AND", 
        ["custcol_c44423_electronic","is","T"], "AND", 
        ["custbody_c44423_orderstate","anyof","4"], "AND", 
        ["location","anyof","1","2"]
     ];
      
      /**
      * Pushing filters only when value for those filters is entered, else blank.
      */

       log.debug("Before Pushing");

        

      if(parameters.custparams_fromdate && parameters.custparams_todate){                     
        let fDate = String(parameters.custparams_fromdate);
        let tDate = String(parameters.custparams_todate);
        log.debug("Filters Search Inside If", "fDate : " + fDate + " || tDate : " + tDate);
        searchFilters.push('AND', ["custbody_c44424_listeddate","within",fDate,tDate]);
        log.debug("searchFilters",searchFilters);
      }
     
            
      let searchObj = search.create({
        type: "invoice",
        filters: searchFilters,
        columns:
        [
          search.createColumn({
             name: "formulatext1",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer.category} ELSE {customermain.category} END",
             label: "Subscription Type"}),
          search.createColumn({name: "line",summary: "GROUP",label: "Line ID"}),
          search.createColumn({name: "item",summary: "GROUP",label: "Item"}),
          search.createColumn({name: "displayname",join: "item",summary: "GROUP",label: "Display Name"}),
          search.createColumn({name: "invoicenum",summary: "GROUP",label: "Invoice Number"}),
          search.createColumn({name: "internalid",summary: "GROUP",label: "Invoice ID"}),
          search.createColumn({name: "class",summary: "GROUP",label: "AbbreviatedJournalName"}),
          search.createColumn({name: "formulatext2",
             summary: "GROUP",formula: "{number}|| '\' ||Concat({internalid},{linesequencenumber})",label: "SubscriberIdentifier"}),
          search.createColumn({name: "formulatext3",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_email} ELSE {customer.email} END",
             label: "SubscriberEmail"}),
          search.createColumn({name: "formulatext4",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer} ELSE {name} END",
             label: "SubscriberName"}),
          search.createColumn({name: "formulatext5",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address1} ELSE {customer.address1} END",
             label: "SubscriberAddress1"}),
          search.createColumn({name: "formulatext6",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address2} ELSE {customer.address2} END",
             label: "SubscriberAddress2"}),
          search.createColumn({name: "formulatext7",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address3} ELSE {customer.address3} END",
             label: "SubscriberAddress3"}),
          search.createColumn({name: "formulatext8",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address4} ELSE {billingaddress.custrecord_c44424_address4} END",
             label: "SubscriberAddress4"}),
          search.createColumn({name: "formulatext9",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_address5} ELSE {billingaddress.custrecord_c44424_address5} END",
             label: "SubscriberAddress5"}),
          search.createColumn({name: "formulatext10",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_zip} ELSE {customer.zipcode} END",
             label: "SubscriberPostCode"}),
          search.createColumn({name: "formulatext11",summary: "GROUP",
             formula: "CASE WHEN {custbody_c44426_customer_category} = 'Sales Agent' THEN {custcol_c44424_customer.countrycode} ELSE {customer.countrycode} END",
             label: "SubscriberCountry "})
        ]
      });
      
      let searchResultCount = searchObj.runPaged().count;
      log.debug('Size of Result Count is',[searchResultCount]);
      
      
      let pagedObject = searchObj.runPaged({pageSize: PAGINATION_PAGE_SIZE});
      return pagedObject;
    }
    catch(ErrorObj){
      log.error('Error in getSearchOutput',[ErrorObj.message,ErrorObj.stack])
    }
  } 

/**
 * Call a Map/Reduce instance
 * 
 * @param {String} scriptId 
 * @param {String} deploymentId 
 * @param {Object} params 
 * @returns {Boolean}
 */
 function callMapReduceIntance(scriptId, deploymentId, params) {

  try {
      log.debug("Inside Map Reduce Function Instance Call");
      
      if(!scriptId) {
          return false;
      }
  
      var mrTask = task.create({taskType: task.TaskType.MAP_REDUCE, scriptId: scriptId});
  
      if(deploymentId) {
          mrTask.deploymentId = deploymentId;
      }
      if(params) {
          mrTask.params = params;
      }
      var taskId = mrTask.submit();
      log.debug("MR Task id:",taskId);
  
      var taskStatus = task.checkStatus(taskId);
  
      if(taskStatus.status == 'FAILED') {
          log.debug("Task failed to Submit");
          return false;
      };
  
      log.debug("Task Submitted.",taskStatus.status);
      return true

  } catch(err) {
      log.error("Error in Submitting MR:"+ scriptId, err);
      return false;
  }

}
  
  return {onRequest}
  
});

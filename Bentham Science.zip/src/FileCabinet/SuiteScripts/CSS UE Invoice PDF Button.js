/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 */
/************************************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS UE Invoice PDF Button.js
* DEVOPS TASK: DD/48530
* AUTHOR: Akash Sharma
* DATE CREATED: 29-April-2022
* DESCRIPTION: This script is for adding button on invoice generating pdf 
                whenever the category is 'Sales Agent'. 
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 31-08-2022    BL/52718            Akash Sharma        Adding Template for "Is Collection Sales."
* 09-09-2022    DT/53107            Akash Sharma        Adding Email Generate Button.
* 04-10-2022    DT/53107            Akash Sharma        Adding Suitelet For Email PDF Generate.
************************************************************************************************/
define(['N/record'],
    
    (record) => {
        /**
         * Defines the function definition that is executed before record is loaded.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @param {Form} scriptContext.form - Current form
         * @param {ServletRequest} scriptContext.request - HTTP request information sent from the browser for a client action only.
         * @since 2015.2
         */
        const beforeLoad = (scriptContext) => {
            try{
                log.debug("inside try of before load");
                let newRec = scriptContext.newRecord;
                let formvalue = newRec.getValue({fieldId: 'customform'});
                var custCategory = newRec.getValue({fieldId: 'custbody_c44426_customer_category'});
                var saleType = newRec.getValue({fieldId: 'location'});


                if (scriptContext.type === scriptContext.UserEventType.VIEW) {
                    let totalAmt = Number(newRec.getValue({fieldId: 'total'}));
                    let remAmt = Number(newRec.getValue({fieldId: 'amountremaining'}));
                    log.debug("totalAmt ", totalAmt);
                    log.debug("remAmt ", remAmt);
                     if(totalAmt && remAmt >= 0){
                        log.debug("starting ", (totalAmt - remAmt));
                        record.submitFields({
                            type: record.Type.INVOICE,
                            id: newRec.id,
                            values : {
                                'custbody_c47967_invoice_amount_rem' : (totalAmt - remAmt) 
                            }
                        });
                        log.debug("Inside submit fields");
                     }
                    var form = scriptContext.form;                       

                    /**
                     * For Sale Type (Subscription Sale or E-book) Only
                     */

                    /**
                     * Commented Code for Non - Sales Agent PDF Email Generate.
                     */

                    // if(((saleType == 1) || (saleType == 2))){
                    //     form.addButton({
                    //         id : "custpage_send_email_button",
                    //         label : "Generate Email",
                    //         functionName : 'sendEmail(' + newRec.id + ')'
                    //     });
                    // }
                    
                    form.addButton({
                        id : "custpage_print_button",
                        label : "Print PDF",
                        functionName : 'printPdf(' + newRec.id + ')'
                    });

                    scriptContext.form.clientScriptModulePath = "./CSS CS Invoice PDF.js";
                    log.debug("at end");
                    
                  }
            }catch(e){
                log.error("Error inside before load", [e.message,e.stack]);
            }
        }

        /**
         * Defines the function definition that is executed before record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const beforeSubmit = (scriptContext) => {
           
            log.debug("inside before submit");
        }

        /**
         * Defines the function definition that is executed after record is submitted.
         * @param {Object} scriptContext
         * @param {Record} scriptContext.newRecord - New record
         * @param {Record} scriptContext.oldRecord - Old record
         * @param {string} scriptContext.type - Trigger type; use values from the context.UserEventType enum
         * @since 2015.2
         */
        const afterSubmit = (scriptContext) => {
            log.debug("inside after submit");
        }

        return {beforeLoad, beforeSubmit, afterSubmit}

    });
/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
/************************************************************************************************
*  * Copyright (c) 2021 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS CS Invoice PDF.js
* DEVOPS TASK: DD/48530
* AUTHOR: Akash Sharma
* DATE CREATED: 29-April-2022
* DESCRIPTION: This script is for function call from user event & to call suitelet to generate pdf.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 31-08-2022    BL/52718            Akash Sharma        Adding Template for "Is Collection Sales."
* 09-09-2022    DT/53107            Akash Sharma        Adding Email Generate Button.
* 04-10-2022    DT/53107            Akash Sharma        Adding Suitelet For Email PDF Generate.
************************************************************************************************/
define(['N/url','N/record'],

function(url,record) {
    
    /**
     * Function to be executed after page is initialized.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.currentRecord - Current form record
     * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
     *
     * @since 2015.2
     */
    function pageInit(scriptContext) {
        log.debug("inside Page init");
    }

    function printPdf(invoice_id){
        try{

            log.debug("invoice_id",invoice_id);

         

            var invRec = record.load({
                type: record.Type.INVOICE, 
                id: Number(invoice_id)
            });

            var oneCustomer = invRec.getValue({fieldId:'custbody_c46481_morethanonecustomer'});
            log.debug("CheckBox Value", oneCustomer);          
            
            var salesAgent = invRec.getValue({fieldId:'custbody_c44426_customer_category'});
            log.debug("salesAgent Value", salesAgent);   

            var invoiceTranId = invRec.getText({fieldId:'tranid'});
            log.debug("invoiceTranId Value", invoiceTranId);  

            var isCollectedSales = invRec.getValue({fieldId: 'custbody_c44424_collection_sales'});
            log.debug("isCollectedSales", isCollectedSales);

            if(isCollectedSales || isCollectedSales == true || isCollectedSales == 'T'){
                // if(oneCustomer || oneCustomer == true || oneCustomer == 'T'){
                //     log.debug("Inside funtion for pdf print");
                //     alert("Uncheck 'Is Collection Sales' Checkbox & then try printing again!");
                // }else{
                //     log.debug("Inside else while printing pdf for only one customer");
                //     if(salesAgent == 5){
                //     alert("Cannot print pdf for Agent while 'Is Collection Sales' Checkbox is checked, change it & then try printing again!");
                //     }else{
                //         log.debug("one customer not agent");
                        var slCallOne = url.resolveScript({ //Invoice - One Customer - Not Sales Agent
                            scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
                            deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
                            returnExternalUrl: false,
                            params: {
                                'invoice_id': invoice_id,
                                'template_id': 'CUSTTMPL_108_7376030_SB1_962',
                                'inv_tranid' : invoiceTranId
                            }
                        });         
                        window.open(slCallOne);
                //     }                    
                // }                
            }else{
                if(oneCustomer || oneCustomer == true || oneCustomer == 'T'){
                    log.debug("Inside funtion for pdf print");
                    var suiteletURL = url.resolveScript({ //Invoice - Shipping Specifications
                        scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
                        deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
                        returnExternalUrl: false,
                        params: {
                            'invoice_id': invoice_id,
                            'template_id': 'CUSTTMPL_103_7376030_SB1_247',
                            'inv_tranid' : invoiceTranId
                        }
                    });            
    
                    var suiteletURLNormal = url.resolveScript({ //Invoice - Renewal
                        scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
                        deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
                        returnExternalUrl: false,
                        params: {
                            'invoice_id': invoice_id,
                            'template_id': 'CUSTTMPL_102_7376030_SB1_378',
                            'inv_tranid' : invoiceTranId
                        }
                    });
    
                    window.open(suiteletURL);
                    window.open(suiteletURLNormal);
                }else{
                    log.debug("Inside else while printing pdf for only one customer");
                    if(salesAgent == 5){
                        var slCallOne = url.resolveScript({ //Invoice - One Customer
                            scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
                            deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
                            returnExternalUrl: false,
                            params: {
                                'invoice_id': invoice_id,
                                'template_id': 'CUSTTMPL_104_7376030_SB1_237',
                                'inv_tranid' : invoiceTranId
                            }
                        }); 
        
                        window.open(slCallOne);
                    }else{
                        log.debug("one customer not agent");
                        var slCallOne = url.resolveScript({ //Invoice - One Customer - Not Sales Agent
                            scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
                            deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
                            returnExternalUrl: false,
                            params: {
                                'invoice_id': invoice_id,
                                'template_id': 'CUSTTMPL_105_7376030_SB1_532',
                                'inv_tranid' : invoiceTranId
                            }
                        }); 
        
                        window.open(slCallOne);
                    }
                    
                }
            }

        }catch(e){
            log.error("Error inside printPdf function", [e.message,e.stack]);
        }
    }

    /**
     * Commented Code for Non - Sales Agent PDF Email Generate.
     */

    // function sendEmail(invoice_id){
    //     try{

    //         log.debug("invoice_id",invoice_id);         

    //         var invRec = record.load({
    //             type: record.Type.INVOICE, 
    //             id: Number(invoice_id)
    //         });

    //         var oneCustomer = invRec.getValue({fieldId:'custbody_c46481_morethanonecustomer'});
    //         log.debug("CheckBox Value", oneCustomer);          
            
    //         var salesAgent = invRec.getValue({fieldId:'custbody_c44426_customer_category'});
    //         log.debug("salesAgent Value", salesAgent);   

    //         var invoiceTranId = invRec.getText({fieldId:'tranid'});
    //         log.debug("invoiceTranId Value", invoiceTranId);  

    //         var isCollectedSales = invRec.getValue({fieldId: 'custbody_c44424_collection_sales'});
    //         log.debug("isCollectedSales", isCollectedSales);

                
    //         if(salesAgent == 5){
    //             alert("Button Clicked when Agent.");
    //             var slCallOne = url.resolveScript({ //Is Sales Agent
    //                 scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
    //                 deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
    //                 returnExternalUrl: false,
    //                 params: {
    //                     'invoice_id': invoice_id,
    //                     'template_id': 'CUSTTMPL_110_7376030_SB1_525',
    //                     'inv_tranid' : invoiceTranId
    //                 }
    //             });         
    //             window.open(slCallOne);
    //         }else{                    
    //             alert("Button Clicked When Not Agent!");      
    //             var slCallOne = url.resolveScript({ //Not Sales Agent
    //                 scriptId: 'customscript_c46481_su_inv_pdf_suitlet',
    //                 deploymentId: 'customdeploy_c46481_su_inv_pdf_suitlet',
    //                 returnExternalUrl: false,
    //                 params: {
    //                     'invoice_id': invoice_id,
    //                     'template_id': 'CUSTTMPL_111_7376030_SB1_812',
    //                     'inv_tranid' : invoiceTranId
    //                 }
    //             });         
    //             window.open(slCallOne); 
    //         }          

    //     }catch(e){
    //         log.error("Error inside Send Email function", [e.message,e.stack]);
    //     }
    // }
    

    return {
        pageInit: pageInit,
        printPdf: printPdf
        // sendEmail: sendEmail
    };
    
});

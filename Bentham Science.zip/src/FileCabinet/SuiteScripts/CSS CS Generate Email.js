/**
* @NApiVersion 2.x
* @NScriptType ClientScript
* @NModuleScope SameAccount
*/

/**************************************************************************************************************************************
*  * Copyright (c) 2022 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of Crowe LLP. ("Confidential Information"). You shall not  disclose such
* Confidential Information and shall use it only in accordance with the terms of the license agreement you entered with Crowe LLP.
*
* FILE NAME: CSS CS Generate Email.js 
* FILE ID: N/A
* DEVOPS TASK: DT/53107
* FUNCTIONAL: N/A
* DEVELOPER: Akash Sharma
* DEPLOYED ON: N/A
* DATE CREATED: 04-Oct-2022
* DESCRIPTION: This script is for generating pdf formatted mail to send to customer.
* REVISION HISTORY
* Date          DevOps item No.    Developed By      Designed By               Description
* =======================================================================================================================================
*
*****************************************************************************************************************************************/

define(['N/currentRecord', 'N/url', 'N/runtime', 'N/record', 'N/query', './CS_Sublist_Pagination.lib.js', 'N/format'],

function(currentRecord, url, runtime, record, query, paginationCL, format) {
  
  /*
  * Suitelet Script and Deployment Id
  */
  const ITEM_SU_ID = "customscript_c53106_su_generate_email"; 
  const ITEM_SU_DEPID = "customdeploy_c53106_su_generate_email";
  
  /*
  * Sublist Fields whose value will be available in POST method
  */
  const SUBLIST_FIELDS_FOR_POST = [
    'custpage_item_sublist_subscription_type',
    'custpage_item_sublist_line_id',
    'custpage_item_sublist_display_name',
    'custpage_item_sublist_invoice_number',
    'custpage_item_sublist_invoice_id',
    'custpage_item_sublist_abb_journal_name',
    'custpage_item_sublist_subscriber_identity_num',
    'custpage_item_sublist_subscriber_email',
    'custpage_item_sublist_subscriber_name',
    'custpage_item_sublist_subscriber_address1',
    'custpage_item_sublist_subscriber_address2',
    'custpage_item_sublist_subscriber_address3',
    'custpage_item_sublist_subscriber_address4',
    'custpage_item_sublist_subscriber_address5',
    'custpage_item_sublist_subscriber_post_code',
    'custpage_item_sublist_subscriber_country'
  ];
  
  /*
  * for Pagination Data
  */
  var PAGINATED_REC_DATA = "";
  var PAGINATED_REC_ID = "";
  var PAGINATED_DATA_HOLDER_REC_TYPE = 'customrecord_c53106_paginated_data_holdr';
  
  /**
  * Function to be executed after page is initialized.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @param {string} scriptContext.mode - The mode in which the record is being accessed (create, copy, or edit)
  *
  * @since 2015.2
  */
  function pageInit(scriptContext) {
    log.debug("Inside page init function");
    
    /*
    * Getting Paginated Data from the Custom Record if it exists
    */
    var paginatedRecData = getPaginatedRecData('invoices');
    console.log("paginatedFileData", paginatedRecData);
    
    PAGINATED_REC_ID = paginatedRecData['id'];
    PAGINATED_REC_DATA = JSON.parse(paginatedRecData['data']);
    
    /*
    * Checking checkbox true for lines which were checked by the user
    */
    if(Object.keys(PAGINATED_REC_DATA).length > 0){
      
      var form = scriptContext.currentRecord;
      var sublistLineCount = form.getLineCount({sublistId: "custpage_item_list_sublist"});
      for(var i = 0; i < sublistLineCount; i++){

        var invoiceNum = form.getSublistValue({sublistId: 'custpage_item_list_sublist', fieldId: 'custpage_item_sublist_invoice_number', line: i});
        var itemVal = form.getSublistValue({sublistId: 'custpage_item_list_sublist', fieldId: 'custpage_item_sublist_item_type', line: i});      
        var customerName = form.getSublistValue({sublistId: 'custpage_item_list_sublist', fieldId: 'custpage_item_sublist_subscriber_name', line: i});
        console.log("invoiceNum", invoiceNum);
        console.log("itemVal", itemVal);
        console.log("customerName", customerName);
        var uniqueKey = invoiceNum + "_" + itemVal + "_" + customerName;
        console.log("uniqueKey: "+uniqueKey);
        
        if(PAGINATED_REC_DATA[uniqueKey]){
          nlapiSetLineItemValue("custpage_item_list_sublist", "custpage_item_sublist_add", i + 1, 'T');
          nlapiSetLineItemValue("custpage_item_list_sublist", "custpage_item_sublist_add", i + 1, 'T');
        }
        
      }
      
    }
    
    /*
    * Resetting Suitevar URL
    */
    var SL_URL = url.resolveScript({
      scriptId: ITEM_SU_ID,
      deploymentId: ITEM_SU_DEPID
    });
    window.history.replaceState(null, null, SL_URL);
    
  }
  
  /**
  * Function to be executed when field is changed.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @param {string} scriptContext.sublistId - Sublist name
  * @param {string} scriptContext.fieldId - Field name
  * @param {number} scriptContext.lineNum - Line number. Will be undefined if not a sublist or matrix field
  * @param {number} scriptContext.columnNum - Line number. Will be undefined if not a matrix field
  *
  * @since 2015.2
  */
  function fieldChanged(scriptContext) {
    log.debug("inside fieldchanged function");
    
    var form = scriptContext.currentRecord;
    var fieldName = scriptContext.fieldId;
    var sublistName = scriptContext.sublistId;
    
    /*
    * Field Changed for the Pagination Dropdown
    */
    if(fieldName == 'custpage_pageid'){
      log.debug("when page changed!");
      
      
      var DEFAULT_PARAM_FIELDS = [
        { name: 'custparams_fromdate', field: 'custpage_from_date', type: 'date'}, 
        { name: 'custparams_todate', field: 'custpage_to_date', type: 'date'},
      ]
      
      log.debug('DEFAULT_PARAM_FIELDS', DEFAULT_PARAM_FIELDS);
      if(PAGINATED_REC_DATA && PAGINATED_REC_ID) {
        console.log("Updating : ", PAGINATED_REC_ID)
        updatePaginatedRec(PAGINATED_REC_ID, PAGINATED_REC_DATA);
      }
      
      window.onbeforeunload = null;
      paginationCL.reloadSL(fieldName, scriptContext, DEFAULT_PARAM_FIELDS);
      
    }
    
    /*
    * Saving and Deleting line data when the checkbox is true or false respectively
    */
    if(sublistName == 'custpage_item_list_sublist' && fieldName == 'custpage_item_sublist_add'){
      log.debug("inside saving/deleting on check/ uncheck");
      
      /*
      * Getting values from current line
      */
      var currentIndex = form.getCurrentSublistIndex({sublistId: sublistName});
     
      
      var invoiceNum = form.getSublistValue({sublistId: sublistName, fieldId: 'custpage_item_sublist_invoice_number', line: currentIndex});
      var itemVal = form.getSublistValue({sublistId: sublistName, fieldId: 'custpage_item_sublist_item_type', line: currentIndex});      
      var customerName = form.getSublistValue({sublistId: sublistName, fieldId: 'custpage_item_sublist_subscriber_name', line: currentIndex});
      console.log("invoiceNum", invoiceNum);
      console.log("itemVal", itemVal);
      console.log("customerName", customerName);
      var uniqueKey = invoiceNum + "_" + itemVal + "_" + customerName;
      console.log("uniqueKey: "+uniqueKey);
      
      var lineSelected = form.getSublistValue({sublistId: sublistName, fieldId: fieldName, line: currentIndex});
      console.log("currentIndex:"+currentIndex, ", lineSelected:"+lineSelected);
      
      // If data doesn't exist on file
      if(!lineSelected) {
        delete PAGINATED_REC_DATA[uniqueKey];
      }
      
      /*
      * Storing line data
      */
      var lineData = {};
      SUBLIST_FIELDS_FOR_POST.forEach(function (field) {
        
        var fieldKey = field.slice(14);  
        var fieldVal = form.getSublistValue({sublistId: sublistName, fieldId: field, line: currentIndex});
        console.log("field: " +field, ", fieldKey: " +fieldKey, ", fieldVal: " + fieldVal);
        
        if(fieldVal) {
          lineData[fieldKey] = fieldVal;
        }
        
      });
      
      // If data already exist on file
      if(lineSelected) {
        PAGINATED_REC_DATA[uniqueKey] = lineData;     
      }
      console.log("PAGINATED_REC_DATA", JSON.stringify(PAGINATED_REC_DATA));
      
    }
    
  }   
  
  /**
  * Validation function to be executed when record is saved.
  *
  * @param {Object} scriptContext
  * @param {Record} scriptContext.currentRecord - Current form record
  * @returns {boolean} Return true if record is valid
  *
  * @since 2015.2
  */
  function saveRecord(scriptContext) {
    log.debug("Inside saveRecord function");
    
    var form = scriptContext.currentRecord;
    
    /*
    * Saving Selected line data in long text field
    */
    if(Object.keys(PAGINATED_REC_DATA).length > 0) {
      // IMPORTANT: Save the PAGINATED_REC_DATA to a Long text field
      form.setValue({fieldId: "custpage_long_text", value: JSON.stringify(PAGINATED_REC_DATA)});
      var emptyData = {};
      updatePaginatedRec(PAGINATED_REC_ID, emptyData);
      console.log("Final Paginated Data: "+JSON.stringify(PAGINATED_REC_DATA));
      return true;
    } else {
      alert("Please check 'Add' checkbox for atleast one line.")
      return false;
    }
    
  }
  
  /**
  * Get the File for Pagination (holding old page data)
  * For every user, every SL type there is a different file
  * 
  * @param {String} SL_TYPE 
  * @returns data
  */
  function getPaginatedRecData(SL_TYPE) {
    log.debug("inside getPaginatedRecData function");
    log.debug("SL_TYPE", SL_TYPE);
    
    var currentUser = runtime.getCurrentUser().id;
    var recName = currentUser + "_" + SL_TYPE;
    
    log.debug("currentUser", currentUser);
    log.debug("recName", recName);
    
    var data = getCustomRec(recName);
    log.debug('data', data);
    return data;
  }
  
  /**
  *  Getting Paged Data from Custom Record
  * 
  * @param {String} name 
  * @returns pageData
  */
  function getCustomRec(name) {
    log.debug("Inside getCustomRec function");
    
    var queryStr = "SELECT id, custrecord_c53106_pdh_line_data FROM "+PAGINATED_DATA_HOLDER_REC_TYPE+" WHERE name='" + name + "'";
    var fileRslt = runSuiteQuery(queryStr);
    log.debug('fileRslt', fileRslt);
    
    var pageData = {};
    
    if(fileRslt.length > 0) {
      
      pageData['data'] = fileRslt[0]['custrecord_c53106_pdh_line_data'];
      pageData['id'] = fileRslt[0]['id'];
      
    } else {
      
      // Create a empty record
      var recObj = record.create({type: PAGINATED_DATA_HOLDER_REC_TYPE});    		
      recObj.setValue({fieldId: 'name', value: name});    		
      recObj.setValue({fieldId: 'custrecord_c53106_pdh_line_data', value: "{}"});    		
      var id = recObj.save();
      
      // return empty object string 
      pageData['data'] = "{}";
      pageData['id'] = id;
      
    }
    log.debug('pageData', pageData);
    
    return pageData;
    
  }
  
  /**
  * Update Custom record with Paginated data
  * 
  * @param {String} paginatedRecId 
  * @param {Object} paginatedData
  */
  function updatePaginatedRec(paginatedRecId, paginatedData) {
    log.debug("Inside updatePaginatedRec functin");
    log.debug('paginatedData', paginatedData);
    
    try {
      
      var recObj = record.load({type: PAGINATED_DATA_HOLDER_REC_TYPE, id: paginatedRecId});
      recObj.setValue({fieldId: 'custrecord_c53106_pdh_line_data', value: JSON.stringify(paginatedData)});
      var id = recObj.save();
      console.log("PAGINATED_DATA_HOLDER_REC_TYPE Updated" , id);
      
    } catch(err) {
      console.log("Error updating " + PAGINATED_DATA_HOLDER_REC_TYPE, err)
    }
    
  }
  
  /**
  * Onclick method for Filtering
  */
  function fetchItemList(){
    
    var form = currentRecord.get();
    var fromDate = form.getValue({fieldId: 'custpage_from_date'});
    var toDate = form.getValue({fieldId: 'custpage_to_date'});
    
    
    console.log("From & To Date in CS, before formatting", "fromDate:"+fromDate+ " || toDate:"+toDate);

      var SL_URL = url.resolveScript({
        scriptId: ITEM_SU_ID,
        deploymentId: ITEM_SU_DEPID
      });
      if(fromDate && toDate){
        fromDate = fromDate.getDate() + "/" + (fromDate.getMonth() + 1) + "/" + fromDate.getFullYear();
        SL_URL += "&custparams_fromdate="+fromDate;

        toDate = toDate.getDate() + "/" + (toDate.getMonth() + 1) + "/" + toDate.getFullYear();
        SL_URL += "&custparams_todate="+toDate;
      }
      
      console.log("From & To Date in CS, after formatting date", "fromDate:"+fromDate+ " || toDate:"+toDate);

      window.onbeforeunload = null;
      window.location = SL_URL;    
  }
  
  /**
  * Run SQL Query
  * 
  * @param {queryString} - Query String passed
  * @return mappedResult - Result fetched from the given queryString
  */
  function runSuiteQuery(queryString) {  
    console.log("Query: ", queryString);
    var resultSet = query.runSuiteQL({
      query: queryString
    });
    console.log("Query wise Data: ", resultSet.asMappedResults());
    
    if(resultSet && resultSet.results && resultSet.results.length > 0) {
      return resultSet.asMappedResults();
    } else {
      return [];
    }
    
  }

  
  return {
    pageInit: pageInit,
    fieldChanged: fieldChanged,
    saveRecord: saveRecord,
    fetchItemList: fetchItemList
  };
  
});

/**
* @NApiVersion 2.x
*/

/*
*  Module description:
*  Acts as a Custom Module for implementing pagination in a sublist
*/

define(['N/ui/serverWidget'],

function(serverWidget) {
  
  // Initialize object to hold script details
  var SCRIPT_DETAILS = {
    scriptId: "",
    deploymentId: "" 
  };
  
  /*
  * Add buttons to simulate Next & Previous
  */
  function addNextPreviousButton(form, pageCount, pageId) {
    log.debug("Inside addNextPreviousButton function", addNextPreviousButton);
    log.debug("form", form);
    log.debug('pageCount', pageCount);
    log.debug('pageId', pageId);
    
    
    if (pageId != 0) {
      form.addButton({
        id : 'custpage_previous',
        label : 'Previous',
        functionName : 'getSuiteletPage(' + SCRIPT_DETAILS.scriptId + ', ' + SCRIPT_DETAILS.deploymentId + ', ' + (pageId - 1) + ')'
      });
    }
    
    if (pageId != pageCount - 1) {
      form.addButton({
        id : 'custpage_next',
        label : 'Next',
        functionName : 'getSuiteletPage(' + SCRIPT_DETAILS.scriptId + ', ' + SCRIPT_DETAILS.deploymentId + ', ' + (pageId + 1) + ')'
      });
    }
    
  }
  
  /*
  *  Add drop-down and options to navigate to specific page
  */
  function addPaginationDropdown(form, PAGE_SIZE, pageCount, pageId, container) {
    log.debug("PAGE_SIZE", PAGE_SIZE);
    log.debug("pageCount", pageCount);
    log.debug("pageId", pageId);
    log.debug("container", container);
    log.debug("inside addPaginationDropdown function");
    
    var fieldParams = {
      id : 'custpage_pageid',
      label : 'Page',
      type : serverWidget.FieldType.SELECT
    }
    
    if(container) {
      fieldParams['container'] = container;
    }
    var selectOptions = form.addField(fieldParams);
    
    for (i = 0; i < pageCount; i++) {
      if (i == pageId) {
        selectOptions.addSelectOption({
          value : 'pageid_' + i,
          text : ((i * PAGE_SIZE) + 1) + ' - ' + ((i + 1) * PAGE_SIZE),
          isSelected : true
        });
      } else {
        selectOptions.addSelectOption({
          value : 'pageid_' + i,
          text : ((i * PAGE_SIZE) + 1) + ' - ' + ((i + 1) * PAGE_SIZE)
        });
      }
    }
    
  }
  
  
  /*
  *  Set Script details 
  */
  function setScriptIds(scriptId, deploymentId) {
    
    log.debug("Inside setScriptIds function");
    
    SCRIPT_DETAILS.scriptId = scriptId;
    SCRIPT_DETAILS.deploymentId = deploymentId;
    
  }
  
  
  /*
  *  Fetch results based on pageNo
  */
  function fetchPageResult(pagedResults, pageNo) {
    log.debug("Inside fetchPageResult function");
    log.debug("pagedResults", pagedResults);
    log.debug("pageNo", pageNo);
    var data = pagedResults.fetch({index: pageNo});
    log.debug("data", data);
    return data.data;	    	
  }
  
  
  /*
  *  Get the total page count of the Query result based on different page size.
  */
  function getTotalPageCount(paginatedResult, PAGE_SIZE) {
    log.debug("Inside getTotalPageCount function");
    log.debug("paginatedResult", paginatedResult);
    log.debug('PAGE_SIZE', PAGE_SIZE);
    log.debug("return val: ",  Math.ceil(paginatedResult.count / PAGE_SIZE));
    
    return Math.ceil(paginatedResult.count / PAGE_SIZE);
    
  }
  
  
  /*
  *  Set pageId to correct value if out of index
  */
  function getPageId(pageId, pageCount) {
    log.debug("Inside getPageId function ");
    log.debug("pageId", pageId);
    log.debug("pageCount", pageCount);
    
    if (!pageId || pageId == '' || pageId < 0)
    pageId = 0;
    else if (pageId >= pageCount)
    pageId = pageCount - 1;
    
    return pageId
    
  }
  
  
  return {
    setScriptIds: setScriptIds,
    addPaginationDropdown: addPaginationDropdown,
    addNextPreviousButton: addNextPreviousButton,
    getTotalPageCount: getTotalPageCount,
    getPageId: getPageId,
    fetchPageResult: fetchPageResult
  };
  
});

/**
* @NApiVersion 2.x
* @NScriptType ClientScript
*/
define(['N/url'],
function (url) {
  
  var LONG_FIELD_ID = '';
  var SUBLIST_FIELDS = '';
  var KEY_FIELD = '';
  
  function fieldChanged(context) {
    log.debug("inside cs lib fieldchanged");
    // Navigate to selected page
    console.log("context.fieldId:", context.fieldId);
    
    var lineNum = context.lineNum;
    var sublistId = context.sublistId;
    var fieldId = context.fieldId;
    var currentRecord = context.currentRecord;
    
    if (context.fieldId == 'custpage_pageid') {
      var pageId = context.currentRecord.getValue({
        fieldId : 'custpage_pageid'
      });
      
      var lineSelectedData = context.currentRecord.getValue({
        fieldId: LONG_FIELD_ID
      })
      
      pageId = parseInt(pageId.split('_')[1]);
      
      var params = {
        'page' : pageId
      };
      params[LONG_FIELD_ID] = lineSelectedData;
      document.location = url.resolveScript({
        scriptId : getParameterFromURL('script'),
        deploymentId : getParameterFromURL('deploy'),
        params : params
      });
    }
    
    if(context.fieldId == 'custpage_ia_select' && sublistId == 'custpage_table') {
      
      handleLineSelect(currentRecord, sublistId, fieldId, LONG_FIELD_ID);
      
    }
    
    
  }
  
  /*
  *  Set Global Field IDs
  */
  function setGlobalIDS(longFieldId, keyField, sublistFields) {
    
    LONG_FIELD_ID = longFieldId; //  'custpage_rich_text';
    SUBLIST_FIELDS = sublistFields; //['so_id'];
    KEY_FIELD = keyField; //'assessment_id';
    
  }
  
  function reloadSL(PAGE_FIELD, context, DEFAULT_PARAM_FIELDS) {
    log.debug("Inside reloadSL function cs lib");
    
    log.debug('DEFAULT_PARAM_FIELDS', DEFAULT_PARAM_FIELDS);
    var pageId = context.currentRecord.getValue({
      fieldId :PAGE_FIELD // 'custpage_pageid'
    });
    
    pageId = parseInt(pageId.split('_')[1]);
    
    log.debug('pageId', pageId);
    var params = {
      'page' : pageId
    };
    
    if(LONG_FIELD_ID) {
      var lineSelectedData = context.currentRecord.getValue({
        fieldId: LONG_FIELD_ID
      });
      params[LONG_FIELD_ID] = lineSelectedData;
    }
    
    if(DEFAULT_PARAM_FIELDS) {
      for(var field = 0; field < DEFAULT_PARAM_FIELDS.length; field++) {
        
        var field_name = DEFAULT_PARAM_FIELDS[field]['field'];
        var param_name = DEFAULT_PARAM_FIELDS[field]['name'];
        
        var field_val = context.currentRecord.getValue({
          fieldId: field_name
        });
        if(DEFAULT_PARAM_FIELDS[field]['type'] == 'date' && field_val){
          field_val = (field_val.getMonth() + 1) + "/" + field_val.getDate() + "/" + field_val.getFullYear();
        }
        params[param_name] = field_val;
        
      }
    }
    log.debug("header parameters before setting to suitelet");
    document.location = url.resolveScript({
      scriptId : getParameterFromURL('script'),
      deploymentId : getParameterFromURL('deploy'),
      params : params
    });
    
  }
  
  function getSuiteletPage(suiteletScriptId, suiteletDeploymentId, pageId) {
    log.debug("Inside getSuiteletPage function cs lib");
    log.debug('suiteletDeploymentId', suiteletDeploymentId);
    log.debug('suiteletScriptId', suiteletScriptId);
    document.location = url.resolveScript({
      scriptId : suiteletScriptId,
      deploymentId : suiteletDeploymentId,
      params : {
        'page' : pageId
      }
    });
  }
  
  function getParameterFromURL(param) {
    log.debug("Inside getParameterFromURL function cs lib");
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split("=");
      if (pair[0] == param) {
        return decodeURIComponent(pair[1]);
      }
    }
    return (false);
  }
  
  
  /*
  *  Add line data to Rich text field ( Header level)
  *  Retaining multiPage data in single field
  */
  function handleLineSelect(currentRecord, sublistId, fieldId, richFieldId) {
    log.debug("Inside handleLineSelect function cs lib");
    var richData = currentRecord.getValue({
      fieldId: richFieldId
    });
    
    var isLineSelected = currentRecord.getCurrentSublistValue({
      sublistId: sublistId,
      fieldId: fieldId
    });
    console.log("isLineSelected:", isLineSelected)
    
    if(isLineSelected == true) {
      richData = addLineData(richData, currentRecord, sublistId,  KEY_FIELD);
    } else {
      richData = removeLineData(richData, currentRecord, sublistId, KEY_FIELD)
    }
    
    // TODO: handle text limit. Long text has limit of 100000
    richData = (richData &&  JSON.stringify(richData)) || "";
    
    currentRecord.setValue({
      fieldId: richFieldId,
      value: richData
    });
    
  }
  
  /*
  *  Add Key-Values to rich data
  */
  function addLineData(richData, currentRecord, sublistId, KEY_FIELD) {
    log.debug("Inside addLineData function cs lib");
    
    if(!richData) {
      richData = {};
    } else {
      richData = JSON.parse(richData);
    }
    
    
    var key = currentRecord.getCurrentSublistValue({
      sublistId: sublistId,
      fieldId: KEY_FIELD
    });
    
    // Make sure KEY_FIELD has always a value
    var  lineData = {};
    
    // Get all Sublist Field Values
    for(var i = 0; i < SUBLIST_FIELDS.length; i++) {
      
      var fieldVal = currentRecord.getCurrentSublistValue({
        sublistId: sublistId,
        fieldId: SUBLIST_FIELDS[i]
      });
      
      lineData[SUBLIST_FIELDS[i]] = fieldVal;
      
    }
    
    richData[key] = lineData
    console.log("After adding data:", richData);
    
    return richData;
    
  }
  
  /*
  * 
  */
  function removeLineData(richData, currentRecord, sublistId, KEY_FIELD) {
    log.debug("Inside removeLineData function cs lib");
    
    
    if(!richData) {
      richData = {};
    } else {
      richData = JSON.parse(richData);
    }
    
    var key = currentRecord.getCurrentSublistValue({
      sublistId: sublistId,
      fieldId: KEY_FIELD
    });
    
    if(key) {
      delete richData[key]
    }
    
    return richData;
    
  }
  
  return {
    fieldChanged: fieldChanged,
    setGlobalIDS: setGlobalIDS,
    handleLineSelect: handleLineSelect,
    getSuiteletPage : getSuiteletPage,
    reloadSL: reloadSL
  };
  
});
/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 */
/************************************************************************************************
*  * Copyright (c) 2022 - Present Crowe LLP - All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Crowe LLP. ("Confidential Information"). You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered with Crowe LLp.
*
* FILE NAME: CSS SU Invoice PDF Suitlet.js
* DEVOPS TASK: DD/48530
* AUTHOR: Akash Sharma
* DATE CREATED: 29-April-2022
* DESCRIPTION: This script is to generate pdf.
* REVISION HISTORY
* Date          DevOps item No.         By               Description
* ==============================================================================================
* 31-08-2022    BL/52718            Akash Sharma        Adding Template for "Is Collection Sales."
************************************************************************************************/
define(['N/record','N/render','N/file','N/email'],
    
    (record,render,file,email) => {
        /**
         * Defines the Suitelet script trigger point.
         * @param {Object} scriptContext
         * @param {ServerRequest} scriptContext.request - Incoming request
         * @param {ServerResponse} scriptContext.response - Suitelet response
         * @since 2015.2
         */
        const onRequest = (scriptContext) => {
            try{
                if (scriptContext.request.method === 'GET') {
                    var invoiceId = parseInt(scriptContext.request.parameters.invoice_id);
                    var invoiceTempId = (scriptContext.request.parameters.template_id);
                    var invoiceName;
                    var invoiceTranId = scriptContext.request.parameters.inv_tranid;
    
                    if (!invoiceId) {
                        log.error("No Invoice ID passed to SuiteLet")
                        return false;
                    }         
                    log.debug("invoiceId",invoiceId);     
                    log.debug("invoiceTempId",invoiceTempId);
            
                    var mergeResult = render.mergeEmail({
                        templateId: invoiceTempId,
                        entity: null,
                        recipient: null,
                        supportCaseId: null,
                        transactionId: invoiceId, 
                        customRecord: null
                    });
                    var emailSubject = mergeResult.subject;
                    var emailBody = mergeResult.body;

                    email.send({
                        author: 8,
                        recipients: 8,
                        subject: emailSubject,
                        body: emailBody,
                        // attachments: [fileObj],
                    });

                    return;
                }
            }catch(e){
                log.error("Error inside onrequest",[e.message,e.stack]);
            }
            
        }

        return {onRequest}

    });

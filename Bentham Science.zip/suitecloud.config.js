module.exports = {
    defaultProjectFolder: "src",
    commands: {}
};
